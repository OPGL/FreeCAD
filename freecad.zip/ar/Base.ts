<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ar" sourcelanguage="en">
  <context>
    <name>UnitsApi</name>
    <message>
      <location filename="../../UnitsApi.cpp" line="58"/>
      <source>Standard (mm, kg, s, °)</source>
      <translation type="unfinished">Standard (mm, kg, s, °)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="60"/>
      <source>MKS (m, kg, s, °)</source>
      <translation type="unfinished">MKS (m, kg, s, °)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="62"/>
      <source>US customary (in, lb)</source>
      <translation>الولايات المتحدة ( بوصة ، رطل)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="64"/>
      <source>Imperial decimal (in, lb)</source>
      <translation>الكسور العشرية الإمبراطورية (, lb)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="66"/>
      <source>Building Euro (cm, m², m³)</source>
      <translation>بناء اوربي (سم ، م 2، م 3)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="68"/>
      <source>Building US (ft-in, sqft, cft)</source>
      <translation>بناء الولايات المتحدة (Ft-in, qft, cft, cft)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="70"/>
      <source>Metric small parts &amp; CNC (mm, mm/min)</source>
      <translation type="unfinished">Metric small parts &amp; CNC (mm, mm/min)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="72"/>
      <source>Imperial for Civil Eng (ft, ft/s)</source>
      <translation type="unfinished">Imperial for Civil Eng (ft, ft/s)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="74"/>
      <source>FEM (mm, N, s)</source>
      <translation>FEM (mm, N, s)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="76"/>
      <source>Meter decimal (m, m², m³)</source>
      <translation type="unfinished">Meter decimal (m, m², m³)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="78"/>
      <source>Unknown schema</source>
      <translation>مخطط غير معروف</translation>
    </message>
  </context>
</TS>
