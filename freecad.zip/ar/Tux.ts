<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ar" sourcelanguage="en">
  <context>
    <name>NavigationIndicator</name>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="85"/>
      <source>Select</source>
      <translation>تحديد</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="86"/>
      <source>Zoom</source>
      <translation>تكبير</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="87"/>
      <source>Rotate</source>
      <translation>تدوير</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="88"/>
      <source>Pan</source>
      <translation>تحريك جانبي</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="89"/>
      <source>Tilt</source>
      <translation>إمالة</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="90"/>
      <source>Navigation style</source>
      <translation>نمط التنقل</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="91"/>
      <source>Page Up or Page Down key.</source>
      <translation>زر صفحة للأعلى أو صفحة للأسفل.</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="92"/>
      <source>Rotation focus</source>
      <translation>تركيز التدوير</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="93"/>
      <source>Middle mouse button or H key.</source>
      <translation>الزر الأوسط للفأره أو الزر H.</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="95"/>
      <source>Middle mouse button.</source>
      <translation>الزر الأوسط للفأرة.</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="98"/>
      <source>Navigation style not recognized.</source>
      <translation>نمط التنقل غير معروف.</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="569"/>
      <source>Settings</source>
      <translation>إعدادات</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="570"/>
      <source>Orbit style</source>
      <translation>نمط المدار</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="571"/>
      <source>Compact</source>
      <translation>مدمج</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="572"/>
      <source>Tooltip</source>
      <translation>تلميح</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="573"/>
      <source>Turntable</source>
      <translation>القرص الدوار</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="574"/>
      <source>Free Turntable</source>
      <translation type="unfinished">Free Turntable</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="575"/>
      <source>Trackball</source>
      <translation type="unfinished">Trackball</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="576"/>
      <source>Undefined</source>
      <translation>غير معرف</translation>
    </message>
  </context>
</TS>
