<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ar" sourcelanguage="en">
  <context>
    <name>CmdMeshAddFacet</name>
    <message>
      <location filename="../../Command.cpp" line="719"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="720"/>
      <source>Add triangle</source>
      <translation>إضافة مثلث</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="721"/>
      <location filename="../../Command.cpp" line="723"/>
      <source>Add triangle manually to a mesh</source>
      <translation>إضافة مثلث يدوياً إلى شبكة</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshBoundingBox</name>
    <message>
      <location filename="../../Command.cpp" line="1438"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1439"/>
      <source>Boundings info...</source>
      <translation>معلومات الحدود...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1440"/>
      <location filename="../../Command.cpp" line="1442"/>
      <source>Shows the boundings of the selected mesh</source>
      <translation>يظهر حدود الشبكة المحددة</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshBuildRegularSolid</name>
    <message>
      <location filename="../../Command.cpp" line="1490"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1491"/>
      <source>Regular solid...</source>
      <translation>مادة صلبة عادية...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1492"/>
      <location filename="../../Command.cpp" line="1494"/>
      <source>Builds a regular solid</source>
      <translation>يبني الصلبة العادية</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshCrossSections</name>
    <message>
      <location filename="../../Command.cpp" line="960"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="961"/>
      <source>Cross-sections...</source>
      <translation>المقاطع العرضية...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="962"/>
      <location filename="../../Command.cpp" line="963"/>
      <source>Cross-sections</source>
      <translation>المقاطع العرضية</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshDecimating</name>
    <message>
      <location filename="../../Command.cpp" line="1334"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1335"/>
      <source>Decimation...</source>
      <translation type="unfinished">Decimation...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1336"/>
      <location filename="../../Command.cpp" line="1337"/>
      <location filename="../../Command.cpp" line="1338"/>
      <source>Decimates a mesh</source>
      <translation type="unfinished">Decimates a mesh</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshDifference</name>
    <message>
      <location filename="../../Command.cpp" line="165"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="166"/>
      <source>Difference</source>
      <translation>فرق</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshEvaluateFacet</name>
    <message>
      <location filename="../../Command.cpp" line="1089"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1090"/>
      <source>Face info</source>
      <translation>معلومات الوجه</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1091"/>
      <location filename="../../Command.cpp" line="1093"/>
      <source>Information about face</source>
      <translation>معلومات عن الوجه</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshEvaluateSolid</name>
    <message>
      <location filename="../../Command.cpp" line="1264"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1265"/>
      <source>Check solid mesh</source>
      <translation>تحقق شبكة صلبة</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1266"/>
      <location filename="../../Command.cpp" line="1268"/>
      <source>Checks whether the mesh is a solid</source>
      <translation>يتحقق ما إذا كانت الشبكة صلبة</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshEvaluation</name>
    <message>
      <location filename="../../Command.cpp" line="1044"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1046"/>
      <source>Evaluate and repair mesh...</source>
      <translation>تقييم وإصلاح الشبكة...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1047"/>
      <location filename="../../Command.cpp" line="1049"/>
      <source>Opens a dialog to analyze and repair a mesh</source>
      <translation>لفتح مربع حوار لتحليل شبكة وإصلاحها</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshExport</name>
    <message>
      <location filename="../../Command.cpp" line="376"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="377"/>
      <source>Export mesh...</source>
      <translation>تصدير شبكة...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="378"/>
      <location filename="../../Command.cpp" line="380"/>
      <source>Exports a mesh to file</source>
      <translation>تصدير الشبكة إلى الملف</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshFillInteractiveHole</name>
    <message>
      <location filename="../../Command.cpp" line="1573"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1574"/>
      <source>Close hole</source>
      <translation>إغلاق الثقب</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1575"/>
      <location filename="../../Command.cpp" line="1577"/>
      <source>Close holes interactively</source>
      <translation>إغلاق الثقوب بشكل تفاعلي</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshFillupHoles</name>
    <message>
      <location filename="../../Command.cpp" line="1522"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1523"/>
      <source>Fill holes...</source>
      <translation>ملء الثقوب...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1524"/>
      <location filename="../../Command.cpp" line="1526"/>
      <source>Fill holes of the mesh</source>
      <translation>ملء ثقوب من شبكة</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshFlipNormals</name>
    <message>
      <location filename="../../Command.cpp" line="1402"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1403"/>
      <source>Flip normals</source>
      <translation>الانقلاب الطبيعي</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1404"/>
      <location filename="../../Command.cpp" line="1406"/>
      <source>Flips the normals of the mesh</source>
      <translation type="unfinished">Flips the normals of the mesh</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshFromGeometry</name>
    <message>
      <location filename="../../Command.cpp" line="459"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="460"/>
      <source>Create mesh from geometry...</source>
      <translation>إنشاء شبكة إنطلاقا من الشكل الهندسي...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="461"/>
      <location filename="../../Command.cpp" line="463"/>
      <source>Create mesh from the selected geometry</source>
      <translation>إنشاء شبكة إنطلاقا من الشكل الهندسي المحدد</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshFromPartShape</name>
    <message>
      <location filename="../../Command.cpp" line="531"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="532"/>
      <source>Create mesh from shape...</source>
      <translation>إنشاء شبكة من الشكل...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="533"/>
      <source>Tessellate shape</source>
      <translation>شكل تيسلات</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshHarmonizeNormals</name>
    <message>
      <location filename="../../Command.cpp" line="1366"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1367"/>
      <source>Harmonize normals</source>
      <translation>موائمة المعايير الطبيعية</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1368"/>
      <location filename="../../Command.cpp" line="1370"/>
      <source>Harmonizes the normals of the mesh</source>
      <translation type="unfinished">Harmonizes the normals of the mesh</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshImport</name>
    <message>
      <location filename="../../Command.cpp" line="323"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="324"/>
      <source>Import mesh...</source>
      <translation>استيراد شبكة...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="325"/>
      <location filename="../../Command.cpp" line="327"/>
      <source>Imports a mesh from file</source>
      <translation>استيراد الشبكة من الملف</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshIntersection</name>
    <message>
      <location filename="../../Command.cpp" line="244"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="245"/>
      <source>Intersection</source>
      <translation>تداخل</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshMerge</name>
    <message>
      <location filename="../../Command.cpp" line="1692"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1693"/>
      <source>Merge</source>
      <translation>دمج</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1694"/>
      <source>Merges selected meshes into one</source>
      <translation>دمج الشبكات المختارة في واحدة</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshPolyCut</name>
    <message>
      <location filename="../../Command.cpp" line="768"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="769"/>
      <source>Cut mesh</source>
      <translation>قطع الشبكة</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="770"/>
      <location filename="../../Command.cpp" line="772"/>
      <source>Cuts a mesh with a picked polygon</source>
      <translation type="unfinished">Cuts a mesh with a picked polygon</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshPolySegm</name>
    <message>
      <location filename="../../Command.cpp" line="660"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="661"/>
      <source>Make segment</source>
      <translation>اجعل الشريحة</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="662"/>
      <location filename="../../Command.cpp" line="664"/>
      <source>Creates a mesh segment</source>
      <translation>يقوم بإنشاء شريحة للشبكة</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshPolySplit</name>
    <message>
      <location filename="../../Command.cpp" line="987"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="988"/>
      <source>Split mesh</source>
      <translation>تقسيم الشبكة</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="989"/>
      <location filename="../../Command.cpp" line="991"/>
      <source>Splits a mesh into two meshes</source>
      <translation>يقسم الشبكة إلى شبكتين</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshPolyTrim</name>
    <message>
      <location filename="../../Command.cpp" line="833"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="834"/>
      <source>Trim mesh</source>
      <translation type="unfinished">Trim mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="835"/>
      <location filename="../../Command.cpp" line="837"/>
      <source>Trims a mesh with a picked polygon</source>
      <translation type="unfinished">Trims a mesh with a picked polygon</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshRemeshGmsh</name>
    <message>
      <location filename="../../Command.cpp" line="1183"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1184"/>
      <source>Refinement...</source>
      <translation type="unfinished">Refinement...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1185"/>
      <location filename="../../Command.cpp" line="1186"/>
      <source>Refine existing mesh</source>
      <translation type="unfinished">Refine existing mesh</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshRemoveCompByHand</name>
    <message>
      <location filename="../../Command.cpp" line="1217"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1218"/>
      <source>Remove components by hand...</source>
      <translation>إزالة المكونات يدويا...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1219"/>
      <location filename="../../Command.cpp" line="1221"/>
      <source>Mark a component to remove it from the mesh</source>
      <translation>وضع علامة على عنصر لإزالته من شبكة</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshRemoveComponents</name>
    <message>
      <location filename="../../Command.cpp" line="1135"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1136"/>
      <source>Remove components...</source>
      <translation>إزالة المكونات...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1137"/>
      <location filename="../../Command.cpp" line="1139"/>
      <source>Remove topologic independent components from the mesh</source>
      <translation>إزالة بنية المكونات المستقلة من الشبكة</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshScale</name>
    <message>
      <location filename="../../Command.cpp" line="1787"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1788"/>
      <source>Scale...</source>
      <translation>مقياس...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1789"/>
      <source>Scale selected meshes</source>
      <translation>ضبط الشبكات المختارة على هذا السلم</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshSectionByPlane</name>
    <message>
      <location filename="../../Command.cpp" line="929"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="930"/>
      <source>Create section from mesh and plane</source>
      <translation>إنشاء قسم من شبكة والسطح</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="931"/>
      <location filename="../../Command.cpp" line="932"/>
      <source>Section from mesh and plane</source>
      <translation type="unfinished">Section from mesh and plane</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshSegmentation</name>
    <message>
      <location filename="../../Command.cpp" line="1620"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1621"/>
      <source>Create mesh segments...</source>
      <translation>إنشاء شرائح الشبكة...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1622"/>
      <location filename="../../Command.cpp" line="1624"/>
      <source>Create mesh segments</source>
      <translation>إنشاء شرائح الشبكة</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshSegmentationBestFit</name>
    <message>
      <location filename="../../Command.cpp" line="1656"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1657"/>
      <source>Create mesh segments from best-fit surfaces...</source>
      <translation type="unfinished">Create mesh segments from best-fit surfaces...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1658"/>
      <location filename="../../Command.cpp" line="1660"/>
      <source>Create mesh segments from best-fit surfaces</source>
      <translation type="unfinished">Create mesh segments from best-fit surfaces</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshSmoothing</name>
    <message>
      <location filename="../../Command.cpp" line="1305"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1306"/>
      <source>Smooth...</source>
      <translation>سلس...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1307"/>
      <location filename="../../Command.cpp" line="1309"/>
      <source>Smooth the selected meshes</source>
      <translation type="unfinished">Smooth the selected meshes</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshSplitComponents</name>
    <message>
      <location filename="../../Command.cpp" line="1738"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1739"/>
      <source>Split by components</source>
      <translation type="unfinished">Split by components</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1740"/>
      <source>Split selected mesh into its components</source>
      <translation type="unfinished">Split selected mesh into its components</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshTrimByPlane</name>
    <message>
      <location filename="../../Command.cpp" line="898"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="899"/>
      <source>Trim mesh with a plane</source>
      <translation type="unfinished">Trim mesh with a plane</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="900"/>
      <location filename="../../Command.cpp" line="901"/>
      <source>Trims a mesh with a plane</source>
      <translation type="unfinished">Trims a mesh with a plane</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshUnion</name>
    <message>
      <location filename="../../Command.cpp" line="86"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="87"/>
      <source>Union</source>
      <translation>الاتحاد</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshVertexCurvature</name>
    <message>
      <location filename="../../Command.cpp" line="557"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="558"/>
      <source>Curvature plot</source>
      <translation type="unfinished">Curvature plot</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="559"/>
      <location filename="../../Command.cpp" line="561"/>
      <source>Calculates the curvature of the vertices of a mesh</source>
      <translation>يقوم بحساب إنحناء رؤوس الشبكة</translation>
    </message>
  </context>
  <context>
    <name>CmdMeshVertexCurvatureInfo</name>
    <message>
      <location filename="../../Command.cpp" line="612"/>
      <source>Mesh</source>
      <translation type="unfinished">Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="613"/>
      <source>Curvature info</source>
      <translation>معلومات الانحناء</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="614"/>
      <location filename="../../Command.cpp" line="616"/>
      <source>Information about curvature</source>
      <translation>معلومات حول الانحناء</translation>
    </message>
  </context>
  <context>
    <name>Command</name>
    <message>
      <location filename="../../Command.cpp" line="103"/>
      <source>Mesh union</source>
      <translation type="unfinished">Mesh union</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="180"/>
      <source>Mesh difference</source>
      <translation type="unfinished">Mesh difference</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="259"/>
      <source>Mesh intersection</source>
      <translation type="unfinished">Mesh intersection</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="355"/>
      <source>Import Mesh</source>
      <translation type="unfinished">Import Mesh</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="574"/>
      <source>Mesh VertexCurvature</source>
      <translation type="unfinished">Mesh VertexCurvature</translation>
    </message>
    <message>
      <location filename="../../DlgSmoothing.cpp" line="175"/>
      <source>Mesh Smoothing</source>
      <translation type="unfinished">Mesh Smoothing</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1378"/>
      <source>Harmonize mesh normals</source>
      <translation type="unfinished">Harmonize mesh normals</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1414"/>
      <source>Flip mesh normals</source>
      <translation type="unfinished">Flip mesh normals</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1548"/>
      <source>Fill up holes</source>
      <translation type="unfinished">Fill up holes</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1707"/>
      <source>Mesh merge</source>
      <translation type="unfinished">Mesh merge</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1753"/>
      <source>Mesh split</source>
      <translation type="unfinished">Mesh split</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1816"/>
      <source>Mesh scale</source>
      <translation type="unfinished">Mesh scale</translation>
    </message>
    <message>
      <location filename="../../DlgDecimating.cpp" line="156"/>
      <source>Mesh Decimating</source>
      <translation type="unfinished">Mesh Decimating</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="548"/>
      <source>Harmonize normals</source>
      <translation>موائمة المعايير الطبيعية</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="659"/>
      <source>Remove non-manifolds</source>
      <translation type="unfinished">Remove non-manifolds</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="763"/>
      <source>Fix indices</source>
      <translation type="unfinished">Fix indices</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="832"/>
      <source>Remove degenerated faces</source>
      <translation type="unfinished">Remove degenerated faces</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="903"/>
      <source>Remove duplicated faces</source>
      <translation type="unfinished">Remove duplicated faces</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="972"/>
      <source>Remove duplicated points</source>
      <translation type="unfinished">Remove duplicated points</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="1057"/>
      <source>Fix self-intersections</source>
      <translation type="unfinished">Fix self-intersections</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="1135"/>
      <source>Remove folds</source>
      <translation type="unfinished">Remove folds</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="1179"/>
      <source>Repair mesh</source>
      <translation type="unfinished">Repair mesh</translation>
    </message>
    <message>
      <location filename="../../RemoveComponents.cpp" line="162"/>
      <source>Delete selection</source>
      <translation>حذف التحديد</translation>
    </message>
    <message>
      <location filename="../../ViewProvider.cpp" line="963"/>
      <location filename="../../ViewProvider.cpp" line="1024"/>
      <source>Cut</source>
      <translation>اقتطاع</translation>
    </message>
    <message>
      <location filename="../../ViewProvider.cpp" line="973"/>
      <location filename="../../ViewProvider.cpp" line="1094"/>
      <source>Trim</source>
      <translation>قطع</translation>
    </message>
    <message>
      <location filename="../../ViewProvider.cpp" line="1181"/>
      <source>Split</source>
      <translation type="unfinished">Split</translation>
    </message>
    <message>
      <location filename="../../ViewProvider.cpp" line="1254"/>
      <source>Segment</source>
      <translation type="unfinished">Segment</translation>
    </message>
    <message>
      <location filename="../../ViewProvider.cpp" line="1856"/>
      <source>Delete</source>
      <translation>حذف</translation>
    </message>
    <message>
      <location filename="../../ViewProvider.cpp" line="1985"/>
      <source>Fill hole</source>
      <translation>ملء الثقوب</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::DlgDecimating</name>
    <message>
      <location filename="../../DlgDecimating.ui" line="14"/>
      <source>Decimating</source>
      <translation type="unfinished">Decimating</translation>
    </message>
    <message>
      <location filename="../../DlgDecimating.ui" line="20"/>
      <source>Reduction</source>
      <translation type="unfinished">Reduction</translation>
    </message>
    <message>
      <location filename="../../DlgDecimating.ui" line="28"/>
      <source>None</source>
      <translation>لا يوجد</translation>
    </message>
    <message>
      <location filename="../../DlgDecimating.ui" line="57"/>
      <source>Full</source>
      <translation type="unfinished">Full</translation>
    </message>
    <message>
      <location filename="../../DlgDecimating.ui" line="66"/>
      <location filename="../../DlgDecimating.cpp" line="101"/>
      <source>Absolute number</source>
      <translation type="unfinished">Absolute number</translation>
    </message>
    <message>
      <location filename="../../DlgDecimating.ui" line="102"/>
      <source>Tolerance</source>
      <translation type="unfinished">Tolerance</translation>
    </message>
    <message>
      <location filename="../../DlgDecimating.cpp" line="95"/>
      <source>Absolute number (Maximum: %1)</source>
      <translation type="unfinished">Absolute number (Maximum: %1)</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::DlgEvaluateMesh</name>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="14"/>
      <source>Evaluate &amp; Repair Mesh</source>
      <translation>تقييم وإصلاح الشبكة</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="23"/>
      <source>Mesh information</source>
      <translation>شبكة المعلومات</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="46"/>
      <source>Number of faces:</source>
      <translation>عدد الوجوه:</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="69"/>
      <location filename="../../DlgEvaluateMesh.ui" line="102"/>
      <location filename="../../DlgEvaluateMesh.ui" line="135"/>
      <location filename="../../DlgEvaluateMesh.ui" line="211"/>
      <location filename="../../DlgEvaluateMesh.ui" line="291"/>
      <location filename="../../DlgEvaluateMesh.ui" line="371"/>
      <location filename="../../DlgEvaluateMesh.ui" line="451"/>
      <location filename="../../DlgEvaluateMesh.ui" line="531"/>
      <location filename="../../DlgEvaluateMesh.ui" line="611"/>
      <location filename="../../DlgEvaluateMesh.ui" line="691"/>
      <location filename="../../DlgEvaluateMesh.ui" line="753"/>
      <source>No information</source>
      <translation>لا معلومات</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="79"/>
      <source>Number of edges:</source>
      <translation>عدد الحواف:</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="112"/>
      <source>Number of points:</source>
      <translation>عدد النقاط:</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="147"/>
      <source>Refresh</source>
      <translation>تحديث</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="187"/>
      <source>Orientation</source>
      <translation>التوجه</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="234"/>
      <location filename="../../DlgEvaluateMesh.ui" line="314"/>
      <location filename="../../DlgEvaluateMesh.ui" line="394"/>
      <location filename="../../DlgEvaluateMesh.ui" line="474"/>
      <location filename="../../DlgEvaluateMesh.ui" line="554"/>
      <location filename="../../DlgEvaluateMesh.ui" line="634"/>
      <location filename="../../DlgEvaluateMesh.ui" line="714"/>
      <location filename="../../DlgEvaluateMesh.ui" line="773"/>
      <location filename="../../DlgEvaluateMesh.ui" line="853"/>
      <source>Analyze</source>
      <translation>تحليل</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="244"/>
      <location filename="../../DlgEvaluateMesh.ui" line="324"/>
      <location filename="../../DlgEvaluateMesh.ui" line="404"/>
      <location filename="../../DlgEvaluateMesh.ui" line="484"/>
      <location filename="../../DlgEvaluateMesh.ui" line="564"/>
      <location filename="../../DlgEvaluateMesh.ui" line="644"/>
      <location filename="../../DlgEvaluateMesh.ui" line="724"/>
      <location filename="../../DlgEvaluateMesh.ui" line="783"/>
      <location filename="../../DlgEvaluateMesh.ui" line="863"/>
      <source>Repair</source>
      <translation>إصلاح</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="267"/>
      <source>Duplicated faces</source>
      <translation>الوجوه المكررة</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="347"/>
      <source>Duplicated points</source>
      <translation>الوجوه المكررة</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="427"/>
      <source>Non-manifolds</source>
      <translation type="unfinished">Non-manifolds</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="507"/>
      <source>Degenerated faces</source>
      <translation>وجوه مدمرة</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="587"/>
      <source>Face indices</source>
      <translation>وجه القرائن</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="667"/>
      <source>Self-intersections</source>
      <translation type="unfinished">Self-intersections</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="735"/>
      <source>Folds on surface</source>
      <translation>طيات على السطح</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="806"/>
      <source>All above tests together</source>
      <translation>جميع الاختبارات المذكورة أعلاه معا</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMesh.ui" line="830"/>
      <source>Repetitive repair</source>
      <translation>إصلاح متكرر</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::DlgEvaluateMeshImp</name>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="141"/>
      <source>Settings...</source>
      <translation>إعدادات...</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="253"/>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="420"/>
      <source>No selection</source>
      <translation>لا اختيار</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="450"/>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="451"/>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="452"/>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="453"/>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="454"/>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="455"/>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="456"/>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="457"/>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="458"/>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="459"/>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="460"/>
      <source>No information</source>
      <translation>لا معلومات</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="556"/>
      <source>Orientation</source>
      <translation>التوجه</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="524"/>
      <source>No flipped normals</source>
      <translation type="unfinished">No flipped normals</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="530"/>
      <source>%1 flipped normals</source>
      <translation type="unfinished">%1 flipped normals</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="616"/>
      <source>No non-manifolds</source>
      <translation type="unfinished">No non-manifolds</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="624"/>
      <source>%1 non-manifolds</source>
      <translation type="unfinished">%1 non-manifolds</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="675"/>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="678"/>
      <source>Non-manifolds</source>
      <translation type="unfinished">Non-manifolds</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="678"/>
      <source>Cannot remove non-manifolds</source>
      <translation type="unfinished">Cannot remove non-manifolds</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="718"/>
      <source>Invalid face indices</source>
      <translation>مؤشرات الوجه غير صالحة</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="725"/>
      <source>Invalid point indices</source>
      <translation>مؤشرات نقطة غير صالحة</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="732"/>
      <source>Multiple point indices</source>
      <translation>مؤشرات نقطة متعددة</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="739"/>
      <source>Invalid neighbour indices</source>
      <translation>مؤشرات الجوار غير صالحة</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="746"/>
      <source>No invalid indices</source>
      <translation>لا توجد مؤشرات غير صالحة</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="771"/>
      <source>Indices</source>
      <translation>المؤشرات</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="808"/>
      <source>No degenerations</source>
      <translation>لا توجد انحطاط</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="814"/>
      <source>%1 degenerated faces</source>
      <translation type="unfinished">%1 degenerated faces</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="841"/>
      <source>Degenerations</source>
      <translation type="unfinished">Degenerations</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="878"/>
      <source>No duplicated faces</source>
      <translation type="unfinished">No duplicated faces</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="884"/>
      <source>%1 duplicated faces</source>
      <translation type="unfinished">%1 duplicated faces</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="912"/>
      <source>Duplicated faces</source>
      <translation>الوجوه المكررة</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="948"/>
      <source>No duplicated points</source>
      <translation type="unfinished">No duplicated points</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="954"/>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="981"/>
      <source>Duplicated points</source>
      <translation>الوجوه المكررة</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="1024"/>
      <source>No self-intersections</source>
      <translation type="unfinished">No self-intersections</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="1030"/>
      <source>Self-intersections</source>
      <translation type="unfinished">Self-intersections</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="1100"/>
      <source>No folds on surface</source>
      <translation type="unfinished">No folds on surface</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="1116"/>
      <source>%1 folds on surface</source>
      <translation type="unfinished">%1 folds on surface</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="1144"/>
      <source>Folds</source>
      <translation>طيات</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="1278"/>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="1281"/>
      <source>Mesh repair</source>
      <translation>إصلاح الشبكة</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::DlgEvaluateSettings</name>
    <message>
      <location filename="../../DlgEvaluateSettings.ui" line="14"/>
      <source>Evaluation settings</source>
      <translation>تقييم الإعدادات</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateSettings.ui" line="20"/>
      <source>Settings</source>
      <translation type="unfinished">Settings</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateSettings.ui" line="26"/>
      <source>Check for non-manifold points</source>
      <translation type="unfinished">Check for non-manifold points</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateSettings.ui" line="33"/>
      <source>Enable check for folds on surface</source>
      <translation>تمكين التحقق من الطيات على السطح</translation>
    </message>
    <message>
      <location filename="../../DlgEvaluateSettings.ui" line="40"/>
      <source>Only consider zero area faces as degenerated</source>
      <translation>النظر فقط في مناطق وجوه الصفر كما انحطت</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::DlgRegularSolid</name>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="14"/>
      <source>Regular Solid</source>
      <translation>الصلابة العادية</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="29"/>
      <source>Solid:</source>
      <translation>الصلابة:</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="42"/>
      <source>Cube</source>
      <translation>مكعب</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="51"/>
      <source>Cylinder</source>
      <translation>أسطوانة</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="60"/>
      <source>Cone</source>
      <translation>مخروط</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="69"/>
      <source>Sphere</source>
      <translation>جسم كروى</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="78"/>
      <source>Ellipsoid</source>
      <translation>سطح إهليلجي</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="87"/>
      <source>Torus</source>
      <translation type="unfinished">Torus</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="120"/>
      <location filename="../../DlgRegularSolid.ui" line="236"/>
      <location filename="../../DlgRegularSolid.ui" line="387"/>
      <source>Length:</source>
      <translation type="unfinished">Length:</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="143"/>
      <source>Width:</source>
      <translation>العرض:</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="163"/>
      <source>Height:</source>
      <translation>الإرتفاع:</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="219"/>
      <location filename="../../DlgRegularSolid.ui" line="501"/>
      <source>Radius:</source>
      <translation>الشعاع:</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="273"/>
      <location filename="../../DlgRegularSolid.ui" line="424"/>
      <source>Edge length:</source>
      <translation>طول الحافة:</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="293"/>
      <location filename="../../DlgRegularSolid.ui" line="441"/>
      <location filename="../../DlgRegularSolid.ui" line="538"/>
      <location filename="../../DlgRegularSolid.ui" line="642"/>
      <location filename="../../DlgRegularSolid.ui" line="746"/>
      <source>Sampling:</source>
      <translation>أخذ العينات:</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="307"/>
      <location filename="../../DlgRegularSolid.ui" line="455"/>
      <source>Closed</source>
      <translation>مغلق</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="353"/>
      <location filename="../../DlgRegularSolid.ui" line="588"/>
      <location filename="../../DlgRegularSolid.ui" line="692"/>
      <source>Radius 1:</source>
      <translation>شعاع 1:</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="370"/>
      <location filename="../../DlgRegularSolid.ui" line="605"/>
      <location filename="../../DlgRegularSolid.ui" line="709"/>
      <source>Radius 2:</source>
      <translation>شعاع 2:</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="809"/>
      <source>&amp;Create</source>
      <translation>&amp;إنشاء</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="812"/>
      <source>Alt+C</source>
      <translation>Alt+C</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolid.ui" line="825"/>
      <source>Close</source>
      <translation>إغلاق</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::DlgRegularSolidImp</name>
    <message>
      <location filename="../../DlgRegularSolidImp.cpp" line="124"/>
      <location filename="../../DlgRegularSolidImp.cpp" line="209"/>
      <location filename="../../DlgRegularSolidImp.cpp" line="217"/>
      <source>Create %1</source>
      <translation>إنشاء %1</translation>
    </message>
    <message>
      <location filename="../../DlgRegularSolidImp.cpp" line="124"/>
      <source>No active document</source>
      <translation>لا يوجد أي مستند نشط</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::DlgSettingsImportExport</name>
    <message>
      <location filename="../../DlgSettingsImportExport.ui" line="14"/>
      <source>Mesh Formats</source>
      <translation>تنسيقات الشبكة</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsImportExport.ui" line="20"/>
      <source>Export</source>
      <translation type="unfinished">Export</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsImportExport.ui" line="28"/>
      <source>Deviation of tessellation to the actual surface</source>
      <translation type="unfinished">Deviation of tessellation to the actual surface</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsImportExport.ui" line="31"/>
      <source>&lt;html&gt;&lt;head&gt;&lt;meta name="qrichtext" content="1" /&gt;&lt;/head&gt;&lt;body style=" white-space: pre-wrap; font-size:7.8pt; font-weight:400; font-style:normal; text-decoration:none;"&gt;&lt;p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"&gt;&lt;span style=" font-weight:600;"&gt;Tessellation&lt;/span&gt;&lt;/p&gt;&lt;p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;"&gt;&lt;/p&gt;&lt;p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;"&gt;&lt;span style=" font-weight:400;"&gt;Defines the maximum deviation of the tessellated mesh to the surface. The smaller the value is the slower the render speed which results in increased detail/resolution.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
      <translation type="unfinished">&lt;html&gt;&lt;head&gt;&lt;meta name="qrichtext" content="1" /&gt;&lt;/head&gt;&lt;body style=" white-space: pre-wrap; font-size:7.8pt; font-weight:400; font-style:normal; text-decoration:none;"&gt;&lt;p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"&gt;&lt;span style=" font-weight:600;"&gt;Tessellation&lt;/span&gt;&lt;/p&gt;&lt;p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;"&gt;&lt;/p&gt;&lt;p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;"&gt;&lt;span style=" font-weight:400;"&gt;Defines the maximum deviation of the tessellated mesh to the surface. The smaller the value is the slower the render speed which results in increased detail/resolution.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsImportExport.ui" line="34"/>
      <source>Maximum mesh deviation</source>
      <translation>أقصى انحراف في الشبكة</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsImportExport.ui" line="41"/>
      <source>Maximal deviation between mesh and object</source>
      <translation type="unfinished">Maximal deviation between mesh and object</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsImportExport.ui" line="63"/>
      <source>ZIP compression is used when writing a mesh file in AMF format</source>
      <translation type="unfinished">ZIP compression is used when writing a mesh file in AMF format</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsImportExport.ui" line="66"/>
      <source>Export AMF files using compression</source>
      <translation type="unfinished">Export AMF files using compression</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsImportExport.ui" line="82"/>
      <source>Always export mesh as model type in 3MF format even if not a solid</source>
      <translation type="unfinished">Always export mesh as model type in 3MF format even if not a solid</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsImportExport.ui" line="85"/>
      <source>Export 3MF files as model type</source>
      <translation type="unfinished">Export 3MF files as model type</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsImportExport.ui" line="114"/>
      <source>Width:</source>
      <translation>العرض:</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsImportExport.ui" line="138"/>
      <source>Height:</source>
      <translation>الإرتفاع:</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsImportExportImp.cpp" line="39"/>
      <source>This parameter indicates whether ZIP compression
is used when writing a file in AMF format</source>
      <translation type="unfinished">This parameter indicates whether ZIP compression
is used when writing a file in AMF format</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::DlgSettingsMeshView</name>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="14"/>
      <source>Mesh view</source>
      <translation>عرض الشبكة</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="35"/>
      <source>Default appearance for new meshes</source>
      <translation>المظهر الافتراضي للتنسقات الجديدة</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="73"/>
      <source>Default mesh color</source>
      <translation>لون الشبكة الافتراضية</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="80"/>
      <source>Default color for new meshes</source>
      <translation type="unfinished">Default color for new meshes</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="116"/>
      <source>Mesh transparency</source>
      <translation>شفافية الشبكة</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="142"/>
      <source>Default line color</source>
      <translation>لون الخط الافتراضي</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="149"/>
      <source>Default line color for new meshes</source>
      <translation type="unfinished">Default line color for new meshes</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="185"/>
      <source>Line transparency</source>
      <translation>شفافية الخط</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="211"/>
      <source>Backface color</source>
      <translation type="unfinished">Backface color</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="251"/>
      <source>The bottom side of surface will be rendered the same way than top side.
If not checked, it depends on the option "Enable backlight color"
(preferences section Display -&gt; 3D View). Either the backlight color
will be used or black.</source>
      <translation type="unfinished">The bottom side of surface will be rendered the same way than top side.
If not checked, it depends on the option "Enable backlight color"
(preferences section Display -&gt; 3D View). Either the backlight color
will be used or black.</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="257"/>
      <source>Two-side rendering</source>
      <translation type="unfinished">Two-side rendering</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="273"/>
      <source>A bounding box will be displayed</source>
      <translation type="unfinished">A bounding box will be displayed</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="276"/>
      <source>Show bounding-box for highlighted or selected meshes</source>
      <translation type="unfinished">Show bounding-box for highlighted or selected meshes</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="313"/>
      <source>Smoothing</source>
      <translation>التنعيم</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="334"/>
      <source>If this option is set Phong shading is used, otherwise flat shading.
Shading defines the appearance of surfaces.

With flat shading the surface normals are not defined per vertex that leads
to a unreal appearance for curved surfaces while using Phong shading leads
to a smoother appearance.
</source>
      <translation type="unfinished">If this option is set Phong shading is used, otherwise flat shading.
Shading defines the appearance of surfaces.

With flat shading the surface normals are not defined per vertex that leads
to a unreal appearance for curved surfaces while using Phong shading leads
to a smoother appearance.
</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="343"/>
      <source>Define normal per vertex</source>
      <translation>تحديد القيمة العادية لكل قمة رأس</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="356"/>
      <source>&lt;html&gt;&lt;head&gt;&lt;meta name="qrichtext" content="1" /&gt;&lt;/head&gt;&lt;body style=" white-space: pre-wrap; font-size:7.8pt; font-weight:400; font-style:normal; text-decoration:none;"&gt;&lt;p style=" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;"&gt;This is the smallest angle between two faces where normals get calculated to do flat shading.&lt;/p&gt;&lt;p style=" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;"&gt;If the angle between the normals of two neighbouring faces is less than the crease angle, the faces will be smoothshaded around their common edge.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
      <translation type="unfinished">&lt;html&gt;&lt;head&gt;&lt;meta name="qrichtext" content="1" /&gt;&lt;/head&gt;&lt;body style=" white-space: pre-wrap; font-size:7.8pt; font-weight:400; font-style:normal; text-decoration:none;"&gt;&lt;p style=" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;"&gt;This is the smallest angle between two faces where normals get calculated to do flat shading.&lt;/p&gt;&lt;p style=" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;"&gt;If the angle between the normals of two neighbouring faces is less than the crease angle, the faces will be smoothshaded around their common edge.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="404"/>
      <source>&lt;html&gt;&lt;head&gt;&lt;meta name="qrichtext" content="1" /&gt;&lt;/head&gt;&lt;body style=" white-space: pre-wrap; font-size:7.8pt; font-weight:400; font-style:normal; text-decoration:none;"&gt;&lt;p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;"&gt;&lt;span style=" font-weight:600;"&gt;Hint&lt;/span&gt;&lt;/p&gt;&lt;p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;"&gt;Defining the normals per vertex is also called &lt;span style=" font-style:italic;"&gt;Phong shading&lt;/span&gt;&lt;/p&gt;&lt;p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt; font-style:italic;"&gt;&lt;span style=" font-style:normal;"&gt;while defining the normals per face is called &lt;/span&gt;Flat shading&lt;span style=" font-style:normal;"&gt;.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
      <translation type="unfinished">&lt;html&gt;&lt;head&gt;&lt;meta name="qrichtext" content="1" /&gt;&lt;/head&gt;&lt;body style=" white-space: pre-wrap; font-size:7.8pt; font-weight:400; font-style:normal; text-decoration:none;"&gt;&lt;p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;"&gt;&lt;span style=" font-weight:600;"&gt;Hint&lt;/span&gt;&lt;/p&gt;&lt;p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;"&gt;Defining the normals per vertex is also called &lt;span style=" font-style:italic;"&gt;Phong shading&lt;/span&gt;&lt;/p&gt;&lt;p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt; font-style:italic;"&gt;&lt;span style=" font-style:normal;"&gt;while defining the normals per face is called &lt;/span&gt;Flat shading&lt;span style=" font-style:normal;"&gt;.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="359"/>
      <source>Crease angle</source>
      <translation>زاوية التجعد</translation>
    </message>
    <message>
      <location filename="../../DlgSettingsMeshView.ui" line="369"/>
      <source>Crease angle is a threshold angle between two faces.

 If face angle ≥ crease angle, facet shading is used
 If face angle &lt; crease angle, smooth shading is used</source>
      <translation type="unfinished">Crease angle is a threshold angle between two faces.

 If face angle ≥ crease angle, facet shading is used
 If face angle &lt; crease angle, smooth shading is used</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::DlgSmoothing</name>
    <message>
      <location filename="../../DlgSmoothing.ui" line="14"/>
      <source>Smoothing</source>
      <translation>التنعيم</translation>
    </message>
    <message>
      <location filename="../../DlgSmoothing.ui" line="23"/>
      <source>Method</source>
      <translation>الطريقة</translation>
    </message>
    <message>
      <location filename="../../DlgSmoothing.ui" line="29"/>
      <source>Taubin</source>
      <translation type="unfinished">Taubin</translation>
    </message>
    <message>
      <location filename="../../DlgSmoothing.ui" line="39"/>
      <source>Laplace</source>
      <translation type="unfinished">Laplace</translation>
    </message>
    <message>
      <location filename="../../DlgSmoothing.ui" line="49"/>
      <source>Parameter</source>
      <translation type="unfinished">Parameter</translation>
    </message>
    <message>
      <location filename="../../DlgSmoothing.ui" line="55"/>
      <source>Iterations:</source>
      <translation>التكرارات:</translation>
    </message>
    <message>
      <location filename="../../DlgSmoothing.ui" line="72"/>
      <source>Lambda:</source>
      <translation type="unfinished">Lambda:</translation>
    </message>
    <message>
      <location filename="../../DlgSmoothing.ui" line="95"/>
      <source>Mu:</source>
      <translation type="unfinished">Mu:</translation>
    </message>
    <message>
      <location filename="../../DlgSmoothing.ui" line="118"/>
      <source>Only selection</source>
      <translation>التحديد فقط</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::GmshWidget</name>
    <message>
      <location filename="../../RemeshGmsh.cpp" line="98"/>
      <source>Automatic</source>
      <translation>تلقائي</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.cpp" line="99"/>
      <source>Adaptive</source>
      <translation type="unfinished">Adaptive</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.cpp" line="101"/>
      <source>Frontal</source>
      <translation type="unfinished">Frontal</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.cpp" line="103"/>
      <source>Frontal Quad</source>
      <translation type="unfinished">Frontal Quad</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.cpp" line="104"/>
      <source>Parallelograms</source>
      <translation type="unfinished">Parallelograms</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.cpp" line="195"/>
      <location filename="../../RemeshGmsh.cpp" line="254"/>
      <source>Time:</source>
      <translation>الوقت:</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.cpp" line="241"/>
      <source>Running gmsh...</source>
      <translation type="unfinished">Running gmsh...</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.cpp" line="265"/>
      <source>Failed to start</source>
      <translation type="unfinished">Failed to start</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.cpp" line="272"/>
      <source>Error</source>
      <translation>خطأ</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::MeshFaceAddition</name>
    <message>
      <location filename="../../MeshEditor.cpp" line="396"/>
      <source>Add triangle</source>
      <translation>إضافة مثلث</translation>
    </message>
    <message>
      <location filename="../../MeshEditor.cpp" line="397"/>
      <source>Flip normal</source>
      <translation>انقلاب عادي</translation>
    </message>
    <message>
      <location filename="../../MeshEditor.cpp" line="398"/>
      <source>Clear</source>
      <translation>مسح</translation>
    </message>
    <message>
      <location filename="../../MeshEditor.cpp" line="414"/>
      <source>Finish</source>
      <translation>إنهاء</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::MeshFillHole</name>
    <message>
      <location filename="../../MeshEditor.cpp" line="767"/>
      <source>Finish</source>
      <translation>إنهاء</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::ParametersDialog</name>
    <message>
      <location filename="../../SegmentationBestFit.cpp" line="172"/>
      <source>Surface fit</source>
      <translation type="unfinished">Surface fit</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.cpp" line="179"/>
      <source>Parameters</source>
      <translation>المعايير</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.cpp" line="184"/>
      <source>Selection</source>
      <translation type="unfinished">Selection</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.cpp" line="192"/>
      <source>Region</source>
      <translation>منطقة</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.cpp" line="198"/>
      <source>Triangle</source>
      <translation>مثلث</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.cpp" line="204"/>
      <source>Clear</source>
      <translation>مسح</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.cpp" line="210"/>
      <source>Compute</source>
      <translation type="unfinished">Compute</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.cpp" line="305"/>
      <source>No selection</source>
      <translation>لا اختيار</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.cpp" line="306"/>
      <source>Before fitting the surface select an area.</source>
      <translation type="unfinished">Before fitting the surface select an area.</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::RemeshGmsh</name>
    <message>
      <location filename="../../RemeshGmsh.ui" line="14"/>
      <source>Remesh by Gmsh</source>
      <translation type="unfinished">Remesh by Gmsh</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.ui" line="26"/>
      <source>Remeshing Parameter</source>
      <translation type="unfinished">Remeshing Parameter</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.ui" line="32"/>
      <source>Meshing:</source>
      <translation type="unfinished">Meshing:</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.ui" line="42"/>
      <source>Max element size (0.0 = Auto):</source>
      <translation type="unfinished">Max element size (0.0 = Auto):</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.ui" line="68"/>
      <source>Min element size (0.0 = Auto):</source>
      <translation type="unfinished">Min element size (0.0 = Auto):</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.ui" line="94"/>
      <source>Angle:</source>
      <translation>الزاوية:</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.ui" line="126"/>
      <source>Gmsh</source>
      <translation type="unfinished">Gmsh</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.ui" line="134"/>
      <source>Path</source>
      <translation>المسار</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.ui" line="154"/>
      <source>Kill</source>
      <translation type="unfinished">Kill</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.ui" line="181"/>
      <source>Time:</source>
      <translation>الوقت:</translation>
    </message>
    <message>
      <location filename="../../RemeshGmsh.ui" line="188"/>
      <source>Clear</source>
      <translation>مسح</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::RemoveComponents</name>
    <message>
      <location filename="../../RemoveComponents.ui" line="14"/>
      <source>Remove components</source>
      <translation>إزالة المكونات</translation>
    </message>
    <message>
      <location filename="../../RemoveComponents.ui" line="20"/>
      <source>Select</source>
      <translation>تحديد</translation>
    </message>
    <message>
      <location filename="../../RemoveComponents.ui" line="32"/>
      <location filename="../../RemoveComponents.ui" line="118"/>
      <source>Region</source>
      <translation>منطقة</translation>
    </message>
    <message>
      <location filename="../../RemoveComponents.ui" line="52"/>
      <location filename="../../RemoveComponents.ui" line="138"/>
      <source>All</source>
      <translation type="unfinished">All</translation>
    </message>
    <message>
      <location filename="../../RemoveComponents.ui" line="72"/>
      <location filename="../../RemoveComponents.ui" line="158"/>
      <source>Components</source>
      <translation>المكونات</translation>
    </message>
    <message>
      <location filename="../../RemoveComponents.ui" line="79"/>
      <source>&lt; faces than</source>
      <translation type="unfinished">&lt; faces than</translation>
    </message>
    <message>
      <location filename="../../RemoveComponents.ui" line="89"/>
      <location filename="../../RemoveComponents.ui" line="175"/>
      <source>Pick triangle</source>
      <translation>اختر مثلث</translation>
    </message>
    <message>
      <location filename="../../RemoveComponents.ui" line="96"/>
      <source>Select whole component</source>
      <translation>حدد مكونا كاملا</translation>
    </message>
    <message>
      <location filename="../../RemoveComponents.ui" line="106"/>
      <source>Deselect</source>
      <translation>إلغاء تحديد</translation>
    </message>
    <message>
      <location filename="../../RemoveComponents.ui" line="165"/>
      <source>&gt; faces than</source>
      <translation type="unfinished">&gt; faces than</translation>
    </message>
    <message>
      <location filename="../../RemoveComponents.ui" line="182"/>
      <source>Deselect whole component</source>
      <translation>قم بإلغاء تحديد مكون كامل</translation>
    </message>
    <message>
      <location filename="../../RemoveComponents.ui" line="192"/>
      <source>Region options</source>
      <translation>خيارات المنطقة</translation>
    </message>
    <message>
      <location filename="../../RemoveComponents.ui" line="198"/>
      <source>Respect only visible triangles</source>
      <translation>احترم المثلثات المرئية فقط</translation>
    </message>
    <message>
      <location filename="../../RemoveComponents.ui" line="208"/>
      <source>Respect only triangles with normals facing screen</source>
      <translation type="unfinished">Respect only triangles with normals facing screen</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::Segmentation</name>
    <message>
      <location filename="../../Segmentation.ui" line="14"/>
      <source>Mesh segmentation</source>
      <translation>تجزئة الشبكة</translation>
    </message>
    <message>
      <location filename="../../Segmentation.ui" line="20"/>
      <source>Smooth mesh</source>
      <translation>شبكة ناعمة</translation>
    </message>
    <message>
      <location filename="../../Segmentation.ui" line="37"/>
      <source>Plane</source>
      <translation>سطح</translation>
    </message>
    <message>
      <location filename="../../Segmentation.ui" line="46"/>
      <location filename="../../Segmentation.ui" line="189"/>
      <location filename="../../Segmentation.ui" line="252"/>
      <location filename="../../Segmentation.ui" line="286"/>
      <source>Tolerance</source>
      <translation type="unfinished">Tolerance</translation>
    </message>
    <message>
      <location filename="../../Segmentation.ui" line="63"/>
      <location filename="../../Segmentation.ui" line="143"/>
      <location filename="../../Segmentation.ui" line="206"/>
      <location filename="../../Segmentation.ui" line="303"/>
      <source>Minimum number of faces</source>
      <translation>الحد الأدنى لعدد الوجوه</translation>
    </message>
    <message>
      <location filename="../../Segmentation.ui" line="83"/>
      <source>Cylinder</source>
      <translation>أسطوانة</translation>
    </message>
    <message>
      <location filename="../../Segmentation.ui" line="92"/>
      <location filename="../../Segmentation.ui" line="172"/>
      <source>Curvature</source>
      <translation type="unfinished">Curvature</translation>
    </message>
    <message>
      <location filename="../../Segmentation.ui" line="109"/>
      <source>Tolerance (Flat)</source>
      <translation type="unfinished">Tolerance (Flat)</translation>
    </message>
    <message>
      <location filename="../../Segmentation.ui" line="126"/>
      <source>Tolerance (Curved)</source>
      <translation type="unfinished">Tolerance (Curved)</translation>
    </message>
    <message>
      <location filename="../../Segmentation.ui" line="163"/>
      <source>Sphere</source>
      <translation>جسم كروى</translation>
    </message>
    <message>
      <location filename="../../Segmentation.ui" line="226"/>
      <source>Freeform</source>
      <translation type="unfinished">Freeform</translation>
    </message>
    <message>
      <location filename="../../Segmentation.ui" line="235"/>
      <source>Max. Curvature</source>
      <translation type="unfinished">Max. Curvature</translation>
    </message>
    <message>
      <location filename="../../Segmentation.ui" line="269"/>
      <source>Min. Curvature</source>
      <translation type="unfinished">Min. Curvature</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::SegmentationBestFit</name>
    <message>
      <location filename="../../SegmentationBestFit.ui" line="14"/>
      <source>Mesh segmentation</source>
      <translation>تجزئة الشبكة</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.ui" line="20"/>
      <source>Plane</source>
      <translation>سطح</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.ui" line="29"/>
      <location filename="../../SegmentationBestFit.ui" line="82"/>
      <location filename="../../SegmentationBestFit.ui" line="135"/>
      <source>Parameters...</source>
      <translation type="unfinished">Parameters...</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.ui" line="36"/>
      <location filename="../../SegmentationBestFit.ui" line="89"/>
      <location filename="../../SegmentationBestFit.ui" line="142"/>
      <source>Tolerance</source>
      <translation type="unfinished">Tolerance</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.ui" line="53"/>
      <location filename="../../SegmentationBestFit.ui" line="106"/>
      <location filename="../../SegmentationBestFit.ui" line="159"/>
      <source>Minimum number of faces</source>
      <translation>الحد الأدنى لعدد الوجوه</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.ui" line="73"/>
      <source>Cylinder</source>
      <translation>أسطوانة</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.ui" line="126"/>
      <source>Sphere</source>
      <translation>جسم كروى</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.cpp" line="374"/>
      <location filename="../../SegmentationBestFit.cpp" line="399"/>
      <source>Base</source>
      <translation>القاعدة</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.cpp" line="375"/>
      <source>Normal</source>
      <translation type="unfinished">Normal</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.cpp" line="400"/>
      <source>Axis</source>
      <translation>محور</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.cpp" line="401"/>
      <location filename="../../SegmentationBestFit.cpp" line="428"/>
      <source>Radius</source>
      <translation>نصف القطر</translation>
    </message>
    <message>
      <location filename="../../SegmentationBestFit.cpp" line="427"/>
      <source>Center</source>
      <translation>مركز</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::Selection</name>
    <message>
      <location filename="../../Selection.ui" line="14"/>
      <location filename="../../Selection.ui" line="20"/>
      <source>Selection</source>
      <translation type="unfinished">Selection</translation>
    </message>
    <message>
      <location filename="../../Selection.ui" line="39"/>
      <source>Add</source>
      <translation>إضافة</translation>
    </message>
    <message>
      <location filename="../../Selection.ui" line="46"/>
      <source>Clear</source>
      <translation>مسح</translation>
    </message>
    <message>
      <location filename="../../Selection.ui" line="53"/>
      <source>Respect only visible triangles</source>
      <translation>احترم المثلثات المرئية فقط</translation>
    </message>
    <message>
      <location filename="../../Selection.ui" line="63"/>
      <source>Respect only triangles with normals facing screen</source>
      <translation type="unfinished">Respect only triangles with normals facing screen</translation>
    </message>
    <message>
      <location filename="../../Selection.cpp" line="86"/>
      <source>Use a brush tool to select the area</source>
      <translation>استخدام أداة فرشاة لتحديد المنطقة</translation>
    </message>
    <message>
      <location filename="../../Selection.cpp" line="89"/>
      <source>Clears completely the selected area</source>
      <translation>مسح المنطقة المحددة تماما</translation>
    </message>
  </context>
  <context>
    <name>MeshGui::TaskRemoveComponents</name>
    <message>
      <location filename="../../RemoveComponents.cpp" line="208"/>
      <location filename="../../RemoveComponents.cpp" line="253"/>
      <source>Delete</source>
      <translation>حذف</translation>
    </message>
    <message>
      <location filename="../../RemoveComponents.cpp" line="209"/>
      <location filename="../../RemoveComponents.cpp" line="254"/>
      <source>Invert</source>
      <translation>عكس</translation>
    </message>
  </context>
  <context>
    <name>MeshInfoWatcher</name>
    <message>
      <location filename="../../Workbench.cpp" line="68"/>
      <source>Number of points:</source>
      <translation>عدد النقاط:</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="71"/>
      <source>Number of facets:</source>
      <translation type="unfinished">Number of facets:</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="77"/>
      <source>Minimum bound:</source>
      <translation type="unfinished">Minimum bound:</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="80"/>
      <source>Maximum bound:</source>
      <translation type="unfinished">Maximum bound:</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="87"/>
      <source>Mesh info box</source>
      <translation type="unfinished">Mesh info box</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="88"/>
      <source>Mesh info</source>
      <translation type="unfinished">Mesh info</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="121"/>
      <location filename="../../Workbench.cpp" line="122"/>
      <source>X: %1	Y: %2	Z: %3</source>
      <translation type="unfinished">X: %1	Y: %2	Z: %3</translation>
    </message>
  </context>
  <context>
    <name>Mesh_BoundingBox</name>
    <message>
      <location filename="../../Command.cpp" line="1462"/>
      <source>Boundings of %1:</source>
      <translation type="unfinished">Boundings of %1:</translation>
    </message>
  </context>
  <context>
    <name>Mesh_Union</name>
    <message>
      <location filename="../../Command.cpp" line="138"/>
      <location filename="../../Command.cpp" line="144"/>
      <location filename="../../Command.cpp" line="217"/>
      <location filename="../../Command.cpp" line="223"/>
      <location filename="../../Command.cpp" line="296"/>
      <location filename="../../Command.cpp" line="302"/>
      <source>OpenSCAD</source>
      <translation>OpenSCAD</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="139"/>
      <location filename="../../Command.cpp" line="218"/>
      <location filename="../../Command.cpp" line="297"/>
      <source>Unknown error occurred while running OpenSCAD.</source>
      <translation>حدث خطأ غير معروف أثناء تشغيل OpenSCAD.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="145"/>
      <location filename="../../Command.cpp" line="224"/>
      <location filename="../../Command.cpp" line="303"/>
      <source>OpenSCAD cannot be found on your system.
Please visit http://www.openscad.org/index.html to install it.</source>
      <translation>لا يمكن العثور على OpenSCAD على النظام الخاص بك.
يرجى زيارة http://www.openscad.org/index.html لتثبيته.</translation>
    </message>
  </context>
  <context>
    <name>QDockWidget</name>
    <message>
      <location filename="../../DlgEvaluateMeshImp.cpp" line="1328"/>
      <source>Evaluate &amp; Repair Mesh</source>
      <translation>تقييم وإصلاح الشبكة</translation>
    </message>
  </context>
  <context>
    <name>QObject</name>
    <message>
      <location filename="../../AppMeshGui.cpp" line="157"/>
      <source>Display</source>
      <translation>عرض</translation>
    </message>
    <message>
      <location filename="../../AppMeshGui.cpp" line="159"/>
      <source>Import-Export</source>
      <translation>إستيراد-تصدير</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="336"/>
      <source>All Mesh Files</source>
      <translation>جميع ملفات الشبكة</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="337"/>
      <location filename="../../Command.cpp" line="397"/>
      <source>Binary STL</source>
      <translation>Binary STL</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="338"/>
      <location filename="../../Command.cpp" line="398"/>
      <location filename="../../Command.cpp" line="399"/>
      <source>ASCII STL</source>
      <translation>ASCII STL</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="339"/>
      <location filename="../../Command.cpp" line="400"/>
      <source>Binary Mesh</source>
      <translation>شبكة ثنائية</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="340"/>
      <location filename="../../Command.cpp" line="401"/>
      <source>Alias Mesh</source>
      <translation>الاسم المستعار للشبكة</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="341"/>
      <location filename="../../Command.cpp" line="403"/>
      <source>Object File Format</source>
      <translation>تنسيق ملف الكائن</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="342"/>
      <source>Inventor V2.1 ASCII</source>
      <translation type="unfinished">Inventor V2.1 ASCII</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="343"/>
      <location filename="../../Command.cpp" line="408"/>
      <source>Stanford Polygon</source>
      <translation>مضلع ستانفورد</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="344"/>
      <source>NASTRAN</source>
      <translation type="unfinished">NASTRAN</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="345"/>
      <location filename="../../Command.cpp" line="415"/>
      <source>All Files</source>
      <translation>كل الملفات</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="349"/>
      <source>Import mesh</source>
      <translation>استيراد شبكة</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="402"/>
      <source>Simple Model Format</source>
      <translation type="unfinished">Simple Model Format</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="404"/>
      <source>Inventor V2.1 ascii</source>
      <translation>المخترع V2.1 أسي</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="405"/>
      <source>X3D Extensible 3D</source>
      <translation type="unfinished">X3D Extensible 3D</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="406"/>
      <source>Compressed X3D</source>
      <translation type="unfinished">Compressed X3D</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="407"/>
      <source>WebGL/X3D</source>
      <translation type="unfinished">WebGL/X3D</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="409"/>
      <source>VRML V2.0</source>
      <translation type="unfinished">VRML V2.0</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="410"/>
      <source>Compressed VRML 2.0</source>
      <translation type="unfinished">Compressed VRML 2.0</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="411"/>
      <source>Nastran</source>
      <translation>ذو نزوات غريبة</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="412"/>
      <source>Python module def</source>
      <translation>بيثون وحدة نمطية الدفاع</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="413"/>
      <source>Asymptote Format</source>
      <translation type="unfinished">Asymptote Format</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="414"/>
      <source>3D Manufacturing Format</source>
      <translation type="unfinished">3D Manufacturing Format</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="424"/>
      <source>Export mesh</source>
      <translation>تصدير الشبكة</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="470"/>
      <source>Meshing Tolerance</source>
      <translation type="unfinished">Meshing Tolerance</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="471"/>
      <source>Enter tolerance for meshing geometry:</source>
      <translation type="unfinished">Enter tolerance for meshing geometry:</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1280"/>
      <source>The mesh '%1' is not a solid.</source>
      <translation>شبكة '%1' ليست صلبة.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1284"/>
      <source>The mesh '%1' is a solid.</source>
      <translation>شبكة '%1' هي صلبة.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1287"/>
      <source>Solid Mesh</source>
      <translation>شبكة صلبة</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1471"/>
      <source>Boundings</source>
      <translation type="unfinished">Boundings</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1537"/>
      <source>Fill holes</source>
      <translation>ملء الثقوب</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1538"/>
      <source>Fill holes with maximum number of edges:</source>
      <translation>ملء الثقوب مع الحد الأقصى لعدد الحواف:</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1804"/>
      <source>Scaling</source>
      <translation>تدريج</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1805"/>
      <source>Enter scaling factor:</source>
      <translation>أدخل عامل التحجيم:</translation>
    </message>
    <message>
      <location filename="../../PropertyEditorMesh.cpp" line="77"/>
      <source>[Points: %1, Edges: %2, Faces: %3]</source>
      <translation>[النقط: %1، الحواف: %2، الوجوه: %3]</translation>
    </message>
    <message>
      <location filename="../../ViewProvider.cpp" line="809"/>
      <source>Display components</source>
      <translation>عرض المكونات</translation>
    </message>
    <message>
      <location filename="../../ViewProvider.cpp" line="817"/>
      <source>Display segments</source>
      <translation type="unfinished">Display segments</translation>
    </message>
    <message>
      <location filename="../../ViewProvider.cpp" line="825"/>
      <source>Display colors</source>
      <translation type="unfinished">Display colors</translation>
    </message>
    <message>
      <location filename="../../ViewProvider.cpp" line="1687"/>
      <location filename="../../ViewProviderCurvature.cpp" line="522"/>
      <source>Leave info mode</source>
      <translation>ترك وضع المعلومات</translation>
    </message>
    <message>
      <location filename="../../ViewProvider.cpp" line="1754"/>
      <source>Index: %1</source>
      <translation>الفهرس:%1</translation>
    </message>
    <message>
      <location filename="../../ViewProvider.cpp" line="1780"/>
      <source>Leave hole-filling mode</source>
      <translation>ترك وضع ملء الحفرة</translation>
    </message>
    <message>
      <location filename="../../ViewProvider.cpp" line="1830"/>
      <source>Leave removal mode</source>
      <translation>اترك وضع الإزالة</translation>
    </message>
    <message>
      <location filename="../../ViewProvider.cpp" line="1831"/>
      <source>Delete selected faces</source>
      <translation>حذف الوجوه المحددة</translation>
    </message>
    <message>
      <location filename="../../ViewProvider.cpp" line="1832"/>
      <source>Clear selected faces</source>
      <translation>مسح الوجوه المحددة</translation>
    </message>
    <message>
      <location filename="../../ViewProviderCurvature.cpp" line="519"/>
      <source>Annotation</source>
      <translation>تعليق توضيحي</translation>
    </message>
  </context>
  <context>
    <name>Workbench</name>
    <message>
      <location filename="../../Workbench.cpp" line="43"/>
      <source>Analyze</source>
      <translation>تحليل</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="44"/>
      <source>Boolean</source>
      <translation>قيمة منطقية</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="45"/>
      <source>&amp;Meshes</source>
      <translation>&amp;الشبكات</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="46"/>
      <source>Cutting</source>
      <translation>تقطيع</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="47"/>
      <source>Mesh tools</source>
      <translation>أدوات الشبكة</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="48"/>
      <source>Mesh modify</source>
      <translation type="unfinished">Mesh modify</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="49"/>
      <source>Mesh boolean</source>
      <translation type="unfinished">Mesh boolean</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="50"/>
      <source>Mesh cutting</source>
      <translation type="unfinished">Mesh cutting</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="51"/>
      <source>Mesh segmentation</source>
      <translation>تجزئة الشبكة</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="52"/>
      <source>Mesh analyze</source>
      <translation type="unfinished">Mesh analyze</translation>
    </message>
  </context>
</TS>
