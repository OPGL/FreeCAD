<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="bg" sourcelanguage="en">
  <context>
    <name>UnitsApi</name>
    <message>
      <location filename="../../UnitsApi.cpp" line="58"/>
      <source>Standard (mm, kg, s, °)</source>
      <translation>Стандартна система (мм, кг, с, градус)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="60"/>
      <source>MKS (m, kg, s, °)</source>
      <translation>Метър-килограм-секунда (м, кг, с, градус)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="62"/>
      <source>US customary (in, lb)</source>
      <translation>Мерни единици за САЩ (инч, фунт)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="64"/>
      <source>Imperial decimal (in, lb)</source>
      <translation>Имперски десетично (инч, фунт)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="66"/>
      <source>Building Euro (cm, m², m³)</source>
      <translation>Градеж Евро (cm, m², m³)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="68"/>
      <source>Building US (ft-in, sqft, cft)</source>
      <translation>Градеж САЩ (ft-in, sqft, cft)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="70"/>
      <source>Metric small parts &amp; CNC (mm, mm/min)</source>
      <translation>Метрични малки части и ЦПУ (mm, mm/min)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="72"/>
      <source>Imperial for Civil Eng (ft, ft/s)</source>
      <translation>Имперски за граждански инж. (футове, фут./сек.)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="74"/>
      <source>FEM (mm, N, s)</source>
      <translation>Метод на крайните елементи (mm, N, s)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="76"/>
      <source>Meter decimal (m, m², m³)</source>
      <translation>Метрична десетична (m, m², m³)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="78"/>
      <source>Unknown schema</source>
      <translation>Неизвестна схема</translation>
    </message>
  </context>
</TS>
