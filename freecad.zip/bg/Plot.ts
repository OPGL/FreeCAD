<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="1.1" language="bg" sourcelanguage="en">
  <context>
    <name>Plot</name>
    <message>
      <location filename="InitGui.py" line="46"/>
      <source>Plot edition tools</source>
      <translation type="unfinished">Plot edition tools</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="49"/>
      <source>Plot</source>
      <translation type="unfinished">Plot</translation>
    </message>
  </context>
  <context>
    <name>Plot_Axes</name>
    <message>
      <location filename="PlotGui.py" line="65"/>
      <source>Configure axes</source>
      <translation>Настройване на осите</translation>
    </message>
    <message>
      <location filename="PlotGui.py" line="68"/>
      <source>Configure the axes parameters</source>
      <translation>Настройване на параметрите на осите</translation>
    </message>
  </context>
  <context>
    <name>Plot_Grid</name>
    <message>
      <location filename="PlotGui.py" line="112"/>
      <source>Show/Hide grid</source>
      <translation>Показване/скриване на решетката</translation>
    </message>
    <message>
      <location filename="PlotGui.py" line="115"/>
      <source>Show/Hide grid on selected plot</source>
      <translation type="unfinished">Show/Hide grid on selected plot</translation>
    </message>
  </context>
  <context>
    <name>Plot_Labels</name>
    <message>
      <location filename="PlotGui.py" line="155"/>
      <source>Set labels</source>
      <translation>Задаване на етикет</translation>
    </message>
    <message>
      <location filename="PlotGui.py" line="158"/>
      <source>Set title and axes labels</source>
      <translation>Задаване на заглавие и етикети на осите</translation>
    </message>
  </context>
  <context>
    <name>Plot_Legend</name>
    <message>
      <location filename="PlotGui.py" line="138"/>
      <source>Show/Hide legend</source>
      <translation>Показване/скриване на легендата</translation>
    </message>
    <message>
      <location filename="PlotGui.py" line="141"/>
      <source>Show/Hide legend on selected plot</source>
      <translation type="unfinished">Show/Hide legend on selected plot</translation>
    </message>
  </context>
  <context>
    <name>Plot_Positions</name>
    <message>
      <location filename="PlotGui.py" line="172"/>
      <source>Set positions and sizes</source>
      <translation>Задаване на положения и размери</translation>
    </message>
    <message>
      <location filename="PlotGui.py" line="175"/>
      <source>Set labels and legend positions and sizes</source>
      <translation>Задаване на етикети и легенда за положенията и размерите</translation>
    </message>
  </context>
  <context>
    <name>Plot_SaveFig</name>
    <message>
      <location filename="PlotGui.py" line="48"/>
      <source>Save plot</source>
      <translation>Съхраняване на чертежа</translation>
    </message>
    <message>
      <location filename="PlotGui.py" line="51"/>
      <source>Save the plot as an image file</source>
      <translation>Съхраняване на чертежа като изображение</translation>
    </message>
  </context>
  <context>
    <name>Plot_Series</name>
    <message>
      <location filename="PlotGui.py" line="84"/>
      <source>Configure series</source>
      <translation>Конфигуриране на поредицата</translation>
    </message>
    <message>
      <location filename="PlotGui.py" line="87"/>
      <source>Configure series drawing style and label</source>
      <translation type="unfinished">Configure series drawing style and label</translation>
    </message>
  </context>
  <context>
    <name>plot_axes</name>
    <message>
      <location filename="TaskPanel.py" line="180"/>
      <source>Configure axes</source>
      <translation>Настройване на осите</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="184"/>
      <source>Active axes</source>
      <translation>Активни оси</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="216"/>
      <source>Apply to all axes</source>
      <translation>Прилагане за всички оси</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="220"/>
      <source>Dimensions</source>
      <translation>Размерности</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="224"/>
      <source>X axis position</source>
      <translation>Положение по оста X</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="228"/>
      <source>Y axis position</source>
      <translation>Положение по оста Y</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="204"/>
      <source>Scales</source>
      <translation>Мащаб</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="208"/>
      <source>X auto</source>
      <translation>Автомащабиране по X</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="212"/>
      <source>Y auto</source>
      <translation>Автомащабиране по Y</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="232"/>
      <source>Index of the active axes</source>
      <translation>Показател с активните оси</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="237"/>
      <source>Add new axes to the plot</source>
      <translation type="unfinished">Add new axes to the plot</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="242"/>
      <source>Remove selected axes</source>
      <translation>Премахване на избраните оси</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="247"/>
      <source>Check it to apply transformations to all axes</source>
      <translation type="unfinished">Check it to apply transformations to all axes</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="252"/>
      <source>Left bound of axes</source>
      <translation type="unfinished">Left bound of axes</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="257"/>
      <source>Right bound of axes</source>
      <translation type="unfinished">Right bound of axes</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="262"/>
      <source>Bottom bound of axes</source>
      <translation type="unfinished">Bottom bound of axes</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="267"/>
      <source>Top bound of axes</source>
      <translation type="unfinished">Top bound of axes</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="272"/>
      <source>Outward offset of X axis</source>
      <translation type="unfinished">Outward offset of X axis</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="277"/>
      <source>Outward offset of Y axis</source>
      <translation type="unfinished">Outward offset of Y axis</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="282"/>
      <source>X axis scale autoselection</source>
      <translation type="unfinished">X axis scale autoselection</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="287"/>
      <source>Y axis scale autoselection</source>
      <translation type="unfinished">Y axis scale autoselection</translation>
    </message>
  </context>
  <context>
    <name>plot_console</name>
    <message>
      <location filename="Plot.py" line="47"/>
      <source>matplotlib not found, so Plot module can not be loaded</source>
      <translation type="unfinished">matplotlib not found, so Plot module can not be loaded</translation>
    </message>
    <message>
      <location filename="InitGui.py" line="58"/>
      <source>matplotlib not found, Plot module will be disabled</source>
      <translation type="unfinished">matplotlib not found, Plot module will be disabled</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="48"/>
      <source>Plot document must be selected in order to save it</source>
      <translation type="unfinished">Plot document must be selected in order to save it</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="346"/>
      <source>Axes 0 can not be deleted</source>
      <translation>Нулевата ос не може да бъде изтрита</translation>
    </message>
    <message>
      <location filename="PlotGui.py" line="101"/>
      <source>The grid must be activated on top of a plot document</source>
      <translation type="unfinished">The grid must be activated on top of a plot document</translation>
    </message>
    <message>
      <location filename="PlotGui.py" line="129"/>
      <source>The legend must be activated on top of a plot document</source>
      <translation type="unfinished">The legend must be activated on top of a plot document</translation>
    </message>
  </context>
  <context>
    <name>plot_labels</name>
    <message>
      <location filename="TaskPanel.py" line="138"/>
      <source>Set labels</source>
      <translation>Задаване на етикет</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="142"/>
      <source>Active axes</source>
      <translation>Активни оси</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="146"/>
      <source>Title</source>
      <translation>Заглавие</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="150"/>
      <source>X label</source>
      <translation>Етикет на X</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="154"/>
      <source>Y label</source>
      <translation>Етикет на Y</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="158"/>
      <source>Index of the active axes</source>
      <translation>Показател с активните оси</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="163"/>
      <source>Title (associated to active axes)</source>
      <translation>Заглавие (свързано с активни оси)</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="168"/>
      <source>Title font size</source>
      <translation>Големина на шрифта на заглавието</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="173"/>
      <source>X axis title</source>
      <translation>Заглавие на оста X</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="178"/>
      <source>X axis title font size</source>
      <translation type="unfinished">X axis title font size</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="183"/>
      <source>Y axis title</source>
      <translation>Заглавие на оста Y</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="188"/>
      <source>Y axis title font size</source>
      <translation type="unfinished">Y axis title font size</translation>
    </message>
  </context>
  <context>
    <name>plot_positions</name>
    <message>
      <location filename="TaskPanel.py" line="124"/>
      <source>Set positions and sizes</source>
      <translation>Задаване на положения и размери</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="129"/>
      <source>Position</source>
      <translation type="unfinished">Position</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="134"/>
      <source>Size</source>
      <translation>Големина</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="144"/>
      <source>X item position</source>
      <translation>Положение на елемента по оста X</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="149"/>
      <source>Y item position</source>
      <translation>Положение на елемента по оста Y</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="154"/>
      <source>Item size</source>
      <translation>Големина на елемента</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="139"/>
      <source>List of modifiable items</source>
      <translation>Списък с изменяеми елементи</translation>
    </message>
  </context>
  <context>
    <name>plot_save</name>
    <message>
      <location filename="TaskPanel.py" line="132"/>
      <source>Save figure</source>
      <translation>Запис на фигурата</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="137"/>
      <source>Inches</source>
      <translation>Инчове</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="142"/>
      <source>Dots per Inch</source>
      <translation>Точки за инч</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="147"/>
      <source>Output image file path</source>
      <translation type="unfinished">Output image file path</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="152"/>
      <source>Show a file selection dialog</source>
      <translation>Показване на прозорец за избор на файл</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="157"/>
      <source>X image size</source>
      <translation>Големина на изображението по X</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="162"/>
      <source>Y image size</source>
      <translation>Големина на изображението по Y</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="168"/>
      <source>Dots per point, with size will define output image resolution</source>
      <translation type="unfinished">Dots per point, with size will define output image resolution</translation>
    </message>
  </context>
  <context>
    <name>plot_series</name>
    <message>
      <location filename="TaskPanel.py" line="157"/>
      <source>No label</source>
      <translation>Няма етикет</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="192"/>
      <source>Line style</source>
      <translation>Стил на линията</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="172"/>
      <source>Marker</source>
      <translation>Маркер</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="152"/>
      <source>Configure series</source>
      <translation>Конфигуриране на поредицата</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="177"/>
      <source>List of available series</source>
      <translation>Списък с наличните поредици</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="182"/>
      <source>Line title</source>
      <translation>Заглавие на линията</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="197"/>
      <source>Marker style</source>
      <translation>Стил на маркера</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="202"/>
      <source>Line width</source>
      <translation>Ширина на линията</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="207"/>
      <source>Marker size</source>
      <translation>Големина на маркера</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="212"/>
      <source>Line and marker color</source>
      <translation>Цвят на линията и маркера</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="162"/>
      <source>Remove series</source>
      <translation>Премахване на поредица</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="187"/>
      <source>If checked, series will not be considered for legend</source>
      <translation>Ако е означено, то поредицата няма да се включва за легендата</translation>
    </message>
    <message>
      <location filename="TaskPanel.py" line="217"/>
      <source>Removes this series</source>
      <translation>Премахва тази поредица</translation>
    </message>
  </context>
</TS>
