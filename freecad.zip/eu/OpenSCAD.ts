<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="eu" sourcelanguage="en">
  <context>
    <name>Gui::Dialog::DlgSettingsOpenSCAD</name>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="14"/>
      <source>General settings</source>
      <translation>Ezarpen orokorrak</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="35"/>
      <source>General OpenSCAD Settings</source>
      <translation>OpenSCAD ezarpen orokorrak</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="43"/>
      <source>OpenSCAD executable</source>
      <translation>OpenSCAD exekutagarria</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="56"/>
      <source>The path to the OpenSCAD executable</source>
      <translation>OpenSCAD exkutagarriaren bidea</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="74"/>
      <source>OpenSCAD import</source>
      <translation>OpenSCAD inportazioa</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="82"/>
      <source>Print debug information in the Console</source>
      <translation>Inprimatu arazketa-informazioa kontsolan</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="99"/>
      <source>If this is checked, Features will claim their children in the tree view</source>
      <translation>Hau markatuta badago, elementuek zuhaitz-bistan dituzten haurrak erreklamatuko dituzte</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="102"/>
      <source>Use ViewProvider in Tree View</source>
      <translation>Erabili bista-hornitzailea zuhaitz-bistan</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="119"/>
      <source>If this is checked, Multmatrix Object will be Parametric</source>
      <translation>Hau markatuta badago, Multimatrix objektua parametrikoa izango da</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="122"/>
      <source>Use Multmatrix Feature</source>
      <translation>Erabili Multmatrix elementua</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="139"/>
      <location filename="../ui/openscadprefs-base.ui" line="162"/>
      <source>The maximum number of faces of a polygon, prism or frustum. If fn is greater than this value the object is considered to be a circular. Set to 0 for no limit</source>
      <translation>Poligono, prisma edo enbor baten aurpegi kopuru maximoa. fn balio hau baino handiagoa bada, objektua zirkularra dela kontsideratuko da. Ezarri 0 mugagabea ezartzeko</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="142"/>
      <source>Maximum number of faces for polygons (fn)</source>
      <translation>Aurpegi kopuru maximoa poligonoetarako (fn)</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="182"/>
      <source>Send to OpenSCAD via:</source>
      <translation>Bidali OpenSCADi honen bidez:</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="195"/>
      <source>The transfer mechanism for getting data to and from OpenSCAD</source>
      <translation>Datuak OpenSCADetik eta OpenSCADera transferitzeko mekanismoa</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="205"/>
      <source>Standard temp directory</source>
      <translation>Aldi baterako direktorio estandarra</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="210"/>
      <source>User-specified directory</source>
      <translation>Erabiltzaileak zehaztutako direktorioa</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="215"/>
      <source>stdout pipe (requires OpenSCAD &gt;= 2021.1)</source>
      <translation>stdout kanalizazioa (OpenSCAD &gt;= 2021.1 behar du)</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="227"/>
      <source>Transfer directory</source>
      <translation>Transferentzia-direktorioa</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="243"/>
      <source>The path to the directory for transferring files to and from OpenSCAD</source>
      <translation>Fitxategiak OpenSCADetik eta OpenSCADera transferitzeko direktorioaren bide-izena</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="261"/>
      <source>OpenSCAD export</source>
      <translation>OpenSCAD esportazioa</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="269"/>
      <source>Maximum fragment size</source>
      <translation>Zati-tamaina maximoa</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="292"/>
      <source>angle (fa)</source>
      <translation>angelua (fa)</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="388"/>
      <source>Convexity</source>
      <translation>Ganbiltasuna</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="289"/>
      <location filename="../ui/openscadprefs-base.ui" line="299"/>
      <source>Minimum angle for a fragment</source>
      <translation>Zati baten angelu minimoa</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="331"/>
      <location filename="../ui/openscadprefs-base.ui" line="356"/>
      <source>Minimum size of a fragment</source>
      <translation>Zati baten tamaina minimoa</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="334"/>
      <source>size (fs)</source>
      <translation>tamaina (fs)</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="362"/>
      <source>mm</source>
      <translation>mm</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="425"/>
      <source>Mesh fallback</source>
      <translation>Amaraunaren ordezkoa</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="445"/>
      <location filename="../ui/openscadprefs-base.ui" line="462"/>
      <source>Deflection</source>
      <translation>Makurdura</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="448"/>
      <source>deflection</source>
      <translation>makurdura</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="455"/>
      <source>Triangulation settings</source>
      <translation>Triangelaketa-ezarpenak</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD</name>
    <message>
      <location filename="../../InitGui.py" line="130"/>
      <source>It looks like you may be using a Snap version of OpenSCAD.</source>
      <translation>Agian OpenSCADen Snap bertsio bat erabiltzen ari zara.</translation>
    </message>
    <message>
      <location filename="../../InitGui.py" line="135"/>
      <location filename="../../InitGui.py" line="148"/>
      <source>If OpenSCAD execution fails to load the temporary file, use FreeCAD's OpenSCAD Workbench Preferences to change the transfer mechanism.</source>
      <translation>OpenSCAD exekuzioan aldi baterako fitxategia kargatzeak huts egiten badu, erabili FreeCADen OpenSCAD lan-mahaien hobespenak transferentzia-mekanismoa aldatzeko.</translation>
    </message>
    <message>
      <location filename="../../InitGui.py" line="143"/>
      <source>It looks like you may be using a sandboxed version of FreeCAD.</source>
      <translation>Agian OpenSCADen bertsio isolatu bat erabiltzen ari zara.</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="92"/>
      <source>Unable to explode %s</source>
      <translation>Ezin izan da %s lehertu</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="139"/>
      <source>Convert Edges to Faces</source>
      <translation>Bihurtu ertzak aurpegi</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="301"/>
      <source>Please select 3 objects first</source>
      <translation>Lehenengo, hautatu 3 objektu</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="334"/>
      <location filename="../../OpenSCADCommands.py" line="365"/>
      <source>Add</source>
      <translation>Gehitu</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="369"/>
      <source>Clear</source>
      <translation>Garbitu</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="366"/>
      <source>Load</source>
      <translation>Kargatu</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="367"/>
      <source>Save</source>
      <translation>Gorde</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="335"/>
      <location filename="../../OpenSCADCommands.py" line="368"/>
      <source>Refresh</source>
      <translation>Freskatu</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="336"/>
      <source>Clear code</source>
      <translation>Garbitu kodea</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="337"/>
      <source>Open...</source>
      <translation>Ireki...</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="338"/>
      <source>Save...</source>
      <translation>Gorde...</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="339"/>
      <location filename="../../OpenSCADCommands.py" line="370"/>
      <source>as Mesh</source>
      <translation>amaraun gisa</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="352"/>
      <location filename="../../OpenSCADCommands.py" line="371"/>
      <source>Add OpenSCAD Element</source>
      <translation>Ireki OpenSCAD elementua</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="428"/>
      <source>Open file</source>
      <translation>Ireki fitxategia</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="430"/>
      <location filename="../../OpenSCADCommands.py" line="444"/>
      <source>OpenSCAD Files</source>
      <translation>OpenSCAD fitxategiak</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="442"/>
      <source>Save file</source>
      <translation>Gorde fitxategia</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="456"/>
      <location filename="../../OpenSCADCommands.py" line="485"/>
      <source>Perform</source>
      <translation>Egin</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="482"/>
      <location filename="../../OpenSCADCommands.py" line="486"/>
      <source>Mesh Boolean</source>
      <translation>Amaraun boolearra</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="487"/>
      <source>Minkowski sum</source>
      <translation>Minkowski batuketa</translation>
    </message>
    <message>
      <location filename="../../OpenSCADUtils.py" line="654"/>
      <source>OpenSCAD file contains both 2D and 3D shapes. That is not supported in this importer, all shapes must have the same dimensionality.</source>
      <translation>OpenSCAD fitxategiak 2D eta 3D formak ditu. Hori ez da onartzen inportatzaile honetan, forma guztiek dimentsio bera izan behar dute.</translation>
    </message>
    <message>
      <location filename="../../OpenSCADUtils.py" line="665"/>
      <source>Error: either all shapes must be 2D or all shapes must be 3D</source>
      <translation>Errorea: forma guztiek 3D izan behar dute edo 3D izan behar dute</translation>
    </message>
    <message>
      <location filename="../../importCSG.py" line="549"/>
      <location filename="../../importCSG.py" line="1434"/>
      <source>Unsupported Function</source>
      <translation>Onartzen ez den funtzioa</translation>
    </message>
    <message>
      <location filename="../../importCSG.py" line="549"/>
      <location filename="../../importCSG.py" line="1434"/>
      <source>Press OK</source>
      <translation>Sakatu 'Ados'</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_ExplodeGroup</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="100"/>
      <source>Explode Group</source>
      <translation>Lehertu taldea</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="103"/>
      <source>Remove fusion, apply placement to children, and color randomly</source>
      <translation>Kendu fusioa, aplikatu kokapena haurrei, eta koloreztatu ausaz</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_ColorCodeShape</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="116"/>
      <source>Color Shapes</source>
      <translation>Koloreztatu formak</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="119"/>
      <source>Color Shapes by validity and type</source>
      <translation>Koloreztatu formak baliozkotasunaren eta motaren arabera</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_Edgestofaces</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="136"/>
      <source>Convert Edges To Faces</source>
      <translation>Bihurtu ertzak aurpegi</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_RefineShapeFeature</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="156"/>
      <source>Refine Shape Feature</source>
      <translation>Forma finduko elementua</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="159"/>
      <source>Create Refine Shape Feature</source>
      <translation>Sortu forma finduko elementua</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_MirrorMeshFeature</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="186"/>
      <source>Mirror Mesh Feature...</source>
      <translation>Ispilatu amaraun-elementua...</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="189"/>
      <source>Create Mirror Mesh Feature</source>
      <translation>Sortu amaraun-elementuaren ispilatzea</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_ScaleMeshFeature</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="215"/>
      <source>Scale Mesh Feature...</source>
      <translation>Eskalatu amaraun-elementua...</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="219"/>
      <source>Create Scale Mesh Feature</source>
      <translation>Sortu amaraun-elementuaren eskala aldatzea</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_ResizeMeshFeature</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="245"/>
      <source>Resize Mesh Feature...</source>
      <translation>Aldatu amaraun-elementuaren tamaina...</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="249"/>
      <source>Create Resize Mesh Feature</source>
      <translation>Sortu amaraun-elementuaren tamaina aldaketa</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_IncreaseToleranceFeature</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="266"/>
      <source>Increase Tolerance Feature</source>
      <translation>Handitu tolerantzia-elementua</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="269"/>
      <source>Create Feature that allows increasing the tolerance</source>
      <translation>Sortu tolerantzia handitzea ahalbidetzen duen elementua</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_ExpandPlacements</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="283"/>
      <source>Expand Placements</source>
      <translation>Hedatu kokapenak</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="286"/>
      <source>Expand all placements downwards in the Tree view</source>
      <translation>Hedatu kokapen guztiak zuhaitz-bistan beherantz</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_ReplaceObject</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="304"/>
      <source>Replace Object</source>
      <translation>Ordeztu objektua</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="307"/>
      <source>Replace an object in the Tree view. Please select old, new, and parent object</source>
      <translation>Ordeztu objektu bat zuhaitz-bistan. Hautatu objektu zaharra, berria eta gurasoa</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_RemoveSubtree</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="317"/>
      <source>Remove Objects and their Children</source>
      <translation>Kendu objektuak eta haien haurrak</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="320"/>
      <source>Removes the selected objects and all children that are not referenced from other objects</source>
      <translation>Beste objektu batzuetan erreferentzia ez duten hautatutako objektuak eta haien haurrak kentzen ditu</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_AddOpenSCADElement</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="530"/>
      <source>Add OpenSCAD Element...</source>
      <translation>Gehitu OpenSCAD elementua...</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="534"/>
      <source>Add an OpenSCAD element by entering OpenSCAD code and executing the OpenSCAD binary</source>
      <translation>Gehitu OpenSCAD elementu bat OpenSCAD kodea sartuz eta OpenSCAD bitarra exekutatuz</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_MeshBoolean</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="545"/>
      <source>Mesh Boolean...</source>
      <translation>Amaraun boolearra...</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="549"/>
      <source>Export objects as meshes and use OpenSCAD to perform a boolean operation</source>
      <translation>Esportatu objektuak amaraun gisa eta erabili OpenSCAD eragiketa boolearra egiteko</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_Hull</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="566"/>
      <source>Hull</source>
      <translation>Krosko</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="569"/>
      <source>Use OpenSCAD to create a hull</source>
      <translation>Erabili OpenSCAD krosko bat sortzeko</translation>
    </message>
  </context>
  <context>
    <name>Workbench</name>
    <message>
      <location filename="../../InitGui.py" line="152"/>
      <source>OpenSCAD Tools</source>
      <translation>OpenSCAD tresnak</translation>
    </message>
    <message>
      <location filename="../../InitGui.py" line="156"/>
      <source>Frequently-used Part WB tools</source>
      <translation>Sarritan erabilitako piezen WB tresnak</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_Minkowski</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="586"/>
      <source>Minkowski sum</source>
      <translation>Minkowski batuketa</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="589"/>
      <source>Use OpenSCAD to create a Minkowski sum</source>
      <translation>Erabili OpenSCAD Minkowski batuketa bat sortzeko</translation>
    </message>
  </context>
</TS>
