<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="eu" sourcelanguage="en">
  <context>
    <name>NavigationIndicator</name>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="85"/>
      <source>Select</source>
      <translation>Hautatu</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="86"/>
      <source>Zoom</source>
      <translation>Zooma</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="87"/>
      <source>Rotate</source>
      <translation>Biratu</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="88"/>
      <source>Pan</source>
      <translation>Mugitu ezker-eskuin</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="89"/>
      <source>Tilt</source>
      <translation>Inklinatu</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="90"/>
      <source>Navigation style</source>
      <translation>Nabigazio-estiloa</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="91"/>
      <source>Page Up or Page Down key.</source>
      <translation>Page Up edo Page Down tekla.</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="92"/>
      <source>Rotation focus</source>
      <translation>Biraketa-fokua</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="93"/>
      <source>Middle mouse button or H key.</source>
      <translation>Saguaren erdiko botoia edo H tekla.</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="95"/>
      <source>Middle mouse button.</source>
      <translation>Saguaren erdiko botoia.</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="98"/>
      <source>Navigation style not recognized.</source>
      <translation>Nabigazio-estiloa ez da onartzen.</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="569"/>
      <source>Settings</source>
      <translation>Ezarpenak</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="570"/>
      <source>Orbit style</source>
      <translation>Orbita-estiloa</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="571"/>
      <source>Compact</source>
      <translation>Trinkoa</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="572"/>
      <source>Tooltip</source>
      <translation>Argibidea</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="573"/>
      <source>Turntable</source>
      <translation>Tornua</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="574"/>
      <source>Free Turntable</source>
      <translation>Tornu librea</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="575"/>
      <source>Trackball</source>
      <translation>Trackball</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="576"/>
      <source>Undefined</source>
      <translation>Definitu gabea</translation>
    </message>
  </context>
</TS>
