<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="af" sourcelanguage="en">
  <context>
    <name>NavigationIndicator</name>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="85"/>
      <source>Select</source>
      <translation>Kies</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="86"/>
      <source>Zoom</source>
      <translation>Vergroot</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="87"/>
      <source>Rotate</source>
      <translation>Roteer</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="88"/>
      <source>Pan</source>
      <translation>Verskuif</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="89"/>
      <source>Tilt</source>
      <translation>Draai</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="90"/>
      <source>Navigation style</source>
      <translation>Navigeer styl</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="91"/>
      <source>Page Up or Page Down key.</source>
      <translation>"Page Up" of "Page Down" sleutel.</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="92"/>
      <source>Rotation focus</source>
      <translation>Rotasie fokus</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="93"/>
      <source>Middle mouse button or H key.</source>
      <translation>Middel muis knoppie of H sleutel.</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="95"/>
      <source>Middle mouse button.</source>
      <translation>Middel muis knoppie.</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="98"/>
      <source>Navigation style not recognized.</source>
      <translation>Navigeer styl is nie herken nie.</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="569"/>
      <source>Settings</source>
      <translation>Instellings</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="570"/>
      <source>Orbit style</source>
      <translation>Wentelbaanstyl</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="571"/>
      <source>Compact</source>
      <translation>Kompak</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="572"/>
      <source>Tooltip</source>
      <translation>Nutswenk</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="573"/>
      <source>Turntable</source>
      <translation>Draaitafel</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="574"/>
      <source>Free Turntable</source>
      <translation type="unfinished">Free Turntable</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="575"/>
      <source>Trackball</source>
      <translation>Spoorbal</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="576"/>
      <source>Undefined</source>
      <translation>Ongedefinieërd</translation>
    </message>
  </context>
</TS>
