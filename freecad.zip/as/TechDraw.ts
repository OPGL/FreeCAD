<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="as" sourcelanguage="en">
  <context>
    <name>Cmd2LineCenterLine</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="659"/>
      <source>Add Centerline between 2 Lines</source>
      <translation type="unfinished">Add Centerline between 2 Lines</translation>
    </message>
  </context>
  <context>
    <name>Cmd2PointCenterLine</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="663"/>
      <source>Add Centerline between 2 Points</source>
      <translation type="unfinished">Add Centerline between 2 Points</translation>
    </message>
  </context>
  <context>
    <name>CmdMidpoints</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="285"/>
      <source>Add Midpoint Vertices</source>
      <translation type="unfinished">Add Midpoint Vertices</translation>
    </message>
  </context>
  <context>
    <name>CmdQuadrants</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="289"/>
      <source>Add Quadrant Vertices</source>
      <translation type="unfinished">Add Quadrant Vertices</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDraw2LineCenterLine</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="795"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="796"/>
      <source>Add Centerline between 2 Lines</source>
      <translation type="unfinished">Add Centerline between 2 Lines</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDraw2PointCenterLine</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="870"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="871"/>
      <source>Add Centerline between 2 Points</source>
      <translation type="unfinished">Add Centerline between 2 Points</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDraw2PointCosmeticLine</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="983"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="984"/>
      <source>Add Cosmetic Line Through 2 Points</source>
      <translation type="unfinished">Add Cosmetic Line Through 2 Points</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDraw3PtAngleDimension</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1787"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1788"/>
      <source>Insert 3-Point Angle Dimension</source>
      <translation type="unfinished">Insert 3-Point Angle Dimension</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawActiveView</name>
    <message>
      <location filename="../../Command.cpp" line="699"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="700"/>
      <source>Insert Active View (3D View)</source>
      <translation type="unfinished">Insert Active View (3D View)</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawAngleDimension</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1740"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1741"/>
      <source>Insert Angle Dimension</source>
      <translation type="unfinished">Insert Angle Dimension</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawAnnotation</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="531"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="532"/>
      <source>Insert Annotation</source>
      <translation type="unfinished">Insert Annotation</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawArchView</name>
    <message>
      <location filename="../../Command.cpp" line="1662"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1663"/>
      <source>Insert BIM Workbench Object</source>
      <translation type="unfinished">Insert BIM Workbench Object</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1664"/>
      <source>Insert a View of a Section Plane from BIM Workbench</source>
      <translation type="unfinished">Insert a View of a Section Plane from BIM Workbench</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawBalloon</name>
    <message>
      <location filename="../../Command.cpp" line="1276"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1277"/>
      <source>Insert Balloon Annotation</source>
      <translation type="unfinished">Insert Balloon Annotation</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawCenterLineGroup</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="581"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="582"/>
      <source>Insert Center Line</source>
      <translation type="unfinished">Insert Center Line</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="655"/>
      <source>Add Centerline to Faces</source>
      <translation type="unfinished">Add Centerline to Faces</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawClipGroup</name>
    <message>
      <location filename="../../Command.cpp" line="1340"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1341"/>
      <source>Insert Clip Group</source>
      <translation type="unfinished">Insert Clip Group</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawClipGroupAdd</name>
    <message>
      <location filename="../../Command.cpp" line="1377"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1378"/>
      <source>Add View to Clip Group</source>
      <translation type="unfinished">Add View to Clip Group</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawClipGroupRemove</name>
    <message>
      <location filename="../../Command.cpp" line="1461"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1462"/>
      <source>Remove View from Clip Group</source>
      <translation type="unfinished">Remove View from Clip Group</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawComplexSection</name>
    <message>
      <location filename="../../Command.cpp" line="884"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="885"/>
      <source>Insert Complex Section View</source>
      <translation type="unfinished">Insert Complex Section View</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="886"/>
      <source>Insert a Complex Section View</source>
      <translation type="unfinished">Insert a Complex Section View</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawCosmeticEraser</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1288"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1289"/>
      <source>Remove Cosmetic Object</source>
      <translation type="unfinished">Remove Cosmetic Object</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawCosmeticVertex</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="392"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="393"/>
      <source>Add Cosmetic Vertex</source>
      <translation type="unfinished">Add Cosmetic Vertex</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawCosmeticVertexGroup</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="205"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="206"/>
      <source>Insert Cosmetic Vertex</source>
      <translation type="unfinished">Insert Cosmetic Vertex</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="281"/>
      <source>Add Cosmetic Vertex</source>
      <translation type="unfinished">Add Cosmetic Vertex</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawDecorateLine</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1406"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1407"/>
      <source>Change Appearance of Lines</source>
      <translation type="unfinished">Change Appearance of Lines</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1408"/>
      <source>Change Appearance of selected Lines</source>
      <translation type="unfinished">Change Appearance of selected Lines</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawDetailView</name>
    <message>
      <location filename="../../Command.cpp" line="1010"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1011"/>
      <source>Insert Detail View</source>
      <translation type="unfinished">Insert Detail View</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawDiameterDimension</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1549"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1550"/>
      <source>Insert Diameter Dimension</source>
      <translation type="unfinished">Insert Diameter Dimension</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawDimension</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1408"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1409"/>
      <source>Insert Dimension</source>
      <translation type="unfinished">Insert Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1410"/>
      <source>Dimension contextually based on your selection.
Depending on your selection you might have several dimensions available. You can cycle through them using the M key.
Left clicking on empty space will validate the current Dimension. Right clicking or pressing Esc will cancel.</source>
      <translation type="unfinished">Dimension contextually based on your selection.
Depending on your selection you might have several dimensions available. You can cycle through them using the M key.
Left clicking on empty space will validate the current Dimension. Right clicking or pressing Esc will cancel.</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawDraftView</name>
    <message>
      <location filename="../../Command.cpp" line="1599"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1600"/>
      <source>Insert Draft Workbench Object</source>
      <translation type="unfinished">Insert Draft Workbench Object</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1601"/>
      <source>Insert a View of a Draft Workbench object</source>
      <translation type="unfinished">Insert a View of a Draft Workbench object</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExportPageDXF</name>
    <message>
      <location filename="../../Command.cpp" line="1849"/>
      <source>File</source>
      <translation type="unfinished">File</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1850"/>
      <source>Export Page as DXF</source>
      <translation type="unfinished">Export Page as DXF</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1884"/>
      <source>Save DXF file</source>
      <translation type="unfinished">Save DXF file</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExportPageSVG</name>
    <message>
      <location filename="../../Command.cpp" line="1806"/>
      <source>File</source>
      <translation type="unfinished">File</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1807"/>
      <source>Export Page as SVG</source>
      <translation type="unfinished">Export Page as SVG</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtendShortenLineGroup</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1661"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1662"/>
      <source>Extend Line</source>
      <translation type="unfinished">Extend Line</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1663"/>
      <source>Extend a cosmetic line or centerline at both ends:&lt;br&gt;- Specify the delta distance (optional)&lt;br&gt;- Select a single line&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Extend a cosmetic line or centerline at both ends:&lt;br&gt;- Specify the delta distance (optional)&lt;br&gt;- Select a single line&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionAreaAnnotation</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1765"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1766"/>
      <source>Calculate the area of selected faces</source>
      <translation type="unfinished">Calculate the area of selected faces</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1767"/>
      <source>Select several faces then click this tool</source>
      <translation type="unfinished">Select several faces then click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCascadeDimensionGroup</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1154"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1155"/>
      <source>Cascade Horizontal Dimensions</source>
      <translation type="unfinished">Cascade Horizontal Dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1156"/>
      <source>Evenly space horizontal dimensions:&lt;br&gt;- Specify the cascade spacing (optional)&lt;br&gt;- Select two or more horizontal dimensions&lt;br&gt;- The first dimension defines the position&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Evenly space horizontal dimensions:&lt;br&gt;- Specify the cascade spacing (optional)&lt;br&gt;- Select two or more horizontal dimensions&lt;br&gt;- The first dimension defines the position&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCascadeHorizDimension</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="976"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="977"/>
      <location filename="../../CommandExtensionDims.cpp" line="1231"/>
      <source>Cascade Horizontal Dimensions</source>
      <translation type="unfinished">Cascade Horizontal Dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="978"/>
      <location filename="../../CommandExtensionDims.cpp" line="1232"/>
      <source>Evenly space horizontal dimensions:&lt;br&gt;- Specify the cascade spacing (optional)&lt;br&gt;- Select two or more horizontal dimensions&lt;br&gt;- The first dimension defines the position&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Evenly space horizontal dimensions:&lt;br&gt;- Specify the cascade spacing (optional)&lt;br&gt;- Select two or more horizontal dimensions&lt;br&gt;- The first dimension defines the position&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCascadeObliqueDimension</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1118"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1119"/>
      <location filename="../../CommandExtensionDims.cpp" line="1249"/>
      <source>Cascade Oblique Dimensions</source>
      <translation type="unfinished">Cascade Oblique Dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1120"/>
      <location filename="../../CommandExtensionDims.cpp" line="1250"/>
      <source>Evenly space oblique dimensions:&lt;br&gt;- Specify the cascade spacing (optional)&lt;br&gt;- Select two or more parallel oblique dimensions&lt;br&gt;- The first dimension defines the position&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Evenly space oblique dimensions:&lt;br&gt;- Specify the cascade spacing (optional)&lt;br&gt;- Select two or more parallel oblique dimensions&lt;br&gt;- The first dimension defines the position&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCascadeVertDimension</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1043"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1044"/>
      <location filename="../../CommandExtensionDims.cpp" line="1240"/>
      <source>Cascade Vertical Dimensions</source>
      <translation type="unfinished">Cascade Vertical Dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1045"/>
      <location filename="../../CommandExtensionDims.cpp" line="1241"/>
      <source>Evenly space vertical dimensions:&lt;br&gt;- Specify the cascade spacing (optional)&lt;br&gt;- Select two or more vertical dimensions&lt;br&gt;- The first dimension defines the position&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Evenly space vertical dimensions:&lt;br&gt;- Specify the cascade spacing (optional)&lt;br&gt;- Select two or more vertical dimensions&lt;br&gt;- The first dimension defines the position&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionChamferDimensionGroup</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2184"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2185"/>
      <source>Create Horizontal Chamfer Dimension</source>
      <translation type="unfinished">Create Horizontal Chamfer Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2186"/>
      <source>Create a horizontal size and angle dimension for a chamfer:&lt;br&gt;- Select two vertexes&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Create a horizontal size and angle dimension for a chamfer:&lt;br&gt;- Select two vertexes&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionChangeLineAttributes</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="779"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="780"/>
      <source>Change Line Attributes</source>
      <translation type="unfinished">Change Line Attributes</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="781"/>
      <source>Change the attributes of cosmetic lines and centerlines:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select one or more lines&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Change the attributes of cosmetic lines and centerlines:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select one or more lines&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCircleCenterLines</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="247"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="248"/>
      <location filename="../../CommandExtensionPack.cpp" line="351"/>
      <source>Add Circle Centerlines</source>
      <translation type="unfinished">Add Circle Centerlines</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="249"/>
      <location filename="../../CommandExtensionPack.cpp" line="352"/>
      <source>Add centerlines to circles and arcs:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select one or more circles or arcs&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add centerlines to circles and arcs:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select one or more circles or arcs&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCircleCenterLinesGroup</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="281"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="282"/>
      <source>Add Circle Centerlines</source>
      <translation type="unfinished">Add Circle Centerlines</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="283"/>
      <source>Add centerlines to circles and arcs:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select one or more circles or arcs&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add centerlines to circles and arcs:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select one or more circles or arcs&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCreateChainDimensionGroup</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1532"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1533"/>
      <source>Create Horizontal Chain Dimensions</source>
      <translation type="unfinished">Create Horizontal Chain Dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1534"/>
      <source>Create a sequence of aligned horizontal dimensions:&lt;br&gt;- Select three or more vertexes&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Create a sequence of aligned horizontal dimensions:&lt;br&gt;- Select three or more vertexes&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCreateCoordDimensionGroup</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1923"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1924"/>
      <source>Create Horizontal Coordinate Dimensions</source>
      <translation type="unfinished">Create Horizontal Coordinate Dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1925"/>
      <source>Create multiple evenly spaced horizontal dimensions starting from the same baseline:&lt;br&gt;- Specify the cascade spacing (optional)&lt;br&gt;- Select three or more vertexes&lt;br&gt;- The selection order of the first two vertexes determines the position of the baseline&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Create multiple evenly spaced horizontal dimensions starting from the same baseline:&lt;br&gt;- Specify the cascade spacing (optional)&lt;br&gt;- Select three or more vertexes&lt;br&gt;- The selection order of the first two vertexes determines the position of the baseline&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCreateHorizChainDimension</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1308"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1309"/>
      <location filename="../../CommandExtensionDims.cpp" line="1607"/>
      <source>Create Horizontal Chain Dimensions</source>
      <translation type="unfinished">Create Horizontal Chain Dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1310"/>
      <location filename="../../CommandExtensionDims.cpp" line="1608"/>
      <source>Create a sequence of aligned horizontal dimensions:&lt;br&gt;- Select three or more vertexes&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Create a sequence of aligned horizontal dimensions:&lt;br&gt;- Select three or more vertexes&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCreateHorizChamferDimension</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2082"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2083"/>
      <location filename="../../CommandExtensionDims.cpp" line="2252"/>
      <source>Create Horizontal Chamfer Dimension</source>
      <translation type="unfinished">Create Horizontal Chamfer Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2084"/>
      <location filename="../../CommandExtensionDims.cpp" line="2253"/>
      <source>Create a horizontal size and angle dimension for a chamfer:&lt;br&gt;- Select two vertexes&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Create a horizontal size and angle dimension for a chamfer:&lt;br&gt;- Select two vertexes&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCreateHorizCoordDimension</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1685"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1686"/>
      <location filename="../../CommandExtensionDims.cpp" line="2000"/>
      <source>Create Horizontal Coordinate Dimensions</source>
      <translation type="unfinished">Create Horizontal Coordinate Dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1687"/>
      <location filename="../../CommandExtensionDims.cpp" line="2001"/>
      <source>Create multiple evenly spaced horizontal dimensions starting from the same baseline:&lt;br&gt;- Specify the cascade spacing (optional)&lt;br&gt;- Select three or more vertexes&lt;br&gt;- The selection order of the first two vertexes determines the position of the baseline&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Create multiple evenly spaced horizontal dimensions starting from the same baseline:&lt;br&gt;- Specify the cascade spacing (optional)&lt;br&gt;- Select three or more vertexes&lt;br&gt;- The selection order of the first two vertexes determines the position of the baseline&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCreateLengthArc</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2284"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2285"/>
      <source>Create Arc Length Dimension</source>
      <translation type="unfinished">Create Arc Length Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2286"/>
      <source>Create an arc length dimension:&lt;br&gt;- Select a single arc&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Create an arc length dimension:&lt;br&gt;- Select a single arc&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCreateObliqueChainDimension</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1498"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1499"/>
      <location filename="../../CommandExtensionDims.cpp" line="1621"/>
      <source>Create Oblique Chain Dimensions</source>
      <translation type="unfinished">Create Oblique Chain Dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1500"/>
      <location filename="../../CommandExtensionDims.cpp" line="1622"/>
      <source>Create a sequence of aligned oblique dimensions:&lt;br&gt;- Select three or more vertexes&lt;br&gt;- The first two vertexes define the direction&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Create a sequence of aligned oblique dimensions:&lt;br&gt;- Select three or more vertexes&lt;br&gt;- The first two vertexes define the direction&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCreateObliqueCoordDimension</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1887"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1888"/>
      <location filename="../../CommandExtensionDims.cpp" line="2018"/>
      <source>Create Oblique Coordinate Dimensions</source>
      <translation type="unfinished">Create Oblique Coordinate Dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1889"/>
      <location filename="../../CommandExtensionDims.cpp" line="2019"/>
      <source>Create multiple evenly spaced oblique dimensions starting from the same baseline:&lt;br&gt;- Specify the cascade spacing (optional)&lt;br&gt;- Select three or more vertexes&lt;br&gt;- The selection order of the first two vertexes determines the position of the baseline&lt;br&gt;- The first two vertexes also define the direction&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Create multiple evenly spaced oblique dimensions starting from the same baseline:&lt;br&gt;- Specify the cascade spacing (optional)&lt;br&gt;- Select three or more vertexes&lt;br&gt;- The selection order of the first two vertexes determines the position of the baseline&lt;br&gt;- The first two vertexes also define the direction&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCreateVertChainDimension</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1375"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1376"/>
      <location filename="../../CommandExtensionDims.cpp" line="1614"/>
      <source>Create Vertical Chain Dimensions</source>
      <translation type="unfinished">Create Vertical Chain Dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1377"/>
      <location filename="../../CommandExtensionDims.cpp" line="1615"/>
      <source>Create a sequence of aligned vertical dimensions:&lt;br&gt;- Select three or more vertexes&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Create a sequence of aligned vertical dimensions:&lt;br&gt;- Select three or more vertexes&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCreateVertChamferDimension</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2151"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2152"/>
      <location filename="../../CommandExtensionDims.cpp" line="2259"/>
      <source>Create Vertical Chamfer Dimension</source>
      <translation type="unfinished">Create Vertical Chamfer Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2153"/>
      <location filename="../../CommandExtensionDims.cpp" line="2260"/>
      <source>Create a vertical size and angle dimension for a chamfer:&lt;br&gt;- Select two vertexes&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Create a vertical size and angle dimension for a chamfer:&lt;br&gt;- Select two vertexes&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCreateVertCoordDimension</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1758"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1759"/>
      <location filename="../../CommandExtensionDims.cpp" line="2009"/>
      <source>Create Vertical Coordinate Dimensions</source>
      <translation type="unfinished">Create Vertical Coordinate Dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1760"/>
      <location filename="../../CommandExtensionDims.cpp" line="2010"/>
      <source>Create multiple evenly spaced vertical dimensions starting from the same baseline:&lt;br&gt;- Specify the cascade spacing (optional)&lt;br&gt;- Select three or more vertexes&lt;br&gt;- The selection order of the first two vertexes determines the position of the baseline&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Create multiple evenly spaced vertical dimensions starting from the same baseline:&lt;br&gt;- Specify the cascade spacing (optional)&lt;br&gt;- Select three or more vertexes&lt;br&gt;- The selection order of the first two vertexes determines the position of the baseline&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionCustomizeFormat</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2335"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2336"/>
      <source>Customize Format Label</source>
      <translation type="unfinished">Customize Format Label</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2337"/>
      <source>Select a dimension or a balloon&lt;br&gt;    - click this tool&lt;br&gt;    - edit the Format field, using the keyboard and/or the special buttons</source>
      <translation type="unfinished">Select a dimension or a balloon&lt;br&gt;    - click this tool&lt;br&gt;    - edit the Format field, using the keyboard and/or the special buttons</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionDecreaseDecimal</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="503"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="504"/>
      <location filename="../../CommandExtensionDims.cpp" line="611"/>
      <source>Decrease Decimal Places</source>
      <translation type="unfinished">Decrease Decimal Places</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="505"/>
      <location filename="../../CommandExtensionDims.cpp" line="612"/>
      <source>Decrease the number of decimal places of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Decrease the number of decimal places of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionDrawCirclesGroup</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1105"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1106"/>
      <source>Add Cosmetic Circle</source>
      <translation type="unfinished">Add Cosmetic Circle</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1107"/>
      <source>Add a cosmetic circle based on two vertexes:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select vertex 1 (center point)&lt;br&gt;- Select vertex 2 (radius)&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add a cosmetic circle based on two vertexes:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select vertex 1 (center point)&lt;br&gt;- Select vertex 2 (radius)&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionDrawCosmArc</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="940"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="941"/>
      <location filename="../../CommandExtensionPack.cpp" line="1193"/>
      <source>Add Cosmetic Arc</source>
      <translation type="unfinished">Add Cosmetic Arc</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="942"/>
      <location filename="../../CommandExtensionPack.cpp" line="1195"/>
      <source>Add a cosmetic counter clockwise arc based on three vertexes:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select vertex 1 (center point)&lt;br&gt;- Select vertex 2 (radius and start angle)&lt;br&gt;- Select vertex 3 (end angle)&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add a cosmetic counter clockwise arc based on three vertexes:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select vertex 1 (center point)&lt;br&gt;- Select vertex 2 (radius and start angle)&lt;br&gt;- Select vertex 3 (end angle)&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionDrawCosmCircle</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1004"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1005"/>
      <location filename="../../CommandExtensionPack.cpp" line="1184"/>
      <source>Add Cosmetic Circle</source>
      <translation type="unfinished">Add Cosmetic Circle</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1006"/>
      <location filename="../../CommandExtensionPack.cpp" line="1185"/>
      <source>Add a cosmetic circle based on two vertexes:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select vertex 1 (center point)&lt;br&gt;- Select vertex 2 (radius)&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add a cosmetic circle based on two vertexes:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select vertex 1 (center point)&lt;br&gt;- Select vertex 2 (radius)&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionDrawCosmCircle3Points</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1070"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1071"/>
      <location filename="../../CommandExtensionPack.cpp" line="1204"/>
      <source>Add Cosmetic Circle 3 Points</source>
      <translation type="unfinished">Add Cosmetic Circle 3 Points</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1072"/>
      <source>Add a cosmetic circle based on three vertexes:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select 3 vertexes&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add a cosmetic circle based on three vertexes:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select 3 vertexes&lt;br&gt;- Click this tool</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1206"/>
      <source>Add a cosmetic circle based on three vertexes:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select three vertexes&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add a cosmetic circle based on three vertexes:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select three vertexes&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionExtendLine</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1591"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1592"/>
      <location filename="../../CommandExtensionPack.cpp" line="1731"/>
      <source>Extend Line</source>
      <translation type="unfinished">Extend Line</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1593"/>
      <location filename="../../CommandExtensionPack.cpp" line="1732"/>
      <source>Extend a cosmetic line or centerline at both ends:&lt;br&gt;- Specify the delta distance (optional)&lt;br&gt;- Select a single line&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Extend a cosmetic line or centerline at both ends:&lt;br&gt;- Specify the delta distance (optional)&lt;br&gt;- Select a single line&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionHoleCircle</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="171"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="172"/>
      <location filename="../../CommandExtensionPack.cpp" line="360"/>
      <source>Add Bolt Circle Centerlines</source>
      <translation type="unfinished">Add Bolt Circle Centerlines</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="173"/>
      <location filename="../../CommandExtensionPack.cpp" line="361"/>
      <source>Add centerlines to a circular pattern of circles:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select three or more circles forming a circular pattern&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add centerlines to a circular pattern of circles:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select three or more circles forming a circular pattern&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionIncreaseDecimal</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="470"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="471"/>
      <location filename="../../CommandExtensionDims.cpp" line="604"/>
      <source>Increase Decimal Places</source>
      <translation type="unfinished">Increase Decimal Places</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="472"/>
      <location filename="../../CommandExtensionDims.cpp" line="605"/>
      <source>Increase the number of decimal places of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Increase the number of decimal places of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionIncreaseDecreaseGroup</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="536"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="537"/>
      <source>Increase Decimal Places</source>
      <translation type="unfinished">Increase Decimal Places</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="538"/>
      <source>Increase the number of decimal places of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Increase the number of decimal places of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionInsertDiameter</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="155"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="156"/>
      <location filename="../../CommandExtensionDims.cpp" line="395"/>
      <source>Insert &apos;⌀&apos; Prefix</source>
      <translation type="unfinished">Insert &apos;⌀&apos; Prefix</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="157"/>
      <location filename="../../CommandExtensionDims.cpp" line="396"/>
      <source>Insert a &apos;⌀&apos; symbol at the beginning of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Insert a &apos;⌀&apos; symbol at the beginning of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionInsertPrefixGroup</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="313"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="314"/>
      <source>Insert &apos;⌀&apos; Prefix</source>
      <translation type="unfinished">Insert &apos;⌀&apos; Prefix</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="315"/>
      <source>Insert a &apos;⌀&apos; symbol at the beginning of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Insert a &apos;⌀&apos; symbol at the beginning of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionInsertSquare</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="188"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="189"/>
      <location filename="../../CommandExtensionDims.cpp" line="402"/>
      <source>Insert &apos;□&apos; Prefix</source>
      <translation type="unfinished">Insert &apos;□&apos; Prefix</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="190"/>
      <location filename="../../CommandExtensionDims.cpp" line="403"/>
      <source>Insert a &apos;□&apos; symbol at the beginning of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Insert a &apos;□&apos; symbol at the beginning of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionLinePPGroup</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1355"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1356"/>
      <source>Add Cosmetic Parallel Line</source>
      <translation type="unfinished">Add Cosmetic Parallel Line</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1357"/>
      <source>Add a cosmetic line parallel to another line through a vertex:&lt;br&gt;- Select a line&lt;br&gt;- Select a vertex&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add a cosmetic line parallel to another line through a vertex:&lt;br&gt;- Select a line&lt;br&gt;- Select a vertex&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionLineParallel</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1286"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1287"/>
      <location filename="../../CommandExtensionPack.cpp" line="1426"/>
      <source>Add Cosmetic Parallel Line</source>
      <translation type="unfinished">Add Cosmetic Parallel Line</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1288"/>
      <location filename="../../CommandExtensionPack.cpp" line="1428"/>
      <source>Add a cosmetic line parallel to another line through a vertex:&lt;br&gt;- Select a line&lt;br&gt;- Select a vertex&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add a cosmetic line parallel to another line through a vertex:&lt;br&gt;- Select a line&lt;br&gt;- Select a vertex&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionLinePerpendicular</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1320"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1321"/>
      <location filename="../../CommandExtensionPack.cpp" line="1435"/>
      <source>Add Cosmetic Perpendicular Line</source>
      <translation type="unfinished">Add Cosmetic Perpendicular Line</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1323"/>
      <location filename="../../CommandExtensionPack.cpp" line="1437"/>
      <source>Add a cosmetic line perpendicular to another line through a vertex:&lt;br&gt;- Select a line&lt;br&gt;- Select a vertex&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add a cosmetic line perpendicular to another line through a vertex:&lt;br&gt;- Select a line&lt;br&gt;- Select a vertex&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionLockUnlockView</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1463"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1464"/>
      <source>Lock/Unlock View</source>
      <translation type="unfinished">Lock/Unlock View</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1465"/>
      <source>Lock or unlock the position of a view:&lt;br&gt;- Select a single view&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Lock or unlock the position of a view:&lt;br&gt;- Select a single view&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionPosChainDimensionGroup</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="827"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="828"/>
      <source>Position Horizontal Chain Dimensions</source>
      <translation type="unfinished">Position Horizontal Chain Dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="829"/>
      <source>Align horizontal dimensions to create a chain dimension:&lt;br&gt;- Select two or more horizontal dimensions&lt;br&gt;- The first dimension defines the position&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Align horizontal dimensions to create a chain dimension:&lt;br&gt;- Select two or more horizontal dimensions&lt;br&gt;- The first dimension defines the position&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionPosHorizChainDimension</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="663"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="664"/>
      <location filename="../../CommandExtensionDims.cpp" line="903"/>
      <source>Position Horizontal Chain Dimensions</source>
      <translation type="unfinished">Position Horizontal Chain Dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="665"/>
      <location filename="../../CommandExtensionDims.cpp" line="904"/>
      <source>Align horizontal dimensions to create a chain dimension:&lt;br&gt;- Select two or more horizontal dimensions&lt;br&gt;- The first dimension defines the position&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Align horizontal dimensions to create a chain dimension:&lt;br&gt;- Select two or more horizontal dimensions&lt;br&gt;- The first dimension defines the position&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionPosObliqueChainDimension</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="792"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="793"/>
      <location filename="../../CommandExtensionDims.cpp" line="919"/>
      <source>Position Oblique Chain Dimensions</source>
      <translation type="unfinished">Position Oblique Chain Dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="794"/>
      <location filename="../../CommandExtensionDims.cpp" line="920"/>
      <source>Align oblique dimensions to create a chain dimension:&lt;br&gt;- Select two or more parallel oblique dimensions&lt;br&gt;- The first dimension defines the position&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Align oblique dimensions to create a chain dimension:&lt;br&gt;- Select two or more parallel oblique dimensions&lt;br&gt;- The first dimension defines the position&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionPosVertChainDimension</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="725"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="726"/>
      <location filename="../../CommandExtensionDims.cpp" line="911"/>
      <source>Position Vertical Chain Dimensions</source>
      <translation type="unfinished">Position Vertical Chain Dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="727"/>
      <location filename="../../CommandExtensionDims.cpp" line="912"/>
      <source>Align vertical dimensions to create a chain dimension:&lt;br&gt;- Select two or more vertical dimensions&lt;br&gt;- The first dimension defines the position&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Align vertical dimensions to create a chain dimension:&lt;br&gt;- Select two or more vertical dimensions&lt;br&gt;- The first dimension defines the position&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionRemovePrefixChar</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="280"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="281"/>
      <source>Remove Prefix</source>
      <translation type="unfinished">Remove Prefix</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="282"/>
      <source>Remove prefix symbols at the beginning of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Remove prefix symbols at the beginning of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionSelectLineAttributes</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="744"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="745"/>
      <source>Select Line Attributes, Cascade Spacing and Delta Distance</source>
      <translation type="unfinished">Select Line Attributes, Cascade Spacing and Delta Distance</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="746"/>
      <source>Select the attributes for new cosmetic lines and centerlines, and specify the cascade spacing and delta distance:&lt;br&gt;- Click this tool&lt;br&gt;- Specify the attributes, spacing and distance in the dialog box&lt;br&gt;- Press OK</source>
      <translation type="unfinished">Select the attributes for new cosmetic lines and centerlines, and specify the cascade spacing and delta distance:&lt;br&gt;- Click this tool&lt;br&gt;- Specify the attributes, spacing and distance in the dialog box&lt;br&gt;- Press OK</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionShortenLine</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1626"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1627"/>
      <location filename="../../CommandExtensionPack.cpp" line="1739"/>
      <source>Shorten Line</source>
      <translation type="unfinished">Shorten Line</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1628"/>
      <location filename="../../CommandExtensionPack.cpp" line="1740"/>
      <source>Shorten a cosmetic line or centerline at both ends:&lt;br&gt;- Specify the delta distance (optional)&lt;br&gt;- Select a single line&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Shorten a cosmetic line or centerline at both ends:&lt;br&gt;- Specify the delta distance (optional)&lt;br&gt;- Select a single line&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionThreadBoltBottom</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="568"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="569"/>
      <location filename="../../CommandExtensionPack.cpp" line="716"/>
      <source>Add Cosmetic Thread Bolt Bottom View</source>
      <translation type="unfinished">Add Cosmetic Thread Bolt Bottom View</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="571"/>
      <location filename="../../CommandExtensionPack.cpp" line="718"/>
      <source>Add a cosmetic thread to the top or bottom view of bolts/screws/rods:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select one or more circles&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add a cosmetic thread to the top or bottom view of bolts/screws/rods:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select one or more circles&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionThreadBoltSide</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="460"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="461"/>
      <location filename="../../CommandExtensionPack.cpp" line="706"/>
      <source>Add Cosmetic Thread Bolt Side View</source>
      <translation type="unfinished">Add Cosmetic Thread Bolt Side View</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="462"/>
      <location filename="../../CommandExtensionPack.cpp" line="709"/>
      <source>Add a cosmetic thread to the side view of a bolt/screw/rod:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select two parallel lines&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add a cosmetic thread to the side view of a bolt/screw/rod:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select two parallel lines&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionThreadHoleBottom</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="514"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="515"/>
      <location filename="../../CommandExtensionPack.cpp" line="696"/>
      <source>Add Cosmetic Thread Hole Bottom View</source>
      <translation type="unfinished">Add Cosmetic Thread Hole Bottom View</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="516"/>
      <location filename="../../CommandExtensionPack.cpp" line="699"/>
      <source>Add a cosmetic thread to the top or bottom view of holes:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select one or more circles&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add a cosmetic thread to the top or bottom view of holes:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select one or more circles&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionThreadHoleSide</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="406"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="407"/>
      <location filename="../../CommandExtensionPack.cpp" line="687"/>
      <source>Add Cosmetic Thread Hole Side View</source>
      <translation type="unfinished">Add Cosmetic Thread Hole Side View</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="408"/>
      <location filename="../../CommandExtensionPack.cpp" line="689"/>
      <source>Add a cosmetic thread to the side view of a hole:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select two parallel lines&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add a cosmetic thread to the side view of a hole:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select two parallel lines&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionThreadsGroup</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="603"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="604"/>
      <source>Add Cosmetic Thread Hole Side View</source>
      <translation type="unfinished">Add Cosmetic Thread Hole Side View</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="605"/>
      <source>Add a cosmetic thread to the side view of a hole:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select two parallel lines&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add a cosmetic thread to the side view of a hole:&lt;br&gt;- Specify the line attributes (optional)&lt;br&gt;- Select two parallel lines&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionVertexAtIntersection</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="840"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="841"/>
      <source>Add Cosmetic Intersection Vertex(es)</source>
      <translation type="unfinished">Add Cosmetic Intersection Vertex(es)</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="843"/>
      <source>Add cosmetic vertex(es) at the intersection(s) of selected edges:&lt;br&gt;- Select two edges&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Add cosmetic vertex(es) at the intersection(s) of selected edges:&lt;br&gt;- Select two edges&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtentGroup</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1965"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1966"/>
      <source>Insert Extent Dimension</source>
      <translation type="unfinished">Insert Extent Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2034"/>
      <source>Horizontal Extent</source>
      <translation type="unfinished">Horizontal Extent</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2039"/>
      <source>Vertical Extent</source>
      <translation type="unfinished">Vertical Extent</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawFaceCenterLine</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="684"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="685"/>
      <source>Add Centerline to Faces</source>
      <translation type="unfinished">Add Centerline to Faces</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawGeometricHatch</name>
    <message>
      <location filename="../../CommandDecorate.cpp" line="172"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="173"/>
      <source>Apply Geometric Hatch to Face</source>
      <translation type="unfinished">Apply Geometric Hatch to Face</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawHatch</name>
    <message>
      <location filename="../../CommandDecorate.cpp" line="76"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="77"/>
      <source>Hatch a Face using Image File</source>
      <translation type="unfinished">Hatch a Face using Image File</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawHorizontalDimension</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1644"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1645"/>
      <source>Insert Horizontal Dimension</source>
      <translation type="unfinished">Insert Horizontal Dimension</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawHorizontalExtentDimension</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2060"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2061"/>
      <source>Insert Horizontal Extent Dimension</source>
      <translation type="unfinished">Insert Horizontal Extent Dimension</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawImage</name>
    <message>
      <location filename="../../CommandDecorate.cpp" line="243"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="244"/>
      <source>Insert Bitmap Image</source>
      <translation type="unfinished">Insert Bitmap Image</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="245"/>
      <location filename="../../CommandDecorate.cpp" line="247"/>
      <source>Insert Bitmap from a file into a page</source>
      <translation type="unfinished">Insert Bitmap from a file into a page</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="262"/>
      <source>Select an Image File</source>
      <translation type="unfinished">Select an Image File</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="264"/>
      <source>Image files (*.jpg *.jpeg *.png *.bmp);;All files (*)</source>
      <translation type="unfinished">Image files (*.jpg *.jpeg *.png *.bmp);;All files (*)</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawLandmarkDimension</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2259"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2260"/>
      <source>Insert Landmark Dimension - EXPERIMENTAL</source>
      <translation type="unfinished">Insert Landmark Dimension - EXPERIMENTAL</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawLeaderLine</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="91"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="92"/>
      <source>Add Leaderline to View</source>
      <translation type="unfinished">Add Leaderline to View</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawLengthDimension</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1597"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1598"/>
      <source>Insert Length Dimension</source>
      <translation type="unfinished">Insert Length Dimension</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawLinkDimension</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1885"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1886"/>
      <source>Link Dimension to 3D Geometry</source>
      <translation type="unfinished">Link Dimension to 3D Geometry</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawMidpoints</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="453"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="454"/>
      <source>Add Midpoint Vertices</source>
      <translation type="unfinished">Add Midpoint Vertices</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawPageDefault</name>
    <message>
      <location filename="../../Command.cpp" line="109"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="110"/>
      <source>Insert Default Page</source>
      <translation type="unfinished">Insert Default Page</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawPageTemplate</name>
    <message>
      <location filename="../../Command.cpp" line="171"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="172"/>
      <source>Insert Page using Template</source>
      <translation type="unfinished">Insert Page using Template</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="185"/>
      <source>Select a Template File</source>
      <translation type="unfinished">Select a Template File</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="186"/>
      <source>Template (*.svg)</source>
      <translation type="unfinished">Template (*.svg)</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawPrintAll</name>
    <message>
      <location filename="../../Command.cpp" line="278"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="279"/>
      <source>Print All Pages</source>
      <translation type="unfinished">Print All Pages</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawProjectShape</name>
    <message>
      <location filename="../../Command.cpp" line="1913"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1914"/>
      <source>Project shape...</source>
      <translation type="unfinished">Project shape...</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawProjectionGroup</name>
    <message>
      <location filename="../../Command.cpp" line="1054"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1055"/>
      <source>Insert Projection Group</source>
      <translation type="unfinished">Insert Projection Group</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1056"/>
      <source>Insert multiple linked views of drawable object(s)</source>
      <translation type="unfinished">Insert multiple linked views of drawable object(s)</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawQuadrants</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="492"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="493"/>
      <source>Add Quadrant Vertices</source>
      <translation type="unfinished">Add Quadrant Vertices</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawRadiusDimension</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1501"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1502"/>
      <source>Insert Radius Dimension</source>
      <translation type="unfinished">Insert Radius Dimension</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawRedrawPage</name>
    <message>
      <location filename="../../Command.cpp" line="242"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="243"/>
      <source>Redraw Page</source>
      <translation type="unfinished">Redraw Page</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawRichTextAnnotation</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="153"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="154"/>
      <source>Insert Rich Text Annotation</source>
      <translation type="unfinished">Insert Rich Text Annotation</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawSectionGroup</name>
    <message>
      <location filename="../../Command.cpp" line="729"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="730"/>
      <source>Insert a simple or complex Section View</source>
      <translation type="unfinished">Insert a simple or complex Section View</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="795"/>
      <source>Section View</source>
      <translation type="unfinished">Section View</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="799"/>
      <source>Complex Section</source>
      <translation type="unfinished">Complex Section</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawSectionView</name>
    <message>
      <location filename="../../Command.cpp" line="821"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="822"/>
      <source>Insert Section View</source>
      <translation type="unfinished">Insert Section View</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawShowAll</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1485"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1486"/>
      <source>Show/Hide Invisible Edges</source>
      <translation type="unfinished">Show/Hide Invisible Edges</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawSpreadsheetView</name>
    <message>
      <location filename="../../Command.cpp" line="1733"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1734"/>
      <source>Insert Spreadsheet View</source>
      <translation type="unfinished">Insert Spreadsheet View</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1735"/>
      <source>Insert View to a spreadsheet</source>
      <translation type="unfinished">Insert View to a spreadsheet</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawStackBottom</name>
    <message>
      <location filename="../../CommandStack.cpp" line="237"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandStack.cpp" line="238"/>
      <source>Move view to bottom of stack</source>
      <translation type="unfinished">Move view to bottom of stack</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawStackDown</name>
    <message>
      <location filename="../../CommandStack.cpp" line="357"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandStack.cpp" line="358"/>
      <source>Move view down one level</source>
      <translation type="unfinished">Move view down one level</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawStackGroup</name>
    <message>
      <location filename="../../CommandStack.cpp" line="64"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandStack.cpp" line="65"/>
      <source>Adjust stacking order of views</source>
      <translation type="unfinished">Adjust stacking order of views</translation>
    </message>
    <message>
      <location filename="../../CommandStack.cpp" line="143"/>
      <source>Stack Top</source>
      <translation type="unfinished">Stack Top</translation>
    </message>
    <message>
      <location filename="../../CommandStack.cpp" line="147"/>
      <source>Stack Bottom</source>
      <translation type="unfinished">Stack Bottom</translation>
    </message>
    <message>
      <location filename="../../CommandStack.cpp" line="151"/>
      <source>Stack Up</source>
      <translation type="unfinished">Stack Up</translation>
    </message>
    <message>
      <location filename="../../CommandStack.cpp" line="155"/>
      <source>Stack Down</source>
      <translation type="unfinished">Stack Down</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawStackTop</name>
    <message>
      <location filename="../../CommandStack.cpp" line="177"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandStack.cpp" line="178"/>
      <source>Move view to top of stack</source>
      <translation type="unfinished">Move view to top of stack</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawStackUp</name>
    <message>
      <location filename="../../CommandStack.cpp" line="297"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandStack.cpp" line="298"/>
      <source>Move view up one level</source>
      <translation type="unfinished">Move view up one level</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawSurfaceFinishSymbols</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1614"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1615"/>
      <source>Create a Surface Finish Symbol</source>
      <translation type="unfinished">Create a Surface Finish Symbol</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1616"/>
      <source>Select a view&lt;br&gt;    - click this button&lt;br&gt;    - select surface finish symbol attributes in opened panel</source>
      <translation type="unfinished">Select a view&lt;br&gt;    - click this button&lt;br&gt;    - select surface finish symbol attributes in opened panel</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawSymbol</name>
    <message>
      <location filename="../../Command.cpp" line="1534"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1535"/>
      <source>Insert SVG Symbol</source>
      <translation type="unfinished">Insert SVG Symbol</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1536"/>
      <source>Insert symbol from an SVG file</source>
      <translation type="unfinished">Insert symbol from an SVG file</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawToggleFrame</name>
    <message>
      <location filename="../../CommandDecorate.cpp" line="306"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="307"/>
      <location filename="../../CommandDecorate.cpp" line="308"/>
      <source>Turn View Frames On/Off</source>
      <translation type="unfinished">Turn View Frames On/Off</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawVerticalDimension</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1692"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1693"/>
      <source>Insert Vertical Dimension</source>
      <translation type="unfinished">Insert Vertical Dimension</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawVerticalExtentDimension</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2172"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2173"/>
      <source>Insert Vertical Extent Dimension</source>
      <translation type="unfinished">Insert Vertical Extent Dimension</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawView</name>
    <message>
      <location filename="../../Command.cpp" line="303"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="304"/>
      <source>Insert View</source>
      <translation type="unfinished">Insert View</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="305"/>
      <source>Insert a View in current page.
Selected objects, spreadsheets or Arch WB section planes will be added.
Without a selection, a file browser lets you select a SVG or image file.</source>
      <translation type="unfinished">Insert a View in current page.
Selected objects, spreadsheets or Arch WB section planes will be added.
Without a selection, a file browser lets you select a SVG or image file.</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawWeldSymbol</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1550"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1551"/>
      <source>Add Welding Information to Leaderline</source>
      <translation type="unfinished">Add Welding Information to Leaderline</translation>
    </message>
  </context>
  <context>
    <name>Command</name>
    <message>
      <location filename="../../Command.cpp" line="125"/>
      <location filename="../../Command.cpp" line="196"/>
      <source>Drawing create page</source>
      <translation type="unfinished">Drawing create page</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="365"/>
      <source>Create BIM View</source>
      <translation type="unfinished">Create BIM View</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="501"/>
      <source>Create view</source>
      <translation type="unfinished">Create view</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="648"/>
      <source>Create broken view</source>
      <translation type="unfinished">Create broken view</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1138"/>
      <source>Create Projection Group</source>
      <translation type="unfinished">Create Projection Group</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1358"/>
      <source>Create Clip</source>
      <translation type="unfinished">Create Clip</translation>
    </message>
    <message>
      <location filename="../../PagePrinter.cpp" line="422"/>
      <location filename="../../Command.cpp" line="1892"/>
      <source>Save page to DXF</source>
      <translation type="unfinished">Save page to DXF</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="458"/>
      <location filename="../../Command.cpp" line="1562"/>
      <source>Create Symbol</source>
      <translation type="unfinished">Create Symbol</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1430"/>
      <source>Add clip group</source>
      <translation type="unfinished">Add clip group</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1501"/>
      <source>Remove clip group</source>
      <translation type="unfinished">Remove clip group</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1635"/>
      <source>Create DraftView</source>
      <translation type="unfinished">Create DraftView</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1709"/>
      <source>Create ArchView</source>
      <translation type="unfinished">Create ArchView</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="347"/>
      <location filename="../../Command.cpp" line="1759"/>
      <source>Create spreadsheet view</source>
      <translation type="unfinished">Create spreadsheet view</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="339"/>
      <source>Add Midpoint Vertices</source>
      <translation type="unfinished">Add Midpoint Vertices</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="366"/>
      <source>Add Quadrant Vertices</source>
      <translation type="unfinished">Add Quadrant Vertices</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="549"/>
      <source>Create Annotation</source>
      <translation type="unfinished">Create Annotation</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="241"/>
      <source>Insert Dimension</source>
      <translation type="unfinished">Insert Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="469"/>
      <location filename="../../CommandCreateDims.cpp" line="887"/>
      <location filename="../../CommandCreateDims.cpp" line="902"/>
      <location filename="../../CommandCreateDims.cpp" line="940"/>
      <location filename="../../CommandCreateDims.cpp" line="955"/>
      <location filename="../../CommandCreateDims.cpp" line="970"/>
      <location filename="../../CommandCreateDims.cpp" line="1004"/>
      <location filename="../../CommandCreateDims.cpp" line="1038"/>
      <location filename="../../CommandCreateDims.cpp" line="1059"/>
      <source>Add Extent dimension</source>
      <translation type="unfinished">Add Extent dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="798"/>
      <source>Add Area dimension</source>
      <translation type="unfinished">Add Area dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="809"/>
      <location filename="../../CommandCreateDims.cpp" line="1104"/>
      <location filename="../../CommandCreateDims.cpp" line="1205"/>
      <source>Add Distance dimension</source>
      <translation type="unfinished">Add Distance dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="818"/>
      <location filename="../../CommandCreateDims.cpp" line="924"/>
      <location filename="../../CommandCreateDims.cpp" line="1185"/>
      <source>Add DistanceX Chamfer dimension</source>
      <translation type="unfinished">Add DistanceX Chamfer dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="829"/>
      <location filename="../../CommandCreateDims.cpp" line="1286"/>
      <source>Add horizontal chain dimensions</source>
      <translation type="unfinished">Add horizontal chain dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="834"/>
      <location filename="../../CommandCreateDims.cpp" line="861"/>
      <source>Add horizontal coordinate dimensions</source>
      <translation type="unfinished">Add horizontal coordinate dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="838"/>
      <location filename="../../CommandCreateDims.cpp" line="842"/>
      <location filename="../../CommandCreateDims.cpp" line="846"/>
      <source>Add 3-points angle dimension</source>
      <translation type="unfinished">Add 3-points angle dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="856"/>
      <source>Add horizontal chain dimension</source>
      <translation type="unfinished">Add horizontal chain dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="871"/>
      <source>Add point to line Distance dimension</source>
      <translation type="unfinished">Add point to line Distance dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="882"/>
      <location filename="../../CommandCreateDims.cpp" line="897"/>
      <location filename="../../CommandCreateDims.cpp" line="912"/>
      <source>Add length dimension</source>
      <translation type="unfinished">Add length dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="935"/>
      <source>Add Angle dimension</source>
      <translation type="unfinished">Add Angle dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="950"/>
      <source>Add circle to line Distance dimension</source>
      <translation type="unfinished">Add circle to line Distance dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="965"/>
      <source>Add ellipse to line Distance dimension</source>
      <translation type="unfinished">Add ellipse to line Distance dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1089"/>
      <source>Add Radius dimension</source>
      <translation type="unfinished">Add Radius dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="989"/>
      <location filename="../../CommandCreateDims.cpp" line="1023"/>
      <source>Add Arc Length dimension</source>
      <translation type="unfinished">Add Arc Length dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="999"/>
      <source>Add circle to circle Distance dimension</source>
      <translation type="unfinished">Add circle to circle Distance dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1033"/>
      <source>Add ellipse to ellipse Distance dimension</source>
      <translation type="unfinished">Add ellipse to ellipse Distance dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1048"/>
      <source>Add edge length dimension</source>
      <translation type="unfinished">Add edge length dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1093"/>
      <source>Add Diameter dimension</source>
      <translation type="unfinished">Add Diameter dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1188"/>
      <source>Add DistanceX dimension</source>
      <translation type="unfinished">Add DistanceX dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1195"/>
      <source>Add DistanceY Chamfer dimension</source>
      <translation type="unfinished">Add DistanceY Chamfer dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1198"/>
      <source>Add DistanceY dimension</source>
      <translation type="unfinished">Add DistanceY dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1243"/>
      <source>Add DistanceX extent dimension</source>
      <translation type="unfinished">Add DistanceX extent dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1248"/>
      <source>Add DistanceY extent dimension</source>
      <translation type="unfinished">Add DistanceY extent dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1290"/>
      <source>Add horizontal coord dimensions</source>
      <translation type="unfinished">Add horizontal coord dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1297"/>
      <source>Add vertical chain dimensions</source>
      <translation type="unfinished">Add vertical chain dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1301"/>
      <source>Add vertical coord dimensions</source>
      <translation type="unfinished">Add vertical coord dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1307"/>
      <source>Add oblique chain dimensions</source>
      <translation type="unfinished">Add oblique chain dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1311"/>
      <source>Add oblique coord dimensions</source>
      <translation type="unfinished">Add oblique coord dimensions</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1383"/>
      <source>Dimension</source>
      <translation type="unfinished">Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2307"/>
      <location filename="../../CommandCreateDims.cpp" line="2472"/>
      <source>Create Dimension</source>
      <translation type="unfinished">Create Dimension</translation>
    </message>
    <message>
      <location filename="../../TaskHatch.cpp" line="202"/>
      <source>Create Hatch</source>
      <translation type="unfinished">Create Hatch</translation>
    </message>
    <message>
      <location filename="../../TaskHatch.cpp" line="239"/>
      <source>Update Hatch</source>
      <translation type="unfinished">Update Hatch</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="123"/>
      <source>Remove old Hatch</source>
      <translation type="unfinished">Remove old Hatch</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="202"/>
      <source>Create GeomHatch</source>
      <translation type="unfinished">Create GeomHatch</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="273"/>
      <location filename="../../Command.cpp" line="483"/>
      <source>Create Image</source>
      <translation type="unfinished">Create Image</translation>
    </message>
    <message>
      <location filename="../../QGIViewBalloon.cpp" line="510"/>
      <source>Drag Balloon</source>
      <translation type="unfinished">Drag Balloon</translation>
    </message>
    <message>
      <location filename="../../QGIViewDimension.cpp" line="875"/>
      <source>Drag Dimension</source>
      <translation type="unfinished">Drag Dimension</translation>
    </message>
    <message>
      <location filename="../../QGSPage.cpp" line="625"/>
      <source>Create Balloon</source>
      <translation type="unfinished">Create Balloon</translation>
    </message>
    <message>
      <location filename="../../TaskActiveView.cpp" line="267"/>
      <source>Create ActiveView</source>
      <translation type="unfinished">Create ActiveView</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticLine.cpp" line="177"/>
      <source>Create Cosmetic Line</source>
      <translation type="unfinished">Create Cosmetic Line</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.cpp" line="193"/>
      <source>Create Cosmetic Circle</source>
      <translation type="unfinished">Create Cosmetic Circle</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.cpp" line="267"/>
      <source>Update CosmeticCircle</source>
      <translation type="unfinished">Update CosmeticCircle</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticLine.cpp" line="253"/>
      <source>Update CosmeticLine</source>
      <translation type="unfinished">Update CosmeticLine</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.cpp" line="434"/>
      <source>Create Detail View</source>
      <translation type="unfinished">Create Detail View</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.cpp" line="476"/>
      <source>Update Detail</source>
      <translation type="unfinished">Update Detail</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.cpp" line="346"/>
      <source>Create Leader</source>
      <translation type="unfinished">Create Leader</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.cpp" line="433"/>
      <source>Edit Leader</source>
      <translation type="unfinished">Edit Leader</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.cpp" line="289"/>
      <source>Create Anno</source>
      <translation type="unfinished">Create Anno</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.cpp" line="351"/>
      <source>Edit Anno</source>
      <translation type="unfinished">Edit Anno</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.cpp" line="495"/>
      <source>Create SectionView</source>
      <translation type="unfinished">Create SectionView</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.cpp" line="559"/>
      <source>Create ComplexSection</source>
      <translation type="unfinished">Create ComplexSection</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.cpp" line="652"/>
      <location filename="../../TaskSectionView.cpp" line="574"/>
      <source>Edit Section View</source>
      <translation type="unfinished">Edit Section View</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.cpp" line="561"/>
      <source>Create WeldSymbol</source>
      <translation type="unfinished">Create WeldSymbol</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.cpp" line="569"/>
      <source>Edit WeldSymbol</source>
      <translation type="unfinished">Edit WeldSymbol</translation>
    </message>
    <message>
      <location filename="../../TaskCosVertex.cpp" line="137"/>
      <source>Add Cosmetic Vertex</source>
      <translation type="unfinished">Add Cosmetic Vertex</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="110"/>
      <source>TechDraw Insert Prefix</source>
      <translation type="unfinished">TechDraw Insert Prefix</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="136"/>
      <source>Insert Prefix</source>
      <translation type="unfinished">Insert Prefix</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="252"/>
      <source>TechDraw Remove Prefix</source>
      <translation type="unfinished">TechDraw Remove Prefix</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="256"/>
      <source>Remove Prefix</source>
      <translation type="unfinished">Remove Prefix</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="442"/>
      <source>Increase/Decrease Decimal</source>
      <translation type="unfinished">Increase/Decrease Decimal</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="637"/>
      <source>Pos Horiz Chain Dim</source>
      <translation type="unfinished">Pos Horiz Chain Dim</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="698"/>
      <source>Pos Vert Chain Dim</source>
      <translation type="unfinished">Pos Vert Chain Dim</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="760"/>
      <source>Pos Oblique Chain Dim</source>
      <translation type="unfinished">Pos Oblique Chain Dim</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="946"/>
      <source>Cascade Horiz Dim</source>
      <translation type="unfinished">Cascade Horiz Dim</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1012"/>
      <source>Cascade Vert Dim</source>
      <translation type="unfinished">Cascade Vert Dim</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1079"/>
      <source>Cascade Oblique Dim</source>
      <translation type="unfinished">Cascade Oblique Dim</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1278"/>
      <source>Create Horiz Chain Dim</source>
      <translation type="unfinished">Create Horiz Chain Dim</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1344"/>
      <source>Create Vert Chain Dim</source>
      <translation type="unfinished">Create Vert Chain Dim</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1410"/>
      <source>Create Oblique Chain Dim</source>
      <translation type="unfinished">Create Oblique Chain Dim</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1649"/>
      <source>Create Horiz Coord Dim</source>
      <translation type="unfinished">Create Horiz Coord Dim</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1721"/>
      <source>Create Vert Coord Dim</source>
      <translation type="unfinished">Create Vert Coord Dim</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1795"/>
      <source>Create Oblique Coord Dim</source>
      <translation type="unfinished">Create Oblique Coord Dim</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2048"/>
      <source>Create Horiz Chamfer Dim</source>
      <translation type="unfinished">Create Horiz Chamfer Dim</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2117"/>
      <source>Create Vert Chamfer Dim</source>
      <translation type="unfinished">Create Vert Chamfer Dim</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2303"/>
      <source>Create Arc Length Dim</source>
      <translation type="unfinished">Create Arc Length Dim</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="106"/>
      <source>TechDraw Hole Circle</source>
      <translation type="unfinished">TechDraw Hole Circle</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="127"/>
      <source>Bolt Circle Centerlines</source>
      <translation type="unfinished">Bolt Circle Centerlines</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="205"/>
      <source>TechDraw Circle Centerlines</source>
      <translation type="unfinished">TechDraw Circle Centerlines</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="208"/>
      <source>Circle Centerlines</source>
      <translation type="unfinished">Circle Centerlines</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="386"/>
      <source>TechDraw Thread Hole Side</source>
      <translation type="unfinished">TechDraw Thread Hole Side</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="389"/>
      <source>Cosmetic Thread Hole Side</source>
      <translation type="unfinished">Cosmetic Thread Hole Side</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="440"/>
      <source>TechDraw Thread Bolt Side</source>
      <translation type="unfinished">TechDraw Thread Bolt Side</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="443"/>
      <source>Cosmetic Thread Bolt Side</source>
      <translation type="unfinished">Cosmetic Thread Bolt Side</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="494"/>
      <source>TechDraw Thread Hole Bottom</source>
      <translation type="unfinished">TechDraw Thread Hole Bottom</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="497"/>
      <source>Cosmetic Thread Hole Bottom</source>
      <translation type="unfinished">Cosmetic Thread Hole Bottom</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="548"/>
      <source>TechDraw Thread Bolt Bottom</source>
      <translation type="unfinished">TechDraw Thread Bolt Bottom</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="551"/>
      <source>Cosmetic Thread Bolt Bottom</source>
      <translation type="unfinished">Cosmetic Thread Bolt Bottom</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="796"/>
      <source>TechDraw Change Line Attributes</source>
      <translation type="unfinished">TechDraw Change Line Attributes</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="799"/>
      <source>Change Line Attributes</source>
      <translation type="unfinished">Change Line Attributes</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="857"/>
      <source>TechDraw Cosmetic Intersection Vertex(es)</source>
      <translation type="unfinished">TechDraw Cosmetic Intersection Vertex(es)</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="860"/>
      <source>Cosmetic Intersection Vertex(es)</source>
      <translation type="unfinished">Cosmetic Intersection Vertex(es)</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="903"/>
      <source>TechDraw Cosmetic Arc</source>
      <translation type="unfinished">TechDraw Cosmetic Arc</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="906"/>
      <source>Cosmetic Arc</source>
      <translation type="unfinished">Cosmetic Arc</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="976"/>
      <source>TechDraw Cosmetic Circle</source>
      <translation type="unfinished">TechDraw Cosmetic Circle</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="979"/>
      <source>Cosmetic Circle</source>
      <translation type="unfinished">Cosmetic Circle</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1039"/>
      <source>TechDraw Cosmetic Circle 3 Points</source>
      <translation type="unfinished">TechDraw Cosmetic Circle 3 Points</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1042"/>
      <source>Cosmetic Circle 3 Points</source>
      <translation type="unfinished">Cosmetic Circle 3 Points</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1230"/>
      <source>TechDraw Cosmetic Line Parallel/Perpendicular</source>
      <translation type="unfinished">TechDraw Cosmetic Line Parallel/Perpendicular</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1233"/>
      <source>Cosmetic Line Parallel/Perpendicular</source>
      <translation type="unfinished">Cosmetic Line Parallel/Perpendicular</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1479"/>
      <source>TechDraw Lock/Unlock View</source>
      <translation type="unfinished">TechDraw Lock/Unlock View</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1482"/>
      <source>Lock/Unlock View</source>
      <translation type="unfinished">Lock/Unlock View</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1507"/>
      <source>TechDraw Extend/Shorten Line</source>
      <translation type="unfinished">TechDraw Extend/Shorten Line</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1510"/>
      <source>Extend/Shorten Line</source>
      <translation type="unfinished">Extend/Shorten Line</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1779"/>
      <source>TechDraw calculate selected area</source>
      <translation type="unfinished">TechDraw calculate selected area</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1821"/>
      <source>Calculate Face Area</source>
      <translation type="unfinished">Calculate Face Area</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1911"/>
      <source>TechDraw calculate selected arc length</source>
      <translation type="unfinished">TechDraw calculate selected arc length</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1948"/>
      <source>Calculate Edge Length</source>
      <translation type="unfinished">Calculate Edge Length</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.cpp" line="190"/>
      <source>Customize Format</source>
      <translation type="unfinished">Customize Format</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.cpp" line="398"/>
      <source>Surface Finish Symbols</source>
      <translation type="unfinished">Surface Finish Symbols</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.cpp" line="405"/>
      <source>Create Centerline</source>
      <translation type="unfinished">Create Centerline</translation>
    </message>
  </context>
  <context>
    <name>CompassWidget</name>
    <message>
      <location filename="../../Widgets/CompassWidget.cpp" line="158"/>
      <source>View Direction as Angle</source>
      <translation type="unfinished">View Direction as Angle</translation>
    </message>
    <message>
      <location filename="../../Widgets/CompassWidget.cpp" line="160"/>
      <source>The view direction angle relative to +X in the BaseView.</source>
      <translation type="unfinished">The view direction angle relative to +X in the BaseView.</translation>
    </message>
    <message>
      <location filename="../../Widgets/CompassWidget.cpp" line="162"/>
      <source>Advance the view direction in clockwise direction.</source>
      <translation type="unfinished">Advance the view direction in clockwise direction.</translation>
    </message>
    <message>
      <location filename="../../Widgets/CompassWidget.cpp" line="164"/>
      <source>Advance the view direction in anti-clockwise direction.</source>
      <translation type="unfinished">Advance the view direction in anti-clockwise direction.</translation>
    </message>
  </context>
  <context>
    <name>MRichTextEdit</name>
    <message>
      <location filename="../../mrichtextedit.ui" line="35"/>
      <source>Save changes</source>
      <translation type="unfinished">Save changes</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="49"/>
      <source>Close editor</source>
      <translation type="unfinished">Close editor</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="73"/>
      <source>Paragraph formatting</source>
      <translation type="unfinished">Paragraph formatting</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="96"/>
      <source>Undo (CTRL+Z)</source>
      <translation type="unfinished">Undo (CTRL+Z)</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="99"/>
      <source>Undo</source>
      <translation type="unfinished">Undo</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="122"/>
      <location filename="../../mrichtextedit.ui" line="125"/>
      <source>Redo</source>
      <translation type="unfinished">Redo</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="145"/>
      <source>Cut (CTRL+X)</source>
      <translation type="unfinished">Cut (CTRL+X)</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="148"/>
      <source>Cut</source>
      <translation type="unfinished">Cut</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="168"/>
      <source>Copy (CTRL+C)</source>
      <translation type="unfinished">Copy (CTRL+C)</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="171"/>
      <source>Copy</source>
      <translation type="unfinished">Copy</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="191"/>
      <source>Paste (CTRL+V)</source>
      <translation type="unfinished">Paste (CTRL+V)</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="194"/>
      <source>Paste</source>
      <translation type="unfinished">Paste</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="221"/>
      <source>Link (CTRL+L)</source>
      <translation type="unfinished">Link (CTRL+L)</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="224"/>
      <source>Link</source>
      <translation type="unfinished">Link</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="257"/>
      <source>Bold</source>
      <translation type="unfinished">Bold</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="280"/>
      <source>Italic (CTRL+I)</source>
      <translation type="unfinished">Italic (CTRL+I)</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="283"/>
      <source>Italic</source>
      <translation type="unfinished">Italic</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="306"/>
      <source>Underline (CTRL+U)</source>
      <translation type="unfinished">Underline (CTRL+U)</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="309"/>
      <source>Underline</source>
      <translation type="unfinished">Underline</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="329"/>
      <source>Strikethrough</source>
      <translation type="unfinished">Strikethrough</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="332"/>
      <source>Strike Out</source>
      <translation type="unfinished">Strike Out</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="362"/>
      <source>Bullet list (CTRL+-)</source>
      <translation type="unfinished">Bullet list (CTRL+-)</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="388"/>
      <source>Ordered list (CTRL+=)</source>
      <translation type="unfinished">Ordered list (CTRL+=)</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="414"/>
      <source>Decrease indentation (CTRL+,)</source>
      <translation type="unfinished">Decrease indentation (CTRL+,)</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="417"/>
      <source>Decrease indentation</source>
      <translation type="unfinished">Decrease indentation</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="437"/>
      <source>Increase indentation (CTRL+.)</source>
      <translation type="unfinished">Increase indentation (CTRL+.)</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="440"/>
      <source>Increase indentation</source>
      <translation type="unfinished">Increase indentation</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="473"/>
      <source>Text foreground color</source>
      <translation type="unfinished">Text foreground color</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="496"/>
      <source>Text background color</source>
      <translation type="unfinished">Text background color</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="499"/>
      <source>Background</source>
      <translation type="unfinished">Background</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="525"/>
      <source>Font size</source>
      <translation type="unfinished">Font size</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.ui" line="566"/>
      <location filename="../../mrichtextedit.ui" line="612"/>
      <source>More functions</source>
      <translation type="unfinished">More functions</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.cpp" line="99"/>
      <source>Standard</source>
      <translation type="unfinished">Standard</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.cpp" line="100"/>
      <source>Heading 1</source>
      <translation type="unfinished">Heading 1</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.cpp" line="101"/>
      <source>Heading 2</source>
      <translation type="unfinished">Heading 2</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.cpp" line="102"/>
      <source>Heading 3</source>
      <translation type="unfinished">Heading 3</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.cpp" line="103"/>
      <source>Heading 4</source>
      <translation type="unfinished">Heading 4</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.cpp" line="104"/>
      <source>Monospace</source>
      <translation type="unfinished">Monospace</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.cpp" line="164"/>
      <source>Remove character formatting</source>
      <translation type="unfinished">Remove character formatting</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.cpp" line="169"/>
      <source>Remove all formatting</source>
      <translation type="unfinished">Remove all formatting</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.cpp" line="173"/>
      <source>Edit document source</source>
      <translation type="unfinished">Edit document source</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.cpp" line="267"/>
      <source>Document source</source>
      <translation type="unfinished">Document source</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.cpp" line="370"/>
      <source>Create a link</source>
      <translation type="unfinished">Create a link</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.cpp" line="371"/>
      <source>Link URL:</source>
      <translation type="unfinished">Link URL:</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.cpp" line="704"/>
      <source>Select an image</source>
      <translation type="unfinished">Select an image</translation>
    </message>
    <message>
      <location filename="../../mrichtextedit.cpp" line="706"/>
      <source>JPEG (*.jpg);; GIF (*.gif);; PNG (*.png);; BMP (*.bmp);; All (*)</source>
      <translation type="unfinished">JPEG (*.jpg);; GIF (*.gif);; PNG (*.png);; BMP (*.bmp);; All (*)</translation>
    </message>
  </context>
  <context>
    <name>QObject</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="317"/>
      <location filename="../../CommandAnnotate.cpp" line="418"/>
      <location filename="../../CommandAnnotate.cpp" line="1314"/>
      <location filename="../../CommandAnnotate.cpp" line="1322"/>
      <location filename="../../CommandAnnotate.cpp" line="1369"/>
      <location filename="../../CommandAnnotate.cpp" line="1511"/>
      <location filename="../../CommandAnnotate.cpp" line="1518"/>
      <location filename="../../CommandAnnotate.cpp" line="1582"/>
      <location filename="../../CommandCreateDims.cpp" line="2279"/>
      <location filename="../../CommandCreateDims.cpp" line="2288"/>
      <location filename="../../Command.cpp" line="632"/>
      <location filename="../../Command.cpp" line="642"/>
      <location filename="../../Command.cpp" line="858"/>
      <location filename="../../Command.cpp" line="975"/>
      <location filename="../../Command.cpp" line="982"/>
      <location filename="../../Command.cpp" line="987"/>
      <location filename="../../Command.cpp" line="1025"/>
      <location filename="../../Command.cpp" line="1124"/>
      <location filename="../../Command.cpp" line="1390"/>
      <location filename="../../Command.cpp" line="1407"/>
      <location filename="../../Command.cpp" line="1412"/>
      <location filename="../../Command.cpp" line="1421"/>
      <location filename="../../Command.cpp" line="1474"/>
      <location filename="../../Command.cpp" line="1493"/>
      <location filename="../../Command.cpp" line="1615"/>
      <location filename="../../Command.cpp" line="1690"/>
      <location filename="../../Command.cpp" line="1696"/>
      <location filename="../../Command.cpp" line="1753"/>
      <source>Wrong selection</source>
      <translation type="unfinished">Wrong selection</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="643"/>
      <location filename="../../Command.cpp" line="1125"/>
      <source>No Shapes, Groups or Links in this selection</source>
      <translation type="unfinished">No Shapes, Groups or Links in this selection</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="593"/>
      <source>Empty selection</source>
      <translation type="unfinished">Empty selection</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="430"/>
      <source>If you want to insert a view from existing objects, please select them before invoking this tool. Without a selection, a file browser will open, to insert a SVG or image file.</source>
      <translation type="unfinished">If you want to insert a view from existing objects, please select them before invoking this tool. Without a selection, a file browser will open, to insert a SVG or image file.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="433"/>
      <source>Do not show this message again</source>
      <translation type="unfinished">Do not show this message again</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="447"/>
      <source>Select a SVG or Image file to open</source>
      <translation type="unfinished">Select a SVG or Image file to open</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="450"/>
      <source>SVG or Image files</source>
      <translation type="unfinished">SVG or Image files</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="594"/>
      <source>Please select objects to break or a base view and break definition objects.</source>
      <translation type="unfinished">Please select objects to break or a base view and break definition objects.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="633"/>
      <source>No Break objects found in this selection</source>
      <translation type="unfinished">No Break objects found in this selection</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="859"/>
      <location filename="../../Command.cpp" line="1026"/>
      <source>Select at least 1 DrawViewPart object as Base.</source>
      <translation type="unfinished">Select at least 1 DrawViewPart object as Base.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="976"/>
      <source>I do not know what base view to use.</source>
      <translation type="unfinished">I do not know what base view to use.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="983"/>
      <source>No Base View, Shapes, Groups or Links in this selection</source>
      <translation type="unfinished">No Base View, Shapes, Groups or Links in this selection</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="988"/>
      <source>No profile object found in selection</source>
      <translation type="unfinished">No profile object found in selection</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1691"/>
      <source>Please select only 1 BIM Section.</source>
      <translation type="unfinished">Please select only 1 BIM Section.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1697"/>
      <source>No BIM Sections in selection.</source>
      <translation type="unfinished">No BIM Sections in selection.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1833"/>
      <source>No Drawing Page</source>
      <translation type="unfinished">No Drawing Page</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1834"/>
      <source>FreeCAD could not find a page to export</source>
      <translation type="unfinished">FreeCAD could not find a page to export</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="387"/>
      <location filename="../../CommandDecorate.cpp" line="394"/>
      <location filename="../../CommandDecorate.cpp" line="401"/>
      <location filename="../../CommandCreateDims.cpp" line="2093"/>
      <location filename="../../CommandCreateDims.cpp" line="2108"/>
      <location filename="../../CommandCreateDims.cpp" line="2387"/>
      <location filename="../../CommandCreateDims.cpp" line="2550"/>
      <location filename="../../CommandCreateDims.cpp" line="2558"/>
      <location filename="../../CommandCreateDims.cpp" line="2567"/>
      <location filename="../../Command.cpp" line="1192"/>
      <location filename="../../Command.cpp" line="1199"/>
      <location filename="../../Command.cpp" line="1207"/>
      <location filename="../../Command.cpp" line="1219"/>
      <location filename="../../CommandExtensionPack.cpp" line="1795"/>
      <location filename="../../CommandExtensionPack.cpp" line="1925"/>
      <source>Incorrect selection</source>
      <translation type="unfinished">Incorrect selection</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2551"/>
      <location filename="../../Command.cpp" line="1193"/>
      <source>Select an object first</source>
      <translation type="unfinished">Select an object first</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2559"/>
      <location filename="../../Command.cpp" line="1200"/>
      <source>Too many objects selected</source>
      <translation type="unfinished">Too many objects selected</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2568"/>
      <location filename="../../Command.cpp" line="1208"/>
      <source>Create a page first.</source>
      <translation type="unfinished">Create a page first.</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2094"/>
      <location filename="../../CommandCreateDims.cpp" line="2388"/>
      <location filename="../../Command.cpp" line="1220"/>
      <source>No View of a Part in selection.</source>
      <translation type="unfinished">No View of a Part in selection.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1391"/>
      <source>Select one Clip group and one View.</source>
      <translation type="unfinished">Select one Clip group and one View.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1408"/>
      <source>Select exactly one View to add to group.</source>
      <translation type="unfinished">Select exactly one View to add to group.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1413"/>
      <source>Select exactly one Clip group.</source>
      <translation type="unfinished">Select exactly one Clip group.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1422"/>
      <source>Clip and View must be from same Page.</source>
      <translation type="unfinished">Clip and View must be from same Page.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1475"/>
      <source>Select exactly one View to remove from Group.</source>
      <translation type="unfinished">Select exactly one View to remove from Group.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1494"/>
      <source>View does not belong to a Clip</source>
      <translation type="unfinished">View does not belong to a Clip</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1553"/>
      <source>Choose an SVG file to open</source>
      <translation type="unfinished">Choose an SVG file to open</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1556"/>
      <source>Scalable Vector Graphic</source>
      <translation type="unfinished">Scalable Vector Graphic</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="450"/>
      <location filename="../../Command.cpp" line="1556"/>
      <source>All Files</source>
      <translation type="unfinished">All Files</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1616"/>
      <source>Select at least one object.</source>
      <translation type="unfinished">Select at least one object.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1754"/>
      <source>Select exactly one Spreadsheet object.</source>
      <translation type="unfinished">Select exactly one Spreadsheet object.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1869"/>
      <source>Can not export selection</source>
      <translation type="unfinished">Can not export selection</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1870"/>
      <source>Page contains DrawViewArch which will not be exported. Continue?</source>
      <translation type="unfinished">Page contains DrawViewArch which will not be exported. Continue?</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2432"/>
      <source>Ellipse Curve Warning</source>
      <translation type="unfinished">Ellipse Curve Warning</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="408"/>
      <location filename="../../CommandDecorate.cpp" line="414"/>
      <location filename="../../CommandCreateDims.cpp" line="1925"/>
      <location filename="../../CommandCreateDims.cpp" line="1932"/>
      <location filename="../../CommandCreateDims.cpp" line="2133"/>
      <location filename="../../CommandCreateDims.cpp" line="2148"/>
      <location filename="../../CommandCreateDims.cpp" line="2226"/>
      <location filename="../../CommandCreateDims.cpp" line="2402"/>
      <location filename="../../CommandCreateDims.cpp" line="2418"/>
      <location filename="../../TaskDimRepair.cpp" line="124"/>
      <location filename="../../TaskDimRepair.cpp" line="136"/>
      <location filename="../../TaskDimRepair.cpp" line="147"/>
      <location filename="../../TaskDimension.cpp" line="442"/>
      <source>Incorrect Selection</source>
      <translation type="unfinished">Incorrect Selection</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2227"/>
      <source>There is no Dimension in your selection</source>
      <translation type="unfinished">There is no Dimension in your selection</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2403"/>
      <source>Can not make 2D dimension from selection</source>
      <translation type="unfinished">Can not make 2D dimension from selection</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2419"/>
      <source>Can not make 3D dimension from selection</source>
      <translation type="unfinished">Can not make 3D dimension from selection</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2433"/>
      <source>Selected edge is an Ellipse. Value will be approximate. Continue?</source>
      <translation type="unfinished">Selected edge is an Ellipse. Value will be approximate. Continue?</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2443"/>
      <source>B-spline Curve Warning</source>
      <translation type="unfinished">B-spline Curve Warning</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2444"/>
      <source>Selected edge is a B-spline. Value will be approximate. Continue?</source>
      <translation type="unfinished">Selected edge is a B-spline. Value will be approximate. Continue?</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2454"/>
      <source>B-spline Curve Error</source>
      <translation type="unfinished">B-spline Curve Error</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2455"/>
      <source>Selected edge is a B-spline and a radius/diameter can not be calculated.</source>
      <translation type="unfinished">Selected edge is a B-spline and a radius/diameter can not be calculated.</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1926"/>
      <source>There is no 3D object in your selection</source>
      <translation type="unfinished">There is no 3D object in your selection</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1933"/>
      <source>There are no 3D Edges or Vertices in your selection</source>
      <translation type="unfinished">There are no 3D Edges or Vertices in your selection</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2109"/>
      <source>Selection contains both 2D and 3D geometry</source>
      <translation type="unfinished">Selection contains both 2D and 3D geometry</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2134"/>
      <source>Can not make 2D extent dimension from selection</source>
      <translation type="unfinished">Can not make 2D extent dimension from selection</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2149"/>
      <source>Can not make 3D extent dimension from selection</source>
      <translation type="unfinished">Can not make 3D extent dimension from selection</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2280"/>
      <source>Select 2 point objects and 1 View. (1)</source>
      <translation type="unfinished">Select 2 point objects and 1 View. (1)</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2289"/>
      <source>Select 2 point objects and 1 View. (2)</source>
      <translation type="unfinished">Select 2 point objects and 1 View. (2)</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="105"/>
      <location filename="../../CommandAnnotate.cpp" line="166"/>
      <location filename="../../CommandAnnotate.cpp" line="218"/>
      <location filename="../../CommandAnnotate.cpp" line="405"/>
      <location filename="../../CommandAnnotate.cpp" line="466"/>
      <location filename="../../CommandAnnotate.cpp" line="505"/>
      <location filename="../../CommandAnnotate.cpp" line="594"/>
      <location filename="../../CommandAnnotate.cpp" line="698"/>
      <location filename="../../CommandAnnotate.cpp" line="809"/>
      <location filename="../../CommandAnnotate.cpp" line="884"/>
      <location filename="../../CommandAnnotate.cpp" line="997"/>
      <location filename="../../CommandAnnotate.cpp" line="1148"/>
      <location filename="../../CommandAnnotate.cpp" line="1301"/>
      <location filename="../../CommandAnnotate.cpp" line="1420"/>
      <location filename="../../CommandAnnotate.cpp" line="1498"/>
      <location filename="../../CommandAnnotate.cpp" line="1564"/>
      <location filename="../../CommandCreateDims.cpp" line="1515"/>
      <location filename="../../CommandCreateDims.cpp" line="1563"/>
      <location filename="../../CommandCreateDims.cpp" line="1611"/>
      <location filename="../../CommandCreateDims.cpp" line="1659"/>
      <location filename="../../CommandCreateDims.cpp" line="1707"/>
      <location filename="../../CommandCreateDims.cpp" line="1754"/>
      <location filename="../../CommandCreateDims.cpp" line="1801"/>
      <location filename="../../CommandCreateDims.cpp" line="1848"/>
      <location filename="../../CommandCreateDims.cpp" line="1979"/>
      <location filename="../../CommandCreateDims.cpp" line="2075"/>
      <location filename="../../CommandCreateDims.cpp" line="2187"/>
      <location filename="../../CommandStack.cpp" line="75"/>
      <location filename="../../CommandStack.cpp" line="191"/>
      <location filename="../../CommandStack.cpp" line="251"/>
      <location filename="../../CommandStack.cpp" line="311"/>
      <location filename="../../CommandStack.cpp" line="371"/>
      <location filename="../../CommandExtensionDims.cpp" line="327"/>
      <location filename="../../CommandExtensionDims.cpp" line="550"/>
      <location filename="../../CommandExtensionDims.cpp" line="842"/>
      <location filename="../../CommandExtensionDims.cpp" line="1170"/>
      <location filename="../../CommandExtensionDims.cpp" line="1546"/>
      <location filename="../../CommandExtensionDims.cpp" line="1939"/>
      <location filename="../../CommandExtensionDims.cpp" line="2198"/>
      <location filename="../../Command.cpp" line="741"/>
      <location filename="../../Command.cpp" line="834"/>
      <location filename="../../Command.cpp" line="897"/>
      <location filename="../../CommandExtensionPack.cpp" line="295"/>
      <location filename="../../CommandExtensionPack.cpp" line="618"/>
      <location filename="../../CommandExtensionPack.cpp" line="1121"/>
      <location filename="../../CommandExtensionPack.cpp" line="1370"/>
      <location filename="../../CommandExtensionPack.cpp" line="1676"/>
      <source>Task In Progress</source>
      <translation type="unfinished">Task In Progress</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="106"/>
      <location filename="../../CommandAnnotate.cpp" line="167"/>
      <location filename="../../CommandAnnotate.cpp" line="219"/>
      <location filename="../../CommandAnnotate.cpp" line="406"/>
      <location filename="../../CommandAnnotate.cpp" line="467"/>
      <location filename="../../CommandAnnotate.cpp" line="506"/>
      <location filename="../../CommandAnnotate.cpp" line="595"/>
      <location filename="../../CommandAnnotate.cpp" line="699"/>
      <location filename="../../CommandAnnotate.cpp" line="810"/>
      <location filename="../../CommandAnnotate.cpp" line="885"/>
      <location filename="../../CommandAnnotate.cpp" line="998"/>
      <location filename="../../CommandAnnotate.cpp" line="1149"/>
      <location filename="../../CommandAnnotate.cpp" line="1302"/>
      <location filename="../../CommandAnnotate.cpp" line="1421"/>
      <location filename="../../CommandAnnotate.cpp" line="1499"/>
      <location filename="../../CommandAnnotate.cpp" line="1565"/>
      <location filename="../../CommandCreateDims.cpp" line="1516"/>
      <location filename="../../CommandCreateDims.cpp" line="1564"/>
      <location filename="../../CommandCreateDims.cpp" line="1612"/>
      <location filename="../../CommandCreateDims.cpp" line="1660"/>
      <location filename="../../CommandCreateDims.cpp" line="1708"/>
      <location filename="../../CommandCreateDims.cpp" line="1755"/>
      <location filename="../../CommandCreateDims.cpp" line="1802"/>
      <location filename="../../CommandCreateDims.cpp" line="1849"/>
      <location filename="../../CommandCreateDims.cpp" line="1980"/>
      <location filename="../../CommandCreateDims.cpp" line="2076"/>
      <location filename="../../CommandCreateDims.cpp" line="2188"/>
      <location filename="../../CommandStack.cpp" line="76"/>
      <location filename="../../CommandStack.cpp" line="192"/>
      <location filename="../../CommandStack.cpp" line="252"/>
      <location filename="../../CommandStack.cpp" line="312"/>
      <location filename="../../CommandStack.cpp" line="372"/>
      <location filename="../../CommandExtensionDims.cpp" line="328"/>
      <location filename="../../CommandExtensionDims.cpp" line="551"/>
      <location filename="../../CommandExtensionDims.cpp" line="843"/>
      <location filename="../../CommandExtensionDims.cpp" line="1171"/>
      <location filename="../../CommandExtensionDims.cpp" line="1547"/>
      <location filename="../../CommandExtensionDims.cpp" line="1940"/>
      <location filename="../../CommandExtensionDims.cpp" line="2199"/>
      <location filename="../../Command.cpp" line="742"/>
      <location filename="../../Command.cpp" line="835"/>
      <location filename="../../Command.cpp" line="898"/>
      <location filename="../../CommandExtensionPack.cpp" line="296"/>
      <location filename="../../CommandExtensionPack.cpp" line="619"/>
      <location filename="../../CommandExtensionPack.cpp" line="1122"/>
      <location filename="../../CommandExtensionPack.cpp" line="1371"/>
      <location filename="../../CommandExtensionPack.cpp" line="1677"/>
      <source>Close active task dialog and try again.</source>
      <translation type="unfinished">Close active task dialog and try again.</translation>
    </message>
    <message>
      <location filename="../../CommandHelpers.cpp" line="110"/>
      <location filename="../../CommandHelpers.cpp" line="123"/>
      <location filename="../../CommandAnnotate.cpp" line="120"/>
      <location filename="../../CommandAnnotate.cpp" line="125"/>
      <location filename="../../CommandAnnotate.cpp" line="725"/>
      <location filename="../../CommandAnnotate.cpp" line="731"/>
      <location filename="../../CommandAnnotate.cpp" line="758"/>
      <location filename="../../CommandAnnotate.cpp" line="768"/>
      <location filename="../../CommandAnnotate.cpp" line="774"/>
      <location filename="../../CommandAnnotate.cpp" line="845"/>
      <location filename="../../CommandAnnotate.cpp" line="854"/>
      <location filename="../../CommandAnnotate.cpp" line="911"/>
      <location filename="../../CommandAnnotate.cpp" line="918"/>
      <location filename="../../CommandAnnotate.cpp" line="945"/>
      <location filename="../../CommandAnnotate.cpp" line="957"/>
      <location filename="../../CommandAnnotate.cpp" line="967"/>
      <location filename="../../CommandAnnotate.cpp" line="1027"/>
      <location filename="../../CommandAnnotate.cpp" line="1050"/>
      <location filename="../../CommandAnnotate.cpp" line="1058"/>
      <location filename="../../CommandAnnotate.cpp" line="1078"/>
      <location filename="../../CommandAnnotate.cpp" line="1114"/>
      <location filename="../../CommandAnnotate.cpp" line="1178"/>
      <location filename="../../CommandAnnotate.cpp" line="1201"/>
      <location filename="../../CommandAnnotate.cpp" line="1223"/>
      <location filename="../../CommandAnnotate.cpp" line="1259"/>
      <location filename="../../CommandAnnotate.cpp" line="1433"/>
      <location filename="../../CommandAnnotate.cpp" line="1440"/>
      <source>Wrong Selection</source>
      <translation type="unfinished">Wrong Selection</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="126"/>
      <location filename="../../CommandAnnotate.cpp" line="732"/>
      <location filename="../../CommandAnnotate.cpp" line="912"/>
      <location filename="../../CommandAnnotate.cpp" line="1051"/>
      <source>You must select a base View for the line.</source>
      <translation type="unfinished">You must select a base View for the line.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="318"/>
      <location filename="../../CommandAnnotate.cpp" line="419"/>
      <source>No DrawViewPart objects in this selection</source>
      <translation type="unfinished">No DrawViewPart objects in this selection</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="726"/>
      <location filename="../../CommandAnnotate.cpp" line="919"/>
      <source>No base View in Selection.</source>
      <translation type="unfinished">No base View in Selection.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="759"/>
      <source>You must select Faces or an existing CenterLine.</source>
      <translation type="unfinished">You must select Faces or an existing CenterLine.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="769"/>
      <source>No CenterLine in selection.</source>
      <translation type="unfinished">No CenterLine in selection.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="775"/>
      <location filename="../../CommandAnnotate.cpp" line="846"/>
      <location filename="../../CommandAnnotate.cpp" line="958"/>
      <source>Selection is not a CenterLine.</source>
      <translation type="unfinished">Selection is not a CenterLine.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="855"/>
      <source>Selection not understood.</source>
      <translation type="unfinished">Selection not understood.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="946"/>
      <source>You must select 2 Vertexes or an existing CenterLine.</source>
      <translation type="unfinished">You must select 2 Vertexes or an existing CenterLine.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="968"/>
      <source>Need 2 Vertices or 1 CenterLine.</source>
      <translation type="unfinished">Need 2 Vertices or 1 CenterLine.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1028"/>
      <location filename="../../CommandAnnotate.cpp" line="1179"/>
      <source>Selection is empty.</source>
      <translation type="unfinished">Selection is empty.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1059"/>
      <source>Not enough points in selection.</source>
      <translation type="unfinished">Not enough points in selection.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1079"/>
      <source>Selection is not a Cosmetic Line.</source>
      <translation type="unfinished">Selection is not a Cosmetic Line.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1115"/>
      <source>You must select 2 Vertexes.</source>
      <translation type="unfinished">You must select 2 Vertexes.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1202"/>
      <source>You must select a base View for the circle.</source>
      <translation type="unfinished">You must select a base View for the circle.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1260"/>
      <source>Please select a center for the circle.</source>
      <translation type="unfinished">Please select a center for the circle.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1315"/>
      <location filename="../../CommandAnnotate.cpp" line="1512"/>
      <source>Nothing selected</source>
      <translation type="unfinished">Nothing selected</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1323"/>
      <source>At least 1 object in selection is not a part view</source>
      <translation type="unfinished">At least 1 object in selection is not a part view</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1370"/>
      <source>Unknown object type in selection</source>
      <translation type="unfinished">Unknown object type in selection</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1441"/>
      <source>No View in Selection.</source>
      <translation type="unfinished">No View in Selection.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1434"/>
      <source>You must select a View and/or lines.</source>
      <translation type="unfinished">You must select a View and/or lines.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="121"/>
      <source>Can not attach leader. No base View selected.</source>
      <translation type="unfinished">Can not attach leader. No base View selected.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1224"/>
      <source>Selection is not a Cosmetic Circle or a Cosmetic Arc of Circle.</source>
      <translation type="unfinished">Selection is not a Cosmetic Circle or a Cosmetic Arc of Circle.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1519"/>
      <source>No Part Views in this selection</source>
      <translation type="unfinished">No Part Views in this selection</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1583"/>
      <source>Select exactly one Leader line or one Weld symbol.</source>
      <translation type="unfinished">Select exactly one Leader line or one Weld symbol.</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1644"/>
      <source>SurfaceFinishSymbols</source>
      <translation type="unfinished">SurfaceFinishSymbols</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1645"/>
      <source>Selected object is not a part view, nor a leader line</source>
      <translation type="unfinished">Selected object is not a part view, nor a leader line</translation>
    </message>
    <message>
      <location filename="../../CommandHelpers.cpp" line="111"/>
      <source>No Part View in Selection</source>
      <translation type="unfinished">No Part View in Selection</translation>
    </message>
    <message>
      <location filename="../../CommandHelpers.cpp" line="124"/>
      <source>No %1 in Selection</source>
      <translation type="unfinished">No %1 in Selection</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="111"/>
      <source>Replace Hatch?</source>
      <translation type="unfinished">Replace Hatch?</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="112"/>
      <source>Some Faces in selection are already hatched. Replace?</source>
      <translation type="unfinished">Some Faces in selection are already hatched. Replace?</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="335"/>
      <source>No TechDraw Page</source>
      <translation type="unfinished">No TechDraw Page</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="336"/>
      <source>Need a TechDraw Page for this command</source>
      <translation type="unfinished">Need a TechDraw Page for this command</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="388"/>
      <source>Select a Face first</source>
      <translation type="unfinished">Select a Face first</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="395"/>
      <source>No TechDraw object in selection</source>
      <translation type="unfinished">No TechDraw object in selection</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="402"/>
      <source>Create a page to insert.</source>
      <translation type="unfinished">Create a page to insert.</translation>
    </message>
    <message>
      <location filename="../../CommandDecorate.cpp" line="409"/>
      <location filename="../../CommandDecorate.cpp" line="415"/>
      <source>No Faces to hatch in this selection</source>
      <translation type="unfinished">No Faces to hatch in this selection</translation>
    </message>
    <message>
      <location filename="../../DrawGuiUtil.cpp" line="306"/>
      <location filename="../../DrawGuiUtil.cpp" line="340"/>
      <source>No page found</source>
      <translation type="unfinished">No page found</translation>
    </message>
    <message>
      <location filename="../../DrawGuiUtil.cpp" line="307"/>
      <source>No Drawing Pages available.</source>
      <translation type="unfinished">No Drawing Pages available.</translation>
    </message>
    <message>
      <location filename="../../DrawGuiUtil.cpp" line="341"/>
      <source>No Drawing Pages in document.</source>
      <translation type="unfinished">No Drawing Pages in document.</translation>
    </message>
    <message>
      <location filename="../../MDIViewPage.cpp" line="311"/>
      <source>PDF (*.pdf)</source>
      <translation type="unfinished">PDF (*.pdf)</translation>
    </message>
    <message>
      <location filename="../../MDIViewPage.cpp" line="312"/>
      <location filename="../../MDIViewPage.cpp" line="474"/>
      <source>All Files (*.*)</source>
      <translation type="unfinished">All Files (*.*)</translation>
    </message>
    <message>
      <location filename="../../MDIViewPage.cpp" line="314"/>
      <source>Export Page As PDF</source>
      <translation type="unfinished">Export Page As PDF</translation>
    </message>
    <message>
      <location filename="../../MDIViewPage.cpp" line="476"/>
      <source>Export page as SVG</source>
      <translation type="unfinished">Export page as SVG</translation>
    </message>
    <message>
      <location filename="../../ViewProviderPage.cpp" line="214"/>
      <location filename="../../ViewProviderTemplate.cpp" line="201"/>
      <location filename="../../ViewProviderProjGroup.cpp" line="157"/>
      <source>Are you sure you want to continue?</source>
      <translation type="unfinished">Are you sure you want to continue?</translation>
    </message>
    <message>
      <location filename="../../ViewProviderPage.cpp" line="235"/>
      <source>Show drawing</source>
      <translation type="unfinished">Show drawing</translation>
    </message>
    <message>
      <location filename="../../ViewProviderPage.cpp" line="237"/>
      <source>Toggle Keep Updated</source>
      <translation type="unfinished">Toggle Keep Updated</translation>
    </message>
    <message>
      <location filename="../../TemplateTextField.cpp" line="50"/>
      <source>Click to update text</source>
      <translation type="unfinished">Click to update text</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.cpp" line="219"/>
      <source>New Leader Line</source>
      <translation type="unfinished">New Leader Line</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.cpp" line="261"/>
      <source>Edit Leader Line</source>
      <translation type="unfinished">Edit Leader Line</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.cpp" line="139"/>
      <source>Rich text creator</source>
      <translation type="unfinished">Rich text creator</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.cpp" line="101"/>
      <location filename="../../TaskRichAnno.cpp" line="239"/>
      <location filename="../../QGIRichAnno.cpp" line="342"/>
      <source>Rich text editor</source>
      <translation type="unfinished">Rich text editor</translation>
    </message>
    <message>
      <location filename="../../TaskCosVertex.cpp" line="108"/>
      <source>New Cosmetic Vertex</source>
      <translation type="unfinished">New Cosmetic Vertex</translation>
    </message>
    <message>
      <location filename="../../SymbolChooser.cpp" line="61"/>
      <source>Select a symbol</source>
      <translation type="unfinished">Select a symbol</translation>
    </message>
    <message>
      <location filename="../../TaskActiveView.cpp" line="92"/>
      <source>ActiveView to TD View</source>
      <translation type="unfinished">ActiveView to TD View</translation>
    </message>
    <message>
      <location filename="../../TaskActiveView.cpp" line="108"/>
      <source>No Main Window</source>
      <translation type="unfinished">No Main Window</translation>
    </message>
    <message>
      <location filename="../../TaskActiveView.cpp" line="109"/>
      <source>Can not find the main window</source>
      <translation type="unfinished">Can not find the main window</translation>
    </message>
    <message>
      <location filename="../../TaskActiveView.cpp" line="143"/>
      <source>No 3D Viewer</source>
      <translation type="unfinished">No 3D Viewer</translation>
    </message>
    <message>
      <location filename="../../TaskActiveView.cpp" line="144"/>
      <source>Can not find a 3D viewer</source>
      <translation type="unfinished">Can not find a 3D viewer</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.cpp" line="168"/>
      <source>Create Center Line</source>
      <translation type="unfinished">Create Center Line</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.cpp" line="211"/>
      <source>Edit Center Line</source>
      <translation type="unfinished">Edit Center Line</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.cpp" line="127"/>
      <source>Create Section View</source>
      <translation type="unfinished">Create Section View</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.cpp" line="153"/>
      <source>No direction set</source>
      <translation type="unfinished">No direction set</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.cpp" line="159"/>
      <source>Edit Section View</source>
      <translation type="unfinished">Edit Section View</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.cpp" line="137"/>
      <source>New Complex Section</source>
      <translation type="unfinished">New Complex Section</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.cpp" line="178"/>
      <source>Edit Complex Section</source>
      <translation type="unfinished">Edit Complex Section</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.cpp" line="216"/>
      <location filename="../../TaskSectionView.cpp" line="230"/>
      <source>Current View Direction</source>
      <translation type="unfinished">Current View Direction</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.cpp" line="217"/>
      <location filename="../../TaskSectionView.cpp" line="231"/>
      <source>The view direction in BaseView coordinates</source>
      <translation type="unfinished">The view direction in BaseView coordinates</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.cpp" line="715"/>
      <location filename="../../TaskSectionView.cpp" line="640"/>
      <source>Operation Failed</source>
      <translation type="unfinished">Operation Failed</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.cpp" line="166"/>
      <source>Create Welding Symbol</source>
      <translation type="unfinished">Create Welding Symbol</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.cpp" line="185"/>
      <source>Edit Welding Symbol</source>
      <translation type="unfinished">Edit Welding Symbol</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticLine.cpp" line="113"/>
      <source>Create Cosmetic Line</source>
      <translation type="unfinished">Create Cosmetic Line</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticLine.cpp" line="155"/>
      <source>Edit Cosmetic Line</source>
      <translation type="unfinished">Edit Cosmetic Line</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.cpp" line="98"/>
      <source>New Detail View</source>
      <translation type="unfinished">New Detail View</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.cpp" line="178"/>
      <source>Edit Detail View</source>
      <translation type="unfinished">Edit Detail View</translation>
    </message>
    <message>
      <location filename="../../ViewProviderDimension.cpp" line="127"/>
      <location filename="../../ViewProviderBalloon.cpp" line="87"/>
      <source>Edit %1</source>
      <translation type="unfinished">Edit %1</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="438"/>
      <source>TechDraw Increase/Decrease Decimal</source>
      <translation type="unfinished">TechDraw Increase/Decrease Decimal</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="633"/>
      <location filename="../../CommandExtensionDims.cpp" line="642"/>
      <source>TechDraw PosHorizChainDimension</source>
      <translation type="unfinished">TechDraw PosHorizChainDimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="643"/>
      <location filename="../../CommandExtensionDims.cpp" line="952"/>
      <source>No horizontal dimensions selected</source>
      <translation type="unfinished">No horizontal dimensions selected</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="694"/>
      <location filename="../../CommandExtensionDims.cpp" line="703"/>
      <source>TechDraw PosVertChainDimension</source>
      <translation type="unfinished">TechDraw PosVertChainDimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="704"/>
      <location filename="../../CommandExtensionDims.cpp" line="1018"/>
      <source>No vertical dimensions selected</source>
      <translation type="unfinished">No vertical dimensions selected</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="756"/>
      <location filename="../../CommandExtensionDims.cpp" line="765"/>
      <source>TechDraw PosObliqueChainDimension</source>
      <translation type="unfinished">TechDraw PosObliqueChainDimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="766"/>
      <location filename="../../CommandExtensionDims.cpp" line="1085"/>
      <source>No oblique dimensions selected</source>
      <translation type="unfinished">No oblique dimensions selected</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="942"/>
      <location filename="../../CommandExtensionDims.cpp" line="951"/>
      <source>TechDraw CascadeHorizDimension</source>
      <translation type="unfinished">TechDraw CascadeHorizDimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1008"/>
      <location filename="../../CommandExtensionDims.cpp" line="1017"/>
      <source>TechDraw CascadeVertDimension</source>
      <translation type="unfinished">TechDraw CascadeVertDimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1075"/>
      <location filename="../../CommandExtensionDims.cpp" line="1084"/>
      <source>TechDraw CascadeObliqueDimension</source>
      <translation type="unfinished">TechDraw CascadeObliqueDimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1274"/>
      <source>TechDraw Create Horizontal Chain Dimension</source>
      <translation type="unfinished">TechDraw Create Horizontal Chain Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1340"/>
      <source>TechDraw Create Vertical Chain Dimension</source>
      <translation type="unfinished">TechDraw Create Vertical Chain Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1406"/>
      <source>TechDraw Create Oblique Chain Dimension</source>
      <translation type="unfinished">TechDraw Create Oblique Chain Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1645"/>
      <source>TechDraw Create Horizontal Coord Dimension</source>
      <translation type="unfinished">TechDraw Create Horizontal Coord Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1718"/>
      <source>TechDraw Create Vertical Coord Dimension</source>
      <translation type="unfinished">TechDraw Create Vertical Coord Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="1791"/>
      <source>TechDraw Create Oblique Coord Dimension</source>
      <translation type="unfinished">TechDraw Create Oblique Coord Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2044"/>
      <source>TechDraw Create Horizontal Chamfer Dimension</source>
      <translation type="unfinished">TechDraw Create Horizontal Chamfer Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2113"/>
      <source>TechDraw Create Vertical Chamfer Dimension</source>
      <translation type="unfinished">TechDraw Create Vertical Chamfer Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2299"/>
      <source>TechDraw Create Arc Length Dimension</source>
      <translation type="unfinished">TechDraw Create Arc Length Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2349"/>
      <source>TechDraw Customize Format</source>
      <translation type="unfinished">TechDraw Customize Format</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2458"/>
      <source>No subelements selected</source>
      <translation type="unfinished">No subelements selected</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2422"/>
      <location filename="../../CommandExtensionPack.cpp" line="2065"/>
      <source>Selection is empty</source>
      <translation type="unfinished">Selection is empty</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="2438"/>
      <location filename="../../CommandExtensionPack.cpp" line="2072"/>
      <source>No object selected</source>
      <translation type="unfinished">No object selected</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="123"/>
      <source>TechDraw Hole Circle</source>
      <translation type="unfinished">TechDraw Hole Circle</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="124"/>
      <source>Fewer than three circles selected</source>
      <translation type="unfinished">Fewer than three circles selected</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1796"/>
      <source>No faces in selection.</source>
      <translation type="unfinished">No faces in selection.</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1926"/>
      <source>No edges in selection.</source>
      <translation type="unfinished">No edges in selection.</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="2150"/>
      <source>TechDraw Thread Hole Side</source>
      <translation type="unfinished">TechDraw Thread Hole Side</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="2151"/>
      <source>Please select two straight lines</source>
      <translation type="unfinished">Please select two straight lines</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.cpp" line="146"/>
      <location filename="../../TaskDimension.cpp" line="161"/>
      <source>Missing Dimension</source>
      <translation type="unfinished">Missing Dimension</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.cpp" line="147"/>
      <location filename="../../TaskDimension.cpp" line="162"/>
      <source>Dimension not found. Was it deleted? Can not continue.</source>
      <translation type="unfinished">Dimension not found. Was it deleted? Can not continue.</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.cpp" line="443"/>
      <source>Select 2 Vertexes or 1 Edge</source>
      <translation type="unfinished">Select 2 Vertexes or 1 Edge</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotationImp.cpp" line="231"/>
      <source>Please select a Line Group</source>
      <translation type="unfinished">Please select a Line Group</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotationImp.cpp" line="242"/>
      <source>%1 defines these line widths:
 thin: %2
 graphic: %3
 thick: %4</source>
      <translation type="unfinished">%1 defines these line widths:
 thin: %2
 graphic: %3
 thick: %4</translation>
    </message>
    <message>
      <location filename="../../TaskHatch.cpp" line="97"/>
      <source>Create Face Hatch</source>
      <translation type="unfinished">Create Face Hatch</translation>
    </message>
    <message>
      <location filename="../../TaskHatch.cpp" line="109"/>
      <source>Edit Face Hatch</source>
      <translation type="unfinished">Edit Face Hatch</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.cpp" line="277"/>
      <source>Method</source>
      <translation type="unfinished">Method</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.cpp" line="283"/>
      <source>Addition</source>
      <translation type="unfinished">Addition</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.cpp" line="292"/>
      <source>Average roughness</source>
      <translation type="unfinished">Average roughness</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.cpp" line="298"/>
      <source>Roughness sampling length</source>
      <translation type="unfinished">Roughness sampling length</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.cpp" line="307"/>
      <source>Lay symbol</source>
      <translation type="unfinished">Lay symbol</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.cpp" line="315"/>
      <source>Minimum roughness grade number</source>
      <translation type="unfinished">Minimum roughness grade number</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.cpp" line="325"/>
      <source>Maximum roughness grade number</source>
      <translation type="unfinished">Maximum roughness grade number</translation>
    </message>
    <message>
      <location filename="../../TaskDimRepair.cpp" line="66"/>
      <source>Dimension Repair</source>
      <translation type="unfinished">Dimension Repair</translation>
    </message>
    <message>
      <location filename="../../TaskDimRepair.cpp" line="125"/>
      <source>Can not use references from a different View</source>
      <translation type="unfinished">Can not use references from a different View</translation>
    </message>
    <message>
      <location filename="../../TaskDimRepair.cpp" line="137"/>
      <location filename="../../TaskDimRepair.cpp" line="148"/>
      <source>Can not make dimension from selection</source>
      <translation type="unfinished">Can not make dimension from selection</translation>
    </message>
    <message>
      <location filename="../../AppTechDrawGui.cpp" line="170"/>
      <location filename="../../AppTechDrawGui.cpp" line="171"/>
      <location filename="../../AppTechDrawGui.cpp" line="172"/>
      <location filename="../../AppTechDrawGui.cpp" line="173"/>
      <location filename="../../AppTechDrawGui.cpp" line="174"/>
      <location filename="../../AppTechDrawGui.cpp" line="175"/>
      <location filename="../../AppTechDrawGui.cpp" line="176"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.cpp" line="119"/>
      <source>Create Cosmetic Circle</source>
      <translation type="unfinished">Create Cosmetic Circle</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.cpp" line="163"/>
      <source>Edit Cosmetic Circle</source>
      <translation type="unfinished">Edit Cosmetic Circle</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.cpp" line="183"/>
      <source>Parameter Error</source>
      <translation type="unfinished">Parameter Error</translation>
    </message>
    <message>
      <location filename="../../PagePrinter.cpp" line="262"/>
      <source>Document Name:</source>
      <translation type="unfinished">Document Name:</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.cpp" line="181"/>
      <source>Projection Group</source>
      <translation type="unfinished">Projection Group</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.cpp" line="191"/>
      <source>Part View</source>
      <translation type="unfinished">Part View</translation>
    </message>
  </context>
  <context>
    <name>Std_Delete</name>
    <message>
      <location filename="../../ViewProviderLeader.cpp" line="211"/>
      <source>You cannot delete this leader line because
it has a weld symbol that would become broken.</source>
      <translation type="unfinished">You cannot delete this leader line because
it has a weld symbol that would become broken.</translation>
    </message>
    <message>
      <location filename="../../ViewProviderViewPart.cpp" line="371"/>
      <source>You cannot delete this view because it has one or more dependent views that would become broken.</source>
      <translation type="unfinished">You cannot delete this view because it has one or more dependent views that would become broken.</translation>
    </message>
    <message>
      <location filename="../../ViewProviderViewPart.cpp" line="374"/>
      <location filename="../../ViewProviderProjGroupItem.cpp" line="155"/>
      <location filename="../../ViewProviderProjGroupItem.cpp" line="164"/>
      <location filename="../../ViewProviderProjGroupItem.cpp" line="172"/>
      <location filename="../../ViewProviderProjGroupItem.cpp" line="180"/>
      <location filename="../../ViewProviderLeader.cpp" line="214"/>
      <location filename="../../ViewProviderWeld.cpp" line="145"/>
      <location filename="../../ViewProviderPage.cpp" line="217"/>
      <location filename="../../ViewProviderTemplate.cpp" line="205"/>
      <location filename="../../ViewProviderProjGroup.cpp" line="143"/>
      <location filename="../../ViewProviderProjGroup.cpp" line="160"/>
      <source>Object dependencies</source>
      <translation type="unfinished">Object dependencies</translation>
    </message>
    <message>
      <location filename="../../ViewProviderProjGroupItem.cpp" line="152"/>
      <source>You cannot delete the anchor view of a projection group.</source>
      <translation type="unfinished">You cannot delete the anchor view of a projection group.</translation>
    </message>
    <message>
      <location filename="../../ViewProviderProjGroupItem.cpp" line="161"/>
      <source>You cannot delete this view because it has a section view that would become broken.</source>
      <translation type="unfinished">You cannot delete this view because it has a section view that would become broken.</translation>
    </message>
    <message>
      <location filename="../../ViewProviderProjGroupItem.cpp" line="169"/>
      <source>You cannot delete this view because it has a detail view that would become broken.</source>
      <translation type="unfinished">You cannot delete this view because it has a detail view that would become broken.</translation>
    </message>
    <message>
      <location filename="../../ViewProviderProjGroupItem.cpp" line="177"/>
      <source>You cannot delete this view because it has a leader line that would become broken.</source>
      <translation type="unfinished">You cannot delete this view because it has a leader line that would become broken.</translation>
    </message>
    <message>
      <location filename="../../ViewProviderPage.cpp" line="208"/>
      <source>The page is not empty, therefore the
following referencing objects might be lost:</source>
      <translation type="unfinished">The page is not empty, therefore the
following referencing objects might be lost:</translation>
    </message>
    <message>
      <location filename="../../ViewProviderProjGroup.cpp" line="136"/>
      <source>The group cannot be deleted because its items have the following
section or detail views, or leader lines that would get broken:</source>
      <translation type="unfinished">The group cannot be deleted because its items have the following
section or detail views, or leader lines that would get broken:</translation>
    </message>
    <message>
      <location filename="../../ViewProviderProjGroup.cpp" line="151"/>
      <source>The projection group is not empty, therefore
the following referencing objects might be lost:</source>
      <translation type="unfinished">The projection group is not empty, therefore
the following referencing objects might be lost:</translation>
    </message>
    <message>
      <location filename="../../ViewProviderTemplate.cpp" line="198"/>
      <source>The following referencing object might break:</source>
      <translation type="unfinished">The following referencing object might break:</translation>
    </message>
    <message>
      <location filename="../../ViewProviderWeld.cpp" line="142"/>
      <source>You cannot delete this weld symbol because
it has a tile weld that would become broken.</source>
      <translation type="unfinished">You cannot delete this weld symbol because
it has a tile weld that would become broken.</translation>
    </message>
  </context>
  <context>
    <name>TaskActiveView</name>
    <message>
      <location filename="../../TaskActiveView.ui" line="26"/>
      <source>ActiveView to TD View</source>
      <translation type="unfinished">ActiveView to TD View</translation>
    </message>
    <message>
      <location filename="../../TaskActiveView.ui" line="44"/>
      <source>If Crop Image is checked, crop captured image to this width.</source>
      <translation type="unfinished">If Crop Image is checked, crop captured image to this width.</translation>
    </message>
    <message>
      <location filename="../../TaskActiveView.ui" line="72"/>
      <source>Select a color for solid background</source>
      <translation type="unfinished">Select a color for solid background</translation>
    </message>
    <message>
      <location filename="../../TaskActiveView.ui" line="92"/>
      <source>Crop To Height</source>
      <translation type="unfinished">Crop To Height</translation>
    </message>
    <message>
      <location filename="../../TaskActiveView.ui" line="99"/>
      <source>Use 3D Background</source>
      <translation type="unfinished">Use 3D Background</translation>
    </message>
    <message>
      <location filename="../../TaskActiveView.ui" line="115"/>
      <source>If Crop Image is checked, crop captured image to this height.</source>
      <translation type="unfinished">If Crop Image is checked, crop captured image to this height.</translation>
    </message>
    <message>
      <location filename="../../TaskActiveView.ui" line="137"/>
      <source>Solid Background</source>
      <translation type="unfinished">Solid Background</translation>
    </message>
    <message>
      <location filename="../../TaskActiveView.ui" line="147"/>
      <source>No Background</source>
      <translation type="unfinished">No Background</translation>
    </message>
    <message>
      <location filename="../../TaskActiveView.ui" line="160"/>
      <source>Crop To Width</source>
      <translation type="unfinished">Crop To Width</translation>
    </message>
    <message>
      <location filename="../../TaskActiveView.ui" line="167"/>
      <source>Crop Image</source>
      <translation type="unfinished">Crop Image</translation>
    </message>
    <message>
      <location filename="../../TaskActiveView.ui" line="134"/>
      <source>Paint background yes/no</source>
      <translation type="unfinished">Paint background yes/no</translation>
    </message>
  </context>
  <context>
    <name>TaskMoveView</name>
    <message>
      <location filename="../../TaskMoveView.ui" line="14"/>
      <source>Move View</source>
      <translation type="unfinished">Move View</translation>
    </message>
    <message>
      <location filename="../../TaskMoveView.ui" line="22"/>
      <source>View to move</source>
      <translation type="unfinished">View to move</translation>
    </message>
    <message>
      <location filename="../../TaskMoveView.ui" line="43"/>
      <source>From Page</source>
      <translation type="unfinished">From Page</translation>
    </message>
    <message>
      <location filename="../../TaskMoveView.ui" line="64"/>
      <source>To Page</source>
      <translation type="unfinished">To Page</translation>
    </message>
  </context>
  <context>
    <name>TaskPojGroup</name>
    <message>
      <location filename="../../TaskComplexSection.cpp" line="487"/>
      <source> updates pending</source>
      <translation type="unfinished"> updates pending</translation>
    </message>
  </context>
  <context>
    <name>TaskWeldingSymbol</name>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="26"/>
      <source>Welding Symbol</source>
      <translation type="unfinished">Welding Symbol</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="42"/>
      <source>Text above arrow side symbol
Angle, surface finish, root</source>
      <translation type="unfinished">Text above arrow side symbol
Angle, surface finish, root</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="50"/>
      <source>Text before arrow side symbol
Preparation depth, (weld size)</source>
      <translation type="unfinished">Text before arrow side symbol
Preparation depth, (weld size)</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="76"/>
      <source>Pick arrow side symbol</source>
      <translation type="unfinished">Pick arrow side symbol</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="82"/>
      <location filename="../../TaskWeldingSymbol.ui" line="132"/>
      <source>Symbol</source>
      <translation type="unfinished">Symbol</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="92"/>
      <source>Text after arrow side symbol
Number of welds × length, (gap)</source>
      <translation type="unfinished">Text after arrow side symbol
Number of welds × length, (gap)</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="121"/>
      <source>Text before other side symbol
Preparation depth, (weld size)</source>
      <translation type="unfinished">Text before other side symbol
Preparation depth, (weld size)</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="129"/>
      <source>Pick other side symbol</source>
      <translation type="unfinished">Pick other side symbol</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="139"/>
      <source>Text after other side symbol
Number of welds × length, (gap)</source>
      <translation type="unfinished">Text after other side symbol
Number of welds × length, (gap)</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="171"/>
      <source>Remove other side symbol</source>
      <translation type="unfinished">Remove other side symbol</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="174"/>
      <source>Delete</source>
      <translation type="unfinished">Delete</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="181"/>
      <source>Text below arrow side symbol
Angle, surface finish, root</source>
      <translation type="unfinished">Text below arrow side symbol
Angle, surface finish, root</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="213"/>
      <source>Flips the sides</source>
      <translation type="unfinished">Flips the sides</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="216"/>
      <source>Flip Sides</source>
      <translation type="unfinished">Flip Sides</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="238"/>
      <source>Adds the &apos;Field Weld&apos; symbol (flag)
at the kink in the leader line</source>
      <translation type="unfinished">Adds the &apos;Field Weld&apos; symbol (flag)
at the kink in the leader line</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="242"/>
      <source>Field Weld</source>
      <translation type="unfinished">Field Weld</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="249"/>
      <source>Adds the &apos;All Around&apos; symbol (circle)
at the kink in the leader line</source>
      <translation type="unfinished">Adds the &apos;All Around&apos; symbol (circle)
at the kink in the leader line</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="253"/>
      <source>All Around</source>
      <translation type="unfinished">All Around</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="260"/>
      <source>Offsets the lower symbol to indicate alternating welds</source>
      <translation type="unfinished">Offsets the lower symbol to indicate alternating welds</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="263"/>
      <source>Alternating</source>
      <translation type="unfinished">Alternating</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="274"/>
      <source>Tail Text</source>
      <translation type="unfinished">Tail Text</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="287"/>
      <source>Text at end of symbol</source>
      <translation type="unfinished">Text at end of symbol</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="294"/>
      <source>Symbol Directory</source>
      <translation type="unfinished">Symbol Directory</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.ui" line="301"/>
      <source>Directory path for welding symbols.
This directory will be used for the symbol selection.</source>
      <translation type="unfinished">Directory path for welding symbols.
This directory will be used for the symbol selection.</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::DlgPageChooser</name>
    <message>
      <location filename="../../DlgPageChooser.ui" line="17"/>
      <source>Page Chooser</source>
      <translation type="unfinished">Page Chooser</translation>
    </message>
    <message>
      <location filename="../../DlgPageChooser.ui" line="29"/>
      <source>FreeCAD could not determine which Page to use. Please select a Page.</source>
      <translation type="unfinished">FreeCAD could not determine which Page to use. Please select a Page.</translation>
    </message>
    <message>
      <location filename="../../DlgPageChooser.ui" line="39"/>
      <source>Select a Page that should be used</source>
      <translation type="unfinished">Select a Page that should be used</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::DlgPrefsTechDrawAdvancedImp</name>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="14"/>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="26"/>
      <source>Advanced</source>
      <translation type="unfinished">Advanced</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="129"/>
      <source>If checked, TechDraw will attempt to build faces using the
line segments returned by the hidden line removal algorithm.
Faces must be detected in order to use hatching, but there
can be a performance penalty in complex models.</source>
      <translation type="unfinished">If checked, TechDraw will attempt to build faces using the
line segments returned by the hidden line removal algorithm.
Faces must be detected in order to use hatching, but there
can be a performance penalty in complex models.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="135"/>
      <source>Detect Faces</source>
      <translation type="unfinished">Detect Faces</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="440"/>
      <source>Highlights border of section cut in section views</source>
      <translation type="unfinished">Highlights border of section cut in section views</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="443"/>
      <source>Show Section Edges</source>
      <translation type="unfinished">Show Section Edges</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="59"/>
      <source>Dump intermediate results during Section view processing</source>
      <translation type="unfinished">Dump intermediate results during Section view processing</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="34"/>
      <source>If this box is checked, double-clicking on a page in the tree will automatically switch to TechDraw and the page will be made visible.</source>
      <translation type="unfinished">If this box is checked, double-clicking on a page in the tree will automatically switch to TechDraw and the page will be made visible.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="37"/>
      <source>Switch Workbench on Click</source>
      <translation type="unfinished">Switch Workbench on Click</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="62"/>
      <source>Debug Section</source>
      <translation type="unfinished">Debug Section</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="82"/>
      <source>If checked, FreeCAD will use the new face finder algorithm.  If not checked, FreeCAD will use the legacy face finder algorithm.</source>
      <translation type="unfinished">If checked, FreeCAD will use the new face finder algorithm.  If not checked, FreeCAD will use the legacy face finder algorithm.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="107"/>
      <source>Dump intermediate results during Detail view processing</source>
      <translation type="unfinished">Dump intermediate results during Detail view processing</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="110"/>
      <source>Debug Detail</source>
      <translation type="unfinished">Debug Detail</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="151"/>
      <source>If checked, the system will attempt to automatically correct dimension references when the model changes.</source>
      <translation type="unfinished">If checked, the system will attempt to automatically correct dimension references when the model changes.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="173"/>
      <source>If checked, input shapes will be checked for errors before use and invalid shapes will be skipped by the shape extractor. Checking for errors is slower, but can prevent crashes from some geometry problems.
</source>
      <translation type="unfinished">If checked, input shapes will be checked for errors before use and invalid shapes will be skipped by the shape extractor. Checking for errors is slower, but can prevent crashes from some geometry problems.
</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="177"/>
      <source>Validate Shapes</source>
      <translation type="unfinished">Validate Shapes</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="196"/>
      <source>Include edges with unexpected geometry (zero length etc.) in results</source>
      <translation type="unfinished">Include edges with unexpected geometry (zero length etc.) in results</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="199"/>
      <source>Allow Crazy Edges</source>
      <translation type="unfinished">Allow Crazy Edges</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="308"/>
      <source>If checked, shapes that fail validation will be saved as BREP files for later analysis.</source>
      <translation type="unfinished">If checked, shapes that fail validation will be saved as BREP files for later analysis.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="311"/>
      <source>Debug Bad Shape</source>
      <translation type="unfinished">Debug Bad Shape</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="335"/>
      <source>Perform a fuse operation on input shape(s) before Section view processing</source>
      <translation type="unfinished">Perform a fuse operation on input shape(s) before Section view processing</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="338"/>
      <source>Fuse Before Section</source>
      <translation type="unfinished">Fuse Before Section</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="466"/>
      <source>Limit of 64x64 pixel SVG tiles used to hatch a single face.
For large scalings, you might get an error about too many SVG tiles.
Then you need to increase the tile limit.</source>
      <translation type="unfinished">Limit of 64x64 pixel SVG tiles used to hatch a single face.
For large scalings, you might get an error about too many SVG tiles.
Then you need to increase the tile limit.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="501"/>
      <source>Some combinations of OS and Navigation style key bindings may conflict with the default modifier keys for Balloon dragging and View snapping override. You can make adjustments here to find a non-conflicting key binding.</source>
      <translation type="unfinished">Some combinations of OS and Navigation style key bindings may conflict with the default modifier keys for Balloon dragging and View snapping override. You can make adjustments here to find a non-conflicting key binding.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="512"/>
      <source>Check this box to use the default modifier keys. Uncheck this box to set a different key combination.</source>
      <translation type="unfinished">Check this box to use the default modifier keys. Uncheck this box to set a different key combination.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="75"/>
      <source>Edge Fuzz</source>
      <translation type="unfinished">Edge Fuzz</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="411"/>
      <source>Size of selection area around edges
Each unit is approx. 0.1 mm wide</source>
      <translation type="unfinished">Size of selection area around edges
Each unit is approx. 0.1 mm wide</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="265"/>
      <source>Mark Fuzz</source>
      <translation type="unfinished">Mark Fuzz</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="363"/>
      <source>Selection area around center marks
Each unit is approx. 0.1 mm wide</source>
      <translation type="unfinished">Selection area around center marks
Each unit is approx. 0.1 mm wide</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="157"/>
      <source>Auto Correct Dimension Refs</source>
      <translation type="unfinished">Auto Correct Dimension Refs</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="85"/>
      <source>Use New Face Finder Algorithm</source>
      <translation type="unfinished">Use New Face Finder Algorithm</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="228"/>
      <source>The number of times FreeCAD should try to remove overlapping edges returned by the Hidden Line Removal algorithm. A value of 0 indicates no scrubbing, 1 indicates a single pass and 2 indicates a second pass should be performed. Values above 2 are generally not productive. Each pass adds to the time required to produce the drawing.</source>
      <translation type="unfinished">The number of times FreeCAD should try to remove overlapping edges returned by the Hidden Line Removal algorithm. A value of 0 indicates no scrubbing, 1 indicates a single pass and 2 indicates a second pass should be performed. Values above 2 are generally not productive. Each pass adds to the time required to produce the drawing.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="301"/>
      <source>Max SVG Hatch Tiles</source>
      <translation type="unfinished">Max SVG Hatch Tiles</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="459"/>
      <source>Max PAT Hatch Segments</source>
      <translation type="unfinished">Max PAT Hatch Segments</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="272"/>
      <source>Maximum hatch line segments to use
when hatching a face with a PAT pattern</source>
      <translation type="unfinished">Maximum hatch line segments to use
when hatching a face with a PAT pattern</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="212"/>
      <source>Issue progress messages while building View geometry</source>
      <translation type="unfinished">Issue progress messages while building View geometry</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="215"/>
      <source>Report Progress</source>
      <translation type="unfinished">Report Progress</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="258"/>
      <source>Overlap Edges Scrub Passes</source>
      <translation type="unfinished">Overlap Edges Scrub Passes</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="504"/>
      <source>Behaviour Overrides</source>
      <translation type="unfinished">Behaviour Overrides</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="515"/>
      <source>Use Default</source>
      <translation type="unfinished">Use Default</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="532"/>
      <source>Balloon Drag</source>
      <translation type="unfinished">Balloon Drag</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="539"/>
      <source>Check this box to include the Alt key in the modifiers.</source>
      <translation type="unfinished">Check this box to include the Alt key in the modifiers.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="542"/>
      <source>Alt</source>
      <translation type="unfinished">Alt</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="549"/>
      <source>Check this box to include the Shift key in the modifiers.</source>
      <translation type="unfinished">Check this box to include the Shift key in the modifiers.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="552"/>
      <source>Shift</source>
      <translation type="unfinished">Shift</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="559"/>
      <source>Check this box to include the Meta/Start/Super key in the modifiers.</source>
      <translation type="unfinished">Check this box to include the Meta/Start/Super key in the modifiers.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="562"/>
      <source>Meta</source>
      <translation type="unfinished">Meta</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="569"/>
      <source>Check this box to include the Control key in the modifiers.</source>
      <translation type="unfinished">Check this box to include the Control key in the modifiers.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="572"/>
      <source>Control</source>
      <translation type="unfinished">Control</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAdvanced.ui" line="590"/>
      <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Note:&lt;/span&gt; Items in &lt;span style=&quot; font-style:italic;&quot;&gt;italics&lt;/span&gt; are default values for new objects. They have no effect on existing objects.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
      <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Note:&lt;/span&gt; Items in &lt;span style=&quot; font-style:italic;&quot;&gt;italics&lt;/span&gt; are default values for new objects. They have no effect on existing objects.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::DlgPrefsTechDrawAnnotationImp</name>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="20"/>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="26"/>
      <source>Annotation</source>
      <translation type="unfinished">Annotation</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="643"/>
      <source>Section Line Style</source>
      <translation type="unfinished">Section Line Style</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="410"/>
      <source>Section Cut Surface</source>
      <translation type="unfinished">Section Cut Surface</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="224"/>
      <source>Default appearance of cut surface in section view</source>
      <translation type="unfinished">Default appearance of cut surface in section view</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="237"/>
      <source>Hide</source>
      <translation type="unfinished">Hide</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="242"/>
      <source>Solid Color</source>
      <translation type="unfinished">Solid Color</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="247"/>
      <source>SVG Hatch</source>
      <translation type="unfinished">SVG Hatch</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="252"/>
      <source>PAT Hatch</source>
      <translation type="unfinished">PAT Hatch</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="91"/>
      <source>If checked, the section annotation will be drawn on the Source view.  If unchecked, no section line, arrows or symbol will be shown in the Source view.</source>
      <translation type="unfinished">If checked, the section annotation will be drawn on the Source view.  If unchecked, no section line, arrows or symbol will be shown in the Source view.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="94"/>
      <source>Show Section Line in Source View</source>
      <translation type="unfinished">Show Section Line in Source View</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="279"/>
      <source>This checkbox controls whether or not to display a highlight around the detail area in the detail&apos;s source view.</source>
      <translation type="unfinished">This checkbox controls whether or not to display a highlight around the detail area in the detail&apos;s source view.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="282"/>
      <source>Detail Source Show Highlight</source>
      <translation type="unfinished">Detail Source Show Highlight</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="134"/>
      <source>If checked, the cut line will be drawn on the Source view.  If unchecked, only the change marks, arrows and symbols will be displayed.</source>
      <translation type="unfinished">If checked, the cut line will be drawn on the Source view.  If unchecked, only the change marks, arrows and symbols will be displayed.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="137"/>
      <source>Include Cut Line in Section Annotation</source>
      <translation type="unfinished">Include Cut Line in Section Annotation</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="180"/>
      <source>Balloon Leader Kink Length</source>
      <translation type="unfinished">Balloon Leader Kink Length</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="192"/>
      <source>Broken View Break Type</source>
      <translation type="unfinished">Broken View Break Type</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="375"/>
      <source>No Break Lines</source>
      <translation type="unfinished">No Break Lines</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="380"/>
      <source>ZigZag Lines</source>
      <translation type="unfinished">ZigZag Lines</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="385"/>
      <source>Simple Lines</source>
      <translation type="unfinished">Simple Lines</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="482"/>
      <source>If this box is checked, templates will auto fill date fields using ccyy-mm-dd format even if that is not the standard format for the current locale.</source>
      <translation type="unfinished">If this box is checked, templates will auto fill date fields using ccyy-mm-dd format even if that is not the standard format for the current locale.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="485"/>
      <source>Enforce ISO 8601 Date Format</source>
      <translation type="unfinished">Enforce ISO 8601 Date Format</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="509"/>
      <source>Lines</source>
      <translation type="unfinished">Lines</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="563"/>
      <source>Standard to be used to draw non-continuous lines.</source>
      <translation type="unfinished">Standard to be used to draw non-continuous lines.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="698"/>
      <source>Shape of line end caps.  The default (round) should almost
always be the right choice.  Flat or square caps are useful
if you are planning to use a drawing as a 1:1 cutting guide.
</source>
      <translation type="unfinished">Shape of line end caps.  The default (round) should almost
always be the right choice.  Flat or square caps are useful
if you are planning to use a drawing as a 1:1 cutting guide.
</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="765"/>
      <source>Line group used to set line widths</source>
      <translation type="unfinished">Line group used to set line widths</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="768"/>
      <source>Line Width Group</source>
      <translation type="unfinished">Line Width Group</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="303"/>
      <source>Detail View Outline Shape</source>
      <translation type="unfinished">Detail View Outline Shape</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="423"/>
      <source>Outline shape for detail views</source>
      <translation type="unfinished">Outline shape for detail views</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="716"/>
      <source>Square</source>
      <translation type="unfinished">Square</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="628"/>
      <source>Line style of detail highlight on base view</source>
      <translation type="unfinished">Line style of detail highlight on base view</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="631"/>
      <source>Detail Highlight Style</source>
      <translation type="unfinished">Detail Highlight Style</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="550"/>
      <source>Center Line Style</source>
      <translation type="unfinished">Center Line Style</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="398"/>
      <source>Balloon Shape</source>
      <translation type="unfinished">Balloon Shape</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="116"/>
      <source>Shape of balloon annotations</source>
      <translation type="unfinished">Shape of balloon annotations</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="358"/>
      <source>Balloon Leader End</source>
      <translation type="unfinished">Balloon Leader End</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="260"/>
      <source>This checkbox controls whether or not to display the outline around a detail view.</source>
      <translation type="unfinished">This checkbox controls whether or not to display the outline around a detail view.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="263"/>
      <source>Detail View Show Matting</source>
      <translation type="unfinished">Detail View Show Matting</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="159"/>
      <source>Style for balloon leader line ends</source>
      <translation type="unfinished">Style for balloon leader line ends</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="177"/>
      <source>Length of horizontal portion of Balloon leader</source>
      <translation type="unfinished">Length of horizontal portion of Balloon leader</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="466"/>
      <source>Length of balloon leader line kink</source>
      <translation type="unfinished">Length of balloon leader line kink</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="205"/>
      <source>Restrict Filled Triangle line end to vertical or horizontal directions</source>
      <translation type="unfinished">Restrict Filled Triangle line end to vertical or horizontal directions</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="208"/>
      <source>Balloon Orthogonal Triangle</source>
      <translation type="unfinished">Balloon Orthogonal Triangle</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="321"/>
      <source>Forces last leader line segment to be horizontal</source>
      <translation type="unfinished">Forces last leader line segment to be horizontal</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="324"/>
      <source>Leader Line Auto Horizontal</source>
      <translation type="unfinished">Leader Line Auto Horizontal</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="67"/>
      <source>Show arc center marks in views</source>
      <translation type="unfinished">Show arc center marks in views</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="70"/>
      <source>Show Center Marks</source>
      <translation type="unfinished">Show Center Marks</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="40"/>
      <source>Show arc centers in printed output</source>
      <translation type="unfinished">Show arc centers in printed output</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="43"/>
      <source>Print Center Marks</source>
      <translation type="unfinished">Print Center Marks</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="441"/>
      <source>Show or hide marks at direction changes on ComplexSection lines.</source>
      <translation type="unfinished">Show or hide marks at direction changes on ComplexSection lines.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="444"/>
      <source>Complex Section Line Marks</source>
      <translation type="unfinished">Complex Section Line Marks</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="787"/>
      <source>Hidden Line Style</source>
      <translation type="unfinished">Hidden Line Style</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="680"/>
      <source>Line Standard</source>
      <translation type="unfinished">Line Standard</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="780"/>
      <source>Line End Cap Shape</source>
      <translation type="unfinished">Line End Cap Shape</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="711"/>
      <source>Round</source>
      <translation type="unfinished">Round</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="721"/>
      <source>Flat</source>
      <translation type="unfinished">Flat</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="812"/>
      <source>Break Line Style</source>
      <translation type="unfinished">Break Line Style</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="819"/>
      <source>Style of line to be used in BrokenView.</source>
      <translation type="unfinished">Style of line to be used in BrokenView.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawAnnotation.ui" line="849"/>
      <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Note:&lt;/span&gt; Items in &lt;span style=&quot; font-style:italic;&quot;&gt;italics&lt;/span&gt; are default values for new objects. They have no effect on existing objects.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
      <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Note:&lt;/span&gt; Items in &lt;span style=&quot; font-style:italic;&quot;&gt;italics&lt;/span&gt; are default values for new objects. They have no effect on existing objects.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::DlgPrefsTechDrawColorsImp</name>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="20"/>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="47"/>
      <source>Colors</source>
      <translation type="unfinished">Colors</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="616"/>
      <source>Normal</source>
      <translation type="unfinished">Normal</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="508"/>
      <source>Normal line color</source>
      <translation type="unfinished">Normal line color</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="604"/>
      <source>Hidden Line</source>
      <translation type="unfinished">Hidden Line</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="528"/>
      <source>Hidden line color</source>
      <translation type="unfinished">Hidden line color</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="248"/>
      <source>Preselected</source>
      <translation type="unfinished">Preselected</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="184"/>
      <source>Preselection color</source>
      <translation type="unfinished">Preselection color</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="170"/>
      <source>Section Face</source>
      <translation type="unfinished">Section Face</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="623"/>
      <source>Section face color</source>
      <translation type="unfinished">Section face color</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="105"/>
      <source>Selected</source>
      <translation type="unfinished">Selected</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="441"/>
      <source>Selected item color</source>
      <translation type="unfinished">Selected item color</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="418"/>
      <source>Section Line</source>
      <translation type="unfinished">Section Line</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="347"/>
      <source>Section line color</source>
      <translation type="unfinished">Section line color</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="216"/>
      <source>Background</source>
      <translation type="unfinished">Background</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="112"/>
      <source>Background color around pages</source>
      <translation type="unfinished">Background color around pages</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="404"/>
      <source>Hatch</source>
      <translation type="unfinished">Hatch</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="327"/>
      <source>Hatch image color</source>
      <translation type="unfinished">Hatch image color</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="565"/>
      <source>Dimension</source>
      <translation type="unfinished">Dimension</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="280"/>
      <source>Color of dimension lines and text.</source>
      <translation type="unfinished">Color of dimension lines and text.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="60"/>
      <source>Geometric Hatch</source>
      <translation type="unfinished">Geometric Hatch</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="367"/>
      <source>Geometric hatch pattern color</source>
      <translation type="unfinished">Geometric hatch pattern color</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="177"/>
      <source>Centerline</source>
      <translation type="unfinished">Centerline</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="267"/>
      <source>Monochrome text color</source>
      <translation type="unfinished">Monochrome text color</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="428"/>
      <source>Light on dark</source>
      <translation type="unfinished">Light on dark</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="411"/>
      <source>Page Color</source>
      <translation type="unfinished">Page Color</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="300"/>
      <source>Use a light color for dark text and dark color for light text.</source>
      <translation type="unfinished">Use a light color for dark text and dark color for light text.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="145"/>
      <source>Centerline color</source>
      <translation type="unfinished">Centerline color</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="204"/>
      <source>Vertex</source>
      <translation type="unfinished">Vertex</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="572"/>
      <source>Color of vertices in views</source>
      <translation type="unfinished">Color of vertices in views</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="392"/>
      <source>Detail Highlight</source>
      <translation type="unfinished">Detail Highlight</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="260"/>
      <source>Leaderline</source>
      <translation type="unfinished">Leaderline</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="461"/>
      <source>Default color for leader lines</source>
      <translation type="unfinished">Default color for leader lines</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="592"/>
      <source>Grid Color</source>
      <translation type="unfinished">Grid Color</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="425"/>
      <source>Check this to use light text and lines on dark backgrounds. Set Page Color to a dark color. Transparent or light color faces are recommended with this option.</source>
      <translation type="unfinished">Check this to use light text and lines on dark backgrounds. Set Page Color to a dark color. Transparent or light color faces are recommended with this option.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="492"/>
      <source>Object faces will be transparent</source>
      <translation type="unfinished">Object faces will be transparent</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="495"/>
      <source>Transparent Faces</source>
      <translation type="unfinished">Transparent Faces</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="223"/>
      <source>Face color (if not transparent)</source>
      <translation type="unfinished">Face color (if not transparent)</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="84"/>
      <source>If checked, FreeCAD will use a single color for all text and lines.</source>
      <translation type="unfinished">If checked, FreeCAD will use a single color for all text and lines.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="87"/>
      <source>Monochrome</source>
      <translation type="unfinished">Monochrome</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="643"/>
      <source>Template Underline</source>
      <translation type="unfinished">Template Underline</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawColors.ui" line="678"/>
      <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Note:&lt;/span&gt; Items in &lt;span style=&quot; font-style:italic;&quot;&gt;italics&lt;/span&gt; are default values for new objects. They have no effect on existing objects.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
      <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Note:&lt;/span&gt; Items in &lt;span style=&quot; font-style:italic;&quot;&gt;italics&lt;/span&gt; are default values for new objects. They have no effect on existing objects.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::DlgPrefsTechDrawDimensionsImp</name>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="20"/>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="32"/>
      <source>Dimensions</source>
      <translation type="unfinished">Dimensions</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="181"/>
      <source>Standard and Style</source>
      <translation type="unfinished">Standard and Style</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="109"/>
      <source>Standard to be used for dimensional values</source>
      <translation type="unfinished">Standard to be used for dimensional values</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="119"/>
      <source>ISO Oriented</source>
      <translation type="unfinished">ISO Oriented</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="124"/>
      <source>ISO Referencing</source>
      <translation type="unfinished">ISO Referencing</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="129"/>
      <source>ASME Inlined</source>
      <translation type="unfinished">ASME Inlined</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="134"/>
      <source>ASME Referencing</source>
      <translation type="unfinished">ASME Referencing</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="356"/>
      <source>Use system setting for number of decimals</source>
      <translation type="unfinished">Use system setting for number of decimals</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="359"/>
      <source>Use Global Decimals</source>
      <translation type="unfinished">Use Global Decimals</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="443"/>
      <source>Controls the gap size between the dimension point and the start of the extension line for ISO dimensions.
 Value * linewidth is the gap.
 Normally, no gap is used. If using a gap, the recommended value is 8.</source>
      <translation type="unfinished">Controls the gap size between the dimension point and the start of the extension line for ISO dimensions.
 Value * linewidth is the gap.
 Normally, no gap is used. If using a gap, the recommended value is 8.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="461"/>
      <source>Controls the gap size between the dimension point and the start of the extension line for ASME dimensions. Value * linewidth is the gap.
 Normally, no gap is used. If using a gap, the recommended value is 6.</source>
      <translation type="unfinished">Controls the gap size between the dimension point and the start of the extension line for ASME dimensions. Value * linewidth is the gap.
 Normally, no gap is used. If using a gap, the recommended value is 6.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="483"/>
      <source>Controls the gap size between dimension line and dimension text for ISO dimensions.</source>
      <translation type="unfinished">Controls the gap size between dimension line and dimension text for ISO dimensions.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="486"/>
      <source>Line Spacing - ISO</source>
      <translation type="unfinished">Line Spacing - ISO</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="493"/>
      <source>Controls the gap size between dimension line and dimension text.
 Value * linewidth is the line spacing.</source>
      <translation type="unfinished">Controls the gap size between dimension line and dimension text.
 Value * linewidth is the line spacing.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="537"/>
      <source>Tools</source>
      <translation type="unfinished">Tools</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="543"/>
      <source>Dimensioning tools:</source>
      <translation type="unfinished">Dimensioning tools:</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="550"/>
      <source>Select the type of dimensioning tools for your toolbar:
&apos;Single tool&apos;: A single tool for all dimensioning in the toolbar: Distance, Distance X / Y, Angle, Radius. (Others in dropdown)
&apos;Separated tools&apos;: Individual tools for each dimensioning tool.
&apos;Both&apos;: You will have both the &apos;Dimension&apos; tool and the separated tools.
This setting is only for the toolbar. Whichever you choose, all tools are always available in the menu and through shortcuts.</source>
      <translation type="unfinished">Select the type of dimensioning tools for your toolbar:
&apos;Single tool&apos;: A single tool for all dimensioning in the toolbar: Distance, Distance X / Y, Angle, Radius. (Others in dropdown)
&apos;Separated tools&apos;: Individual tools for each dimensioning tool.
&apos;Both&apos;: You will have both the &apos;Dimension&apos; tool and the separated tools.
This setting is only for the toolbar. Whichever you choose, all tools are always available in the menu and through shortcuts.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="561"/>
      <source>Dimension tool diameter/radius mode:</source>
      <translation type="unfinished">Dimension tool diameter/radius mode:</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="568"/>
      <source>While using the Dimension tool you may choose how to handle circles and arcs:
&apos;Auto&apos;: The tool will apply radius to arcs and diameter to circles.
&apos;Diameter&apos;: The tool will apply diameter to all.
&apos;Radius&apos;: The tool will apply radius to all.</source>
      <translation type="unfinished">While using the Dimension tool you may choose how to handle circles and arcs:
&apos;Auto&apos;: The tool will apply radius to arcs and diameter to circles.
&apos;Diameter&apos;: The tool will apply diameter to all.
&apos;Radius&apos;: The tool will apply radius to all.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="160"/>
      <source>Append unit to dimension values</source>
      <translation type="unfinished">Append unit to dimension values</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="163"/>
      <source>Show Units</source>
      <translation type="unfinished">Show Units</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="393"/>
      <source>Alternate Decimals</source>
      <translation type="unfinished">Alternate Decimals</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="302"/>
      <source>Number of decimals if &apos;Use Global Decimals&apos; is not used</source>
      <translation type="unfinished">Number of decimals if &apos;Use Global Decimals&apos; is not used</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="67"/>
      <source>Dimension Format</source>
      <translation type="unfinished">Dimension Format</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="405"/>
      <source>Controls the gap size between the dimension point and the start of the extension line for ISO dimensions.</source>
      <translation type="unfinished">Controls the gap size between the dimension point and the start of the extension line for ISO dimensions.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="408"/>
      <source>Extension Gap Factor - ISO</source>
      <translation type="unfinished">Extension Gap Factor - ISO</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="147"/>
      <source>Font Size</source>
      <translation type="unfinished">Font Size</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="194"/>
      <source>Dimension text font size</source>
      <translation type="unfinished">Dimension text font size</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="286"/>
      <source>Tolerance Text Scale</source>
      <translation type="unfinished">Tolerance Text Scale</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="252"/>
      <source>Tolerance text scale
Multiplier of &apos;Font Size&apos;</source>
      <translation type="unfinished">Tolerance text scale
Multiplier of &apos;Font Size&apos;</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="96"/>
      <source>Diameter Symbol</source>
      <translation type="unfinished">Diameter Symbol</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="329"/>
      <source>Character used to indicate diameter dimensions</source>
      <translation type="unfinished">Character used to indicate diameter dimensions</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="227"/>
      <source>Arrow Style</source>
      <translation type="unfinished">Arrow Style</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="80"/>
      <source>Arrowhead style</source>
      <translation type="unfinished">Arrowhead style</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="215"/>
      <source>Arrow Size</source>
      <translation type="unfinished">Arrow Size</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="46"/>
      <source>Arrowhead size</source>
      <translation type="unfinished">Arrowhead size</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="415"/>
      <source>Leave blank for automatic dimension format. Use %f, %g or %w specifiers to override.</source>
      <translation type="unfinished">Leave blank for automatic dimension format. Use %f, %g or %w specifiers to override.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="433"/>
      <source>Controls the gap size between the dimension point and the start of the extension line for ASME dimensions.</source>
      <translation type="unfinished">Controls the gap size between the dimension point and the start of the extension line for ASME dimensions.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="436"/>
      <source>Extension Gap Factor - ASME</source>
      <translation type="unfinished">Extension Gap Factor - ASME</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensions.ui" line="521"/>
      <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Note:&lt;/span&gt; Items in &lt;span style=&quot; font-style:italic;&quot;&gt;italics&lt;/span&gt; are default values for new objects. They have no effect on existing objects.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
      <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Note:&lt;/span&gt; Items in &lt;span style=&quot; font-style:italic;&quot;&gt;italics&lt;/span&gt; are default values for new objects. They have no effect on existing objects.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensionsImp.cpp" line="162"/>
      <source>Single tool</source>
      <translation type="unfinished">Single tool</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensionsImp.cpp" line="163"/>
      <source>Separated tools</source>
      <translation type="unfinished">Separated tools</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensionsImp.cpp" line="164"/>
      <source>Both</source>
      <translation type="unfinished">Both</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensionsImp.cpp" line="182"/>
      <source>Auto</source>
      <translation type="unfinished">Auto</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensionsImp.cpp" line="183"/>
      <source>Diameter</source>
      <translation type="unfinished">Diameter</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawDimensionsImp.cpp" line="184"/>
      <source>Radius</source>
      <translation type="unfinished">Radius</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::DlgPrefsTechDrawGeneralImp</name>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="20"/>
      <source>General</source>
      <translation type="unfinished">General</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="35"/>
      <source>Drawing Update</source>
      <translation type="unfinished">Drawing Update</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="49"/>
      <source>Whether or not pages are updated every time the 3D model is changed</source>
      <translation type="unfinished">Whether or not pages are updated every time the 3D model is changed</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="52"/>
      <source>Update With 3D (global policy)</source>
      <translation type="unfinished">Update With 3D (global policy)</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="74"/>
      <source>Whether or not a page&apos;s &apos;Keep Updated&apos; property
can override the global &apos;Update With 3D&apos; parameter</source>
      <translation type="unfinished">Whether or not a page&apos;s &apos;Keep Updated&apos; property
can override the global &apos;Update With 3D&apos; parameter</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="78"/>
      <source>Allow Page Override (global policy)</source>
      <translation type="unfinished">Allow Page Override (global policy)</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="105"/>
      <source>Keep drawing pages in sync with changes of 3D model in real time.
This can slow down the response time.</source>
      <translation type="unfinished">Keep drawing pages in sync with changes of 3D model in real time.
This can slow down the response time.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="109"/>
      <source>Keep Page Up To Date</source>
      <translation type="unfinished">Keep Page Up To Date</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="136"/>
      <source>Automatically distribute secondary views
for ProjectionGroups</source>
      <translation type="unfinished">Automatically distribute secondary views
for ProjectionGroups</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="140"/>
      <source>Auto-distribute Secondary Views</source>
      <translation type="unfinished">Auto-distribute Secondary Views</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="167"/>
      <source>Labels</source>
      <translation type="unfinished">Labels</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="181"/>
      <source>* this font is also used for dimensions
   Changes have no effect on existing dimensions.</source>
      <translation type="unfinished">* this font is also used for dimensions
   Changes have no effect on existing dimensions.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="185"/>
      <source>Label Font*</source>
      <translation type="unfinished">Label Font*</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="220"/>
      <source>Font for labels</source>
      <translation type="unfinished">Font for labels</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="239"/>
      <source>Label Size</source>
      <translation type="unfinished">Label Size</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="265"/>
      <source>Label size</source>
      <translation type="unfinished">Label size</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="301"/>
      <source>Conventions</source>
      <translation type="unfinished">Conventions</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="322"/>
      <source>Projection Group Angle</source>
      <translation type="unfinished">Projection Group Angle</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="335"/>
      <source>Use first- or third-angle multiview projection convention</source>
      <translation type="unfinished">Use first- or third-angle multiview projection convention</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="358"/>
      <source>Page</source>
      <translation>পৃষ্ঠা</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="372"/>
      <source>Standard to be used to draw section lines.  This affects the position of arrows and symbol.</source>
      <translation type="unfinished">Standard to be used to draw section lines.  This affects the position of arrows and symbol.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="850"/>
      <source>If checked, the 3D camera direction (or normal of a selected face) will be used as the view direction. If not checked, Views will be created as Front Views.</source>
      <translation type="unfinished">If checked, the 3D camera direction (or normal of a selected face) will be used as the view direction. If not checked, Views will be created as Front Views.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="853"/>
      <source>Use 3D Camera Direction</source>
      <translation type="unfinished">Use 3D Camera Direction</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="403"/>
      <source>Section Line Convention</source>
      <translation type="unfinished">Section Line Convention</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="421"/>
      <source>Files</source>
      <translation type="unfinished">Files</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="460"/>
      <source>Preferred SVG or bitmap file for hatching.  This value will also control the initial directory for choosing hatch patterns.  You can use this to get hatch files from a local directory.</source>
      <translation type="unfinished">Preferred SVG or bitmap file for hatching.  This value will also control the initial directory for choosing hatch patterns.  You can use this to get hatch files from a local directory.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="627"/>
      <source>Default Template</source>
      <translation type="unfinished">Default Template</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="498"/>
      <source>Default template file for new pages</source>
      <translation type="unfinished">Default template file for new pages</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="586"/>
      <source>Template Directory</source>
      <translation type="unfinished">Template Directory</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="570"/>
      <source>Starting directory for menu &apos;Insert Page using Template&apos;</source>
      <translation type="unfinished">Starting directory for menu &apos;Insert Page using Template&apos;</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="620"/>
      <source>Hatch Pattern File</source>
      <translation type="unfinished">Hatch Pattern File</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="676"/>
      <source>Line Group File</source>
      <translation type="unfinished">Line Group File</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="479"/>
      <source>Alternate file for personal LineGroup definition</source>
      <translation type="unfinished">Alternate file for personal LineGroup definition</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="516"/>
      <source>Welding Directory</source>
      <translation type="unfinished">Welding Directory</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="548"/>
      <source>Default directory for welding symbols</source>
      <translation type="unfinished">Default directory for welding symbols</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="447"/>
      <source>PAT File</source>
      <translation type="unfinished">PAT File</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="529"/>
      <source>Default PAT pattern definition file for geometric hatching</source>
      <translation type="unfinished">Default PAT pattern definition file for geometric hatching</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="688"/>
      <source>Pattern Name</source>
      <translation type="unfinished">Pattern Name</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="652"/>
      <source>Name of the default PAT pattern</source>
      <translation type="unfinished">Name of the default PAT pattern</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="348"/>
      <source>First-angle</source>
      <translation type="unfinished">First-angle</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="353"/>
      <source>Third-angle</source>
      <translation type="unfinished">Third-angle</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="599"/>
      <source>Alternate directory to search for SVG symbol files.</source>
      <translation type="unfinished">Alternate directory to search for SVG symbol files.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="639"/>
      <source>Symbol Directory</source>
      <translation type="unfinished">Symbol Directory</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="655"/>
      <source>Diamond</source>
      <translation type="unfinished">Diamond</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="700"/>
      <source>Grid</source>
      <translation type="unfinished">Grid</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="726"/>
      <source>Set ShowGrid property to true on new Pages.</source>
      <translation type="unfinished">Set ShowGrid property to true on new Pages.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="729"/>
      <source>Show Grid</source>
      <translation type="unfinished">Show Grid</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="750"/>
      <source>Grid Spacing</source>
      <translation type="unfinished">Grid Spacing</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="757"/>
      <source>Distance between Page grid lines.</source>
      <translation type="unfinished">Distance between Page grid lines.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="787"/>
      <source>Selection</source>
      <translation type="unfinished">Selection</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="801"/>
      <source>If enabled, clicking without Ctrl does not clear existing vertex/edge/face selection</source>
      <translation type="unfinished">If enabled, clicking without Ctrl does not clear existing vertex/edge/face selection</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="804"/>
      <source>Enable Multiselection Mode</source>
      <translation type="unfinished">Enable Multiselection Mode</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="831"/>
      <source>View Defaults</source>
      <translation type="unfinished">View Defaults</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="871"/>
      <source>If checked, view labels will be displayed even when frames are suppressed.</source>
      <translation type="unfinished">If checked, view labels will be displayed even when frames are suppressed.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="874"/>
      <source>Always Show Label</source>
      <translation type="unfinished">Always Show Label</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="898"/>
      <source>Snapping</source>
      <translation type="unfinished">Snapping</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="906"/>
      <source>Check this box if you want views to snap into alignment when being dragged.</source>
      <translation type="unfinished">Check this box if you want views to snap into alignment when being dragged.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="909"/>
      <source>Snap View Alignment</source>
      <translation type="unfinished">Snap View Alignment</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="938"/>
      <source>View Snapping Factor</source>
      <translation type="unfinished">View Snapping Factor</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="945"/>
      <source>When dragging a view, if it is within this fraction of view size of the correct alignment, it will snap into alignment.</source>
      <translation type="unfinished">When dragging a view, if it is within this fraction of view size of the correct alignment, it will snap into alignment.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawGeneral.ui" line="993"/>
      <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Note:&lt;/span&gt; Items in &lt;span style=&quot; font-style:italic;&quot;&gt;italics&lt;/span&gt; are default values for new objects. They have no effect on existing objects.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
      <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Note:&lt;/span&gt; Items in &lt;span style=&quot; font-style:italic;&quot;&gt;italics&lt;/span&gt; are default values for new objects. They have no effect on existing objects.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::DlgPrefsTechDrawHLRImp</name>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="20"/>
      <source>HLR</source>
      <translation type="unfinished">HLR</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="47"/>
      <source>Hidden Line Removal</source>
      <translation type="unfinished">Hidden Line Removal</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="66"/>
      <source>Use an approximation to find hidden lines.
Fast, but result is a collection of short straight lines.</source>
      <translation type="unfinished">Use an approximation to find hidden lines.
Fast, but result is a collection of short straight lines.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="70"/>
      <source>Use Polygon Approximation</source>
      <translation type="unfinished">Use Polygon Approximation</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="83"/>
      <source>Visible</source>
      <translation type="unfinished">Visible</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="103"/>
      <source>Hidden</source>
      <translation type="unfinished">Hidden</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="140"/>
      <source>Show hard and outline edges (always shown)</source>
      <translation type="unfinished">Show hard and outline edges (always shown)</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="143"/>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="176"/>
      <source>Show Hard Lines</source>
      <translation type="unfinished">Show Hard Lines</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="173"/>
      <source>Show hidden hard and outline edges</source>
      <translation type="unfinished">Show hidden hard and outline edges</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="200"/>
      <source>Show smooth lines</source>
      <translation type="unfinished">Show smooth lines</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="203"/>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="233"/>
      <source>Show Smooth Lines</source>
      <translation type="unfinished">Show Smooth Lines</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="230"/>
      <source>Show hidden smooth edges</source>
      <translation type="unfinished">Show hidden smooth edges</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="257"/>
      <source>Show seam lines</source>
      <translation type="unfinished">Show seam lines</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="260"/>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="290"/>
      <source>Show Seam Lines</source>
      <translation type="unfinished">Show Seam Lines</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="287"/>
      <source>Show hidden seam lines</source>
      <translation type="unfinished">Show hidden seam lines</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="314"/>
      <source>Make lines of equal parameterization</source>
      <translation type="unfinished">Make lines of equal parameterization</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="317"/>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="344"/>
      <source>Show UV ISO Lines</source>
      <translation type="unfinished">Show UV ISO Lines</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="341"/>
      <source>Show hidden equal parameterization lines</source>
      <translation type="unfinished">Show hidden equal parameterization lines</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="368"/>
      <source>ISO Count</source>
      <translation type="unfinished">ISO Count</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="387"/>
      <source>Number of ISO lines per face edge</source>
      <translation type="unfinished">Number of ISO lines per face edge</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawHLR.ui" line="414"/>
      <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Note:&lt;/span&gt; Items in &lt;span style=&quot; font-style:italic;&quot;&gt;italics&lt;/span&gt; are default values for new objects. They have no effect on existing objects.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
      <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Note:&lt;/span&gt; Items in &lt;span style=&quot; font-style:italic;&quot;&gt;italics&lt;/span&gt; are default values for new objects. They have no effect on existing objects.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::DlgPrefsTechDrawScaleImp</name>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="20"/>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="47"/>
      <source>Scale</source>
      <translation type="unfinished">Scale</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="60"/>
      <source>Page Scale</source>
      <translation type="unfinished">Page Scale</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="79"/>
      <source>Default scale for new pages</source>
      <translation type="unfinished">Default scale for new pages</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="106"/>
      <source>View Scale Type</source>
      <translation type="unfinished">View Scale Type</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="128"/>
      <source>Default scale for new views</source>
      <translation type="unfinished">Default scale for new views</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="138"/>
      <source>Page</source>
      <translation>পৃষ্ঠা</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="143"/>
      <source>Auto</source>
      <translation type="unfinished">Auto</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="148"/>
      <source>Custom</source>
      <translation type="unfinished">Custom</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="161"/>
      <source>View Custom Scale</source>
      <translation type="unfinished">View Custom Scale</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="196"/>
      <source>Default scale for views if &apos;View Scale Type&apos; is &apos;Custom&apos;</source>
      <translation type="unfinished">Default scale for views if &apos;View Scale Type&apos; is &apos;Custom&apos;</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="238"/>
      <source>Size Adjustments</source>
      <translation type="unfinished">Size Adjustments</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="246"/>
      <source>Vertex Scale</source>
      <translation type="unfinished">Vertex Scale</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="265"/>
      <source>Scale of vertex dots. Multiplier of line width.</source>
      <translation type="unfinished">Scale of vertex dots. Multiplier of line width.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="292"/>
      <source>Center Mark Scale</source>
      <translation type="unfinished">Center Mark Scale</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="324"/>
      <source>Size of center marks. Multiplier of vertex size.</source>
      <translation type="unfinished">Size of center marks. Multiplier of vertex size.</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="349"/>
      <source>Template Edit Mark</source>
      <translation type="unfinished">Template Edit Mark</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="368"/>
      <source>Size of template field click handles</source>
      <translation type="unfinished">Size of template field click handles</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="387"/>
      <source>Welding Symbol Scale</source>
      <translation type="unfinished">Welding Symbol Scale</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="394"/>
      <source>Multiplier for size of welding symbols</source>
      <translation type="unfinished">Multiplier for size of welding symbols</translation>
    </message>
    <message>
      <location filename="../../DlgPrefsTechDrawScale.ui" line="427"/>
      <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Note:&lt;/span&gt; Items in &lt;span style=&quot; font-style:italic;&quot;&gt;italics&lt;/span&gt; are default values for new objects. They have no effect on existing objects.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
      <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Note:&lt;/span&gt; Items in &lt;span style=&quot; font-style:italic;&quot;&gt;italics&lt;/span&gt; are default values for new objects. They have no effect on existing objects.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::MDIViewPage</name>
    <message>
      <location filename="../../MDIViewPage.cpp" line="89"/>
      <source>Toggle &amp;Keep Updated</source>
      <translation type="unfinished">Toggle &amp;Keep Updated</translation>
    </message>
    <message>
      <location filename="../../MDIViewPage.cpp" line="92"/>
      <source>Toggle &amp;Frames</source>
      <translation type="unfinished">Toggle &amp;Frames</translation>
    </message>
    <message>
      <location filename="../../MDIViewPage.cpp" line="95"/>
      <source>&amp;Export SVG</source>
      <translation type="unfinished">&amp;Export SVG</translation>
    </message>
    <message>
      <location filename="../../MDIViewPage.cpp" line="98"/>
      <source>Export DXF</source>
      <translation type="unfinished">Export DXF</translation>
    </message>
    <message>
      <location filename="../../MDIViewPage.cpp" line="101"/>
      <source>Export PDF</source>
      <translation type="unfinished">Export PDF</translation>
    </message>
    <message>
      <location filename="../../MDIViewPage.cpp" line="104"/>
      <source>Print All Pages</source>
      <translation type="unfinished">Print All Pages</translation>
    </message>
    <message>
      <location filename="../../MDIViewPage.cpp" line="393"/>
      <source>Different orientation</source>
      <translation type="unfinished">Different orientation</translation>
    </message>
    <message>
      <location filename="../../MDIViewPage.cpp" line="394"/>
      <source>The printer uses a different orientation than the drawing.
Do you want to continue?</source>
      <translation type="unfinished">The printer uses a different orientation than the drawing.
Do you want to continue?</translation>
    </message>
    <message>
      <location filename="../../MDIViewPage.cpp" line="403"/>
      <source>Different paper size</source>
      <translation type="unfinished">Different paper size</translation>
    </message>
    <message>
      <location filename="../../MDIViewPage.cpp" line="404"/>
      <source>The printer uses a different paper size than the drawing.
Do you want to continue?</source>
      <translation type="unfinished">The printer uses a different paper size than the drawing.
Do you want to continue?</translation>
    </message>
    <message>
      <location filename="../../MDIViewPage.cpp" line="495"/>
      <source>Save DXF file</source>
      <translation type="unfinished">Save DXF file</translation>
    </message>
    <message>
      <location filename="../../MDIViewPage.cpp" line="518"/>
      <source>Save PDF file</source>
      <translation type="unfinished">Save PDF file</translation>
    </message>
    <message>
      <location filename="../../MDIViewPage.cpp" line="1061"/>
      <source>Selected:</source>
      <translation type="unfinished">Selected:</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::SymbolChooser</name>
    <message>
      <location filename="../../SymbolChooser.ui" line="17"/>
      <source>Symbol Chooser</source>
      <translation type="unfinished">Symbol Chooser</translation>
    </message>
    <message>
      <location filename="../../SymbolChooser.ui" line="26"/>
      <source>Select a symbol that should be used</source>
      <translation type="unfinished">Select a symbol that should be used</translation>
    </message>
    <message>
      <location filename="../../SymbolChooser.ui" line="48"/>
      <source>Symbol Dir</source>
      <translation type="unfinished">Symbol Dir</translation>
    </message>
    <message>
      <location filename="../../SymbolChooser.ui" line="55"/>
      <source>Directory to welding symbols.</source>
      <translation type="unfinished">Directory to welding symbols.</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskBalloon</name>
    <message>
      <location filename="../../TaskBalloon.ui" line="14"/>
      <source>Balloon</source>
      <translation type="unfinished">Balloon</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="22"/>
      <source>Text:</source>
      <translation type="unfinished">Text:</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="29"/>
      <source>Text to be displayed</source>
      <translation type="unfinished">Text to be displayed</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="36"/>
      <source>Text Color:</source>
      <translation type="unfinished">Text Color:</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="43"/>
      <source>Color for &apos;Text&apos;</source>
      <translation type="unfinished">Color for &apos;Text&apos;</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="57"/>
      <source>Font Size:</source>
      <translation type="unfinished">Font Size:</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="76"/>
      <source>Fontsize for &apos;Text&apos;</source>
      <translation type="unfinished">Fontsize for &apos;Text&apos;</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="95"/>
      <source>Bubble Shape:</source>
      <translation type="unfinished">Bubble Shape:</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="102"/>
      <source>Shape of the balloon bubble</source>
      <translation type="unfinished">Shape of the balloon bubble</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="106"/>
      <source>Circular</source>
      <translation type="unfinished">Circular</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="115"/>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="124"/>
      <source>Triangle</source>
      <translation type="unfinished">Triangle</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="133"/>
      <source>Inspection</source>
      <translation type="unfinished">Inspection</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="142"/>
      <source>Hexagon</source>
      <translation type="unfinished">Hexagon</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="151"/>
      <source>Square</source>
      <translation type="unfinished">Square</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="160"/>
      <source>Rectangle</source>
      <translation type="unfinished">Rectangle</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="169"/>
      <source>Line</source>
      <translation type="unfinished">Line</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="181"/>
      <source>Shape Scale:</source>
      <translation type="unfinished">Shape Scale:</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="194"/>
      <source>Bubble shape scale factor</source>
      <translation type="unfinished">Bubble shape scale factor</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="213"/>
      <source>End Symbol:</source>
      <translation type="unfinished">End Symbol:</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="220"/>
      <source>End symbol for the balloon line</source>
      <translation type="unfinished">End symbol for the balloon line</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="227"/>
      <source>End Symbol Scale:</source>
      <translation type="unfinished">End Symbol Scale:</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="240"/>
      <source>End symbol scale factor</source>
      <translation type="unfinished">End symbol scale factor</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="259"/>
      <source>Line Visible:</source>
      <translation type="unfinished">Line Visible:</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="266"/>
      <source>Whether the leader line is visible or not</source>
      <translation type="unfinished">Whether the leader line is visible or not</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="273"/>
      <source>False</source>
      <translation type="unfinished">False</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="278"/>
      <source>True</source>
      <translation type="unfinished">True</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="286"/>
      <source>Line Width:</source>
      <translation type="unfinished">Line Width:</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="305"/>
      <source>Leader line width</source>
      <translation type="unfinished">Leader line width</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="324"/>
      <source>Leader Kink Length:</source>
      <translation type="unfinished">Leader Kink Length:</translation>
    </message>
    <message>
      <location filename="../../TaskBalloon.ui" line="343"/>
      <source>Length of balloon leader line kink</source>
      <translation type="unfinished">Length of balloon leader line kink</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskCenterLine</name>
    <message>
      <location filename="../../TaskCenterLine.ui" line="17"/>
      <source>Center Line</source>
      <translation type="unfinished">Center Line</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="29"/>
      <source>Base View</source>
      <translation type="unfinished">Base View</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="52"/>
      <source>Elements</source>
      <translation type="unfinished">Elements</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="83"/>
      <source>Orientation</source>
      <translation type="unfinished">Orientation</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="89"/>
      <source>Top to Bottom line</source>
      <translation type="unfinished">Top to Bottom line</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="92"/>
      <source>Vertical</source>
      <translation type="unfinished">Vertical</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="108"/>
      <source>Left to Right line</source>
      <translation type="unfinished">Left to Right line</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="111"/>
      <source>Horizontal</source>
      <translation type="unfinished">Horizontal</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="124"/>
      <source>centerline between
- lines: in equal distance to the lines and with
  half of the angle the lines have to each other
- points: in equal distance to the points</source>
      <translation type="unfinished">centerline between
- lines: in equal distance to the lines and with
  half of the angle the lines have to each other
- points: in equal distance to the points</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="130"/>
      <source>Aligned</source>
      <translation type="unfinished">Aligned</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="208"/>
      <source>Shift Horizontal</source>
      <translation type="unfinished">Shift Horizontal</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="240"/>
      <source>Move line -Left or +Right</source>
      <translation type="unfinished">Move line -Left or +Right</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="253"/>
      <source>Shift Vertical</source>
      <translation type="unfinished">Shift Vertical</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="221"/>
      <source>Move line +Up or -Down</source>
      <translation type="unfinished">Move line +Up or -Down</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="260"/>
      <source>Rotate</source>
      <translation type="unfinished">Rotate</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="273"/>
      <source>Rotate line +CCW or -CW</source>
      <translation type="unfinished">Rotate line +CCW or -CW</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="289"/>
      <source>Extend By</source>
      <translation type="unfinished">Extend By</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="302"/>
      <source>Make the line a little longer.</source>
      <translation type="unfinished">Make the line a little longer.</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="145"/>
      <source>Color</source>
      <translation type="unfinished">Color</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="176"/>
      <source>Weight</source>
      <translation type="unfinished">Weight</translation>
    </message>
    <message>
      <location filename="../../TaskCenterLine.ui" line="183"/>
      <source>Style</source>
      <translation type="unfinished">Style</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskComplexSection</name>
    <message>
      <location filename="../../TaskComplexSection.ui" line="20"/>
      <source>Complex Section</source>
      <translation type="unfinished">Complex Section</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="36"/>
      <source>Object Selection</source>
      <translation type="unfinished">Object Selection</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="44"/>
      <source>Objects to section</source>
      <translation type="unfinished">Objects to section</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="51"/>
      <location filename="../../TaskComplexSection.ui" line="79"/>
      <source>Use Selection</source>
      <translation type="unfinished">Use Selection</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="58"/>
      <source>Profile object</source>
      <translation type="unfinished">Profile object</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="91"/>
      <source>Section Parameters</source>
      <translation type="unfinished">Section Parameters</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="105"/>
      <source>Scale Page/Auto/Custom</source>
      <translation type="unfinished">Scale Page/Auto/Custom</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="109"/>
      <source>Page</source>
      <translation>পৃষ্ঠা</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="114"/>
      <source>Automatic</source>
      <translation type="unfinished">Automatic</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="119"/>
      <source>Custom</source>
      <translation type="unfinished">Custom</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="127"/>
      <source>Scale</source>
      <translation type="unfinished">Scale</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="134"/>
      <source>Scale Type</source>
      <translation type="unfinished">Scale Type</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="160"/>
      <source>Projection Strategy</source>
      <translation type="unfinished">Projection Strategy</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="185"/>
      <location filename="../../TaskComplexSection.ui" line="192"/>
      <source>Offset</source>
      <translation type="unfinished">Offset</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="197"/>
      <source>Aligned</source>
      <translation type="unfinished">Aligned</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="202"/>
      <source>NoParallel</source>
      <translation type="unfinished">NoParallel</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="210"/>
      <source>Identifier</source>
      <translation type="unfinished">Identifier</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="223"/>
      <source>Identifier for this section</source>
      <translation type="unfinished">Identifier for this section</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="230"/>
      <source>BaseView</source>
      <translation type="unfinished">BaseView</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="255"/>
      <source>Set View Direction</source>
      <translation type="unfinished">Set View Direction</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="272"/>
      <source>Preset view direction looking up.</source>
      <translation type="unfinished">Preset view direction looking up.</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="302"/>
      <source>Preset view direction looking down.</source>
      <translation type="unfinished">Preset view direction looking down.</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="329"/>
      <source>Preset view direction looking left.</source>
      <translation type="unfinished">Preset view direction looking left.</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="356"/>
      <source>Preset view direction looking right.</source>
      <translation type="unfinished">Preset view direction looking right.</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="385"/>
      <source>Preview</source>
      <translation type="unfinished">Preview</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="393"/>
      <source>Check to update display after every property change.</source>
      <translation type="unfinished">Check to update display after every property change.</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="396"/>
      <source>Live Update</source>
      <translation type="unfinished">Live Update</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="403"/>
      <source>Rebuild display now. May be slow for complex models.</source>
      <translation type="unfinished">Rebuild display now. May be slow for complex models.</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.ui" line="406"/>
      <source>Update Now</source>
      <translation type="unfinished">Update Now</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.cpp" line="173"/>
      <source>No direction set</source>
      <translation type="unfinished">No direction set</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.cpp" line="561"/>
      <location filename="../../TaskComplexSection.cpp" line="703"/>
      <source>ComplexSection</source>
      <translation type="unfinished">ComplexSection</translation>
    </message>
    <message>
      <location filename="../../TaskComplexSection.cpp" line="714"/>
      <source>Can not continue. Object * %1 or %2 not found.</source>
      <translation type="unfinished">Can not continue. Object * %1 or %2 not found.</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskCosVertex</name>
    <message>
      <location filename="../../TaskCosVertex.ui" line="14"/>
      <source>Cosmetic Vertex</source>
      <translation type="unfinished">Cosmetic Vertex</translation>
    </message>
    <message>
      <location filename="../../TaskCosVertex.ui" line="26"/>
      <source>Base View</source>
      <translation type="unfinished">Base View</translation>
    </message>
    <message>
      <location filename="../../TaskCosVertex.ui" line="66"/>
      <location filename="../../TaskCosVertex.cpp" line="114"/>
      <source>Point Picker</source>
      <translation type="unfinished">Point Picker</translation>
    </message>
    <message>
      <location filename="../../TaskCosVertex.ui" line="95"/>
      <source>Position from the view center</source>
      <translation type="unfinished">Position from the view center</translation>
    </message>
    <message>
      <location filename="../../TaskCosVertex.ui" line="98"/>
      <source>Position</source>
      <translation type="unfinished">Position</translation>
    </message>
    <message>
      <location filename="../../TaskCosVertex.cpp" line="159"/>
      <location filename="../../TaskCosVertex.cpp" line="248"/>
      <source>Pick Points</source>
      <translation type="unfinished">Pick Points</translation>
    </message>
    <message>
      <location filename="../../TaskCosVertex.cpp" line="173"/>
      <source>Pick a point for cosmetic vertex</source>
      <translation type="unfinished">Pick a point for cosmetic vertex</translation>
    </message>
    <message>
      <location filename="../../TaskCosVertex.cpp" line="176"/>
      <source>Escape picking</source>
      <translation type="unfinished">Escape picking</translation>
    </message>
    <message>
      <location filename="../../TaskCosVertex.cpp" line="201"/>
      <source>Left click to set a point</source>
      <translation type="unfinished">Left click to set a point</translation>
    </message>
    <message>
      <location filename="../../TaskCosVertex.cpp" line="276"/>
      <source>In progress edit abandoned. Start over.</source>
      <translation type="unfinished">In progress edit abandoned. Start over.</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskCosmeticLine</name>
    <message>
      <location filename="../../TaskCosmeticLine.ui" line="26"/>
      <source>Cosmetic Line</source>
      <translation type="unfinished">Cosmetic Line</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticLine.ui" line="34"/>
      <source>View</source>
      <translation type="unfinished">View</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticLine.ui" line="61"/>
      <location filename="../../TaskCosmeticLine.ui" line="140"/>
      <source>2D Point</source>
      <translation type="unfinished">2D Point</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticLine.ui" line="77"/>
      <location filename="../../TaskCosmeticLine.ui" line="156"/>
      <source>3D Point</source>
      <translation type="unfinished">3D Point</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskCustomizeFormat</name>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="26"/>
      <source>Format Symbols</source>
      <translation type="unfinished">Format Symbols</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="32"/>
      <source>GD&amp;T</source>
      <translation type="unfinished">GD&amp;T</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="41"/>
      <source>Straightness</source>
      <translation type="unfinished">Straightness</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="51"/>
      <source>Flatness</source>
      <translation type="unfinished">Flatness</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="61"/>
      <source>Circularity</source>
      <translation type="unfinished">Circularity</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="71"/>
      <source>Cylindricity</source>
      <translation type="unfinished">Cylindricity</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="81"/>
      <source>Parallelism</source>
      <translation type="unfinished">Parallelism</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="91"/>
      <source>Perpendicularity</source>
      <translation type="unfinished">Perpendicularity</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="101"/>
      <source>Angularity</source>
      <translation type="unfinished">Angularity</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="116"/>
      <source>Profile of a line</source>
      <translation type="unfinished">Profile of a line</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="126"/>
      <source>Profile of a surface</source>
      <translation type="unfinished">Profile of a surface</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="136"/>
      <source>Circular runout</source>
      <translation type="unfinished">Circular runout</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="146"/>
      <source>Total runout</source>
      <translation type="unfinished">Total runout</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="156"/>
      <source>Position</source>
      <translation type="unfinished">Position</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="166"/>
      <source>Concentricity</source>
      <translation type="unfinished">Concentricity</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="176"/>
      <source>Symmetry</source>
      <translation type="unfinished">Symmetry</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="188"/>
      <source>Modifiers</source>
      <translation type="unfinished">Modifiers</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="202"/>
      <source>derived geometry element</source>
      <translation type="unfinished">derived geometry element</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="217"/>
      <source>Minimax (Tschebyschew)</source>
      <translation type="unfinished">Minimax (Tschebyschew)</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="232"/>
      <source>Hull condition</source>
      <translation type="unfinished">Hull condition</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="247"/>
      <source>Free state</source>
      <translation type="unfinished">Free state</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="262"/>
      <source>Least square geometry element</source>
      <translation type="unfinished">Least square geometry element</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="277"/>
      <source>Least material condition (LMC)</source>
      <translation type="unfinished">Least material condition (LMC)</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="292"/>
      <source>Maximum material condition (MMC)</source>
      <translation type="unfinished">Maximum material condition (MMC)</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="307"/>
      <source>least inscribed geometry element</source>
      <translation type="unfinished">least inscribed geometry element</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="322"/>
      <source>Projected tolerance zone</source>
      <translation type="unfinished">Projected tolerance zone</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="337"/>
      <source>Reciprocity condition</source>
      <translation type="unfinished">Reciprocity condition</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="352"/>
      <source>Regardless of feature size (RFS)</source>
      <translation type="unfinished">Regardless of feature size (RFS)</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="367"/>
      <source>Tangent plane</source>
      <translation type="unfinished">Tangent plane</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="382"/>
      <source>Unequal Bilateral</source>
      <translation type="unfinished">Unequal Bilateral</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="397"/>
      <source>most inscribed geometry element</source>
      <translation type="unfinished">most inscribed geometry element</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="409"/>
      <source>Radius &amp; Diameter</source>
      <translation type="unfinished">Radius &amp; Diameter</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="418"/>
      <source>Radius</source>
      <translation type="unfinished">Radius</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="428"/>
      <source>Diameter</source>
      <translation type="unfinished">Diameter</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="438"/>
      <source>Radius of sphere</source>
      <translation type="unfinished">Radius of sphere</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="448"/>
      <source>Diameter of sphere</source>
      <translation type="unfinished">Diameter of sphere</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="458"/>
      <source>Square</source>
      <translation type="unfinished">Square</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="470"/>
      <source>Angles</source>
      <translation type="unfinished">Angles</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="479"/>
      <source>Degree</source>
      <translation type="unfinished">Degree</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="489"/>
      <source>(Arc) Minute</source>
      <translation type="unfinished">(Arc) Minute</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="499"/>
      <source>(Arc) Second</source>
      <translation type="unfinished">(Arc) Second</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="509"/>
      <source>(Arc) Tertie</source>
      <translation type="unfinished">(Arc) Tertie</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="521"/>
      <source>Other</source>
      <translation type="unfinished">Other</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="533"/>
      <source>Taper</source>
      <translation type="unfinished">Taper</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="543"/>
      <source>Slope</source>
      <translation type="unfinished">Slope</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="553"/>
      <source>Counterbore</source>
      <translation type="unfinished">Counterbore</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="563"/>
      <source>Countersink</source>
      <translation type="unfinished">Countersink</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="573"/>
      <source>Plus - Minus</source>
      <translation type="unfinished">Plus - Minus</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="583"/>
      <source>Centerline</source>
      <translation type="unfinished">Centerline</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="593"/>
      <source>Left/right arrow</source>
      <translation type="unfinished">Left/right arrow</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="603"/>
      <source>Downward arrow</source>
      <translation type="unfinished">Downward arrow</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="613"/>
      <source>Multiplication sign</source>
      <translation type="unfinished">Multiplication sign</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="625"/>
      <source>Greek Letters</source>
      <translation type="unfinished">Greek Letters</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="634"/>
      <source>Capital delta</source>
      <translation type="unfinished">Capital delta</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="644"/>
      <source>Capital sigma</source>
      <translation type="unfinished">Capital sigma</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="654"/>
      <source>Capital omega</source>
      <translation type="unfinished">Capital omega</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="664"/>
      <source>Small mu</source>
      <translation type="unfinished">Small mu</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="674"/>
      <source>Small sigma</source>
      <translation type="unfinished">Small sigma</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="684"/>
      <source>Small phi</source>
      <translation type="unfinished">Small phi</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="694"/>
      <source>Small omega</source>
      <translation type="unfinished">Small omega</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="708"/>
      <source>Format:</source>
      <translation type="unfinished">Format:</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.ui" line="718"/>
      <source>Preview:</source>
      <translation type="unfinished">Preview:</translation>
    </message>
    <message>
      <location filename="../../TaskCustomizeFormat.cpp" line="80"/>
      <source>Customize Format</source>
      <translation type="unfinished">Customize Format</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskDetail</name>
    <message>
      <location filename="../../TaskDetail.ui" line="14"/>
      <source>Detail Anchor</source>
      <translation type="unfinished">Detail Anchor</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="26"/>
      <source>Base View</source>
      <translation type="unfinished">Base View</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="49"/>
      <source>Detail View</source>
      <translation type="unfinished">Detail View</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="80"/>
      <source>Click to drag detail highlight to new position</source>
      <translation type="unfinished">Click to drag detail highlight to new position</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="83"/>
      <location filename="../../TaskDetail.cpp" line="260"/>
      <source>Drag Highlight</source>
      <translation type="unfinished">Drag Highlight</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="134"/>
      <source>x position of detail highlight within view</source>
      <translation type="unfinished">x position of detail highlight within view</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="160"/>
      <source>y position of detail highlight within view</source>
      <translation type="unfinished">y position of detail highlight within view</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="176"/>
      <source>Radius</source>
      <translation type="unfinished">Radius</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="183"/>
      <source>size of detail view</source>
      <translation type="unfinished">size of detail view</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="202"/>
      <source>Scale Type</source>
      <translation type="unfinished">Scale Type</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="209"/>
      <source>Page: scale factor of page is used
Automatic: if the detail view is larger than the page,
                   it will be scaled down to fit into the page
Custom: custom scale factor is used</source>
      <translation type="unfinished">Page: scale factor of page is used
Automatic: if the detail view is larger than the page,
                   it will be scaled down to fit into the page
Custom: custom scale factor is used</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="216"/>
      <source>Page</source>
      <translation>পৃষ্ঠা</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="221"/>
      <source>Automatic</source>
      <translation type="unfinished">Automatic</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="226"/>
      <source>Custom</source>
      <translation type="unfinished">Custom</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="234"/>
      <source>Scale Factor</source>
      <translation type="unfinished">Scale Factor</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="244"/>
      <source>scale factor for detail view</source>
      <translation type="unfinished">scale factor for detail view</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="266"/>
      <source>Reference</source>
      <translation type="unfinished">Reference</translation>
    </message>
    <message>
      <location filename="../../TaskDetail.ui" line="273"/>
      <source>reference label</source>
      <translation type="unfinished">reference label</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskDimension</name>
    <message>
      <location filename="../../TaskDimension.ui" line="14"/>
      <source>Dimension</source>
      <translation type="unfinished">Dimension</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="20"/>
      <source>Tolerancing</source>
      <translation type="unfinished">Tolerancing</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="28"/>
      <source>If theoretical exact (basic) dimension</source>
      <translation type="unfinished">If theoretical exact (basic) dimension</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="31"/>
      <source>Theoretically Exact</source>
      <translation type="unfinished">Theoretically Exact</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="137"/>
      <source>If checked, the content of &apos;Format Spec&apos; will
be used instead of the dimension value</source>
      <translation type="unfinished">If checked, the content of &apos;Format Spec&apos; will
be used instead of the dimension value</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="176"/>
      <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, the content of tolerance format spec  will&lt;/p&gt;&lt;p&gt;be used instead of the tolerance value&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
      <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, the content of tolerance format spec  will&lt;/p&gt;&lt;p&gt;be used instead of the tolerance value&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="199"/>
      <source>Reverses usual direction of dimension line terminators</source>
      <translation type="unfinished">Reverses usual direction of dimension line terminators</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="41"/>
      <source>Equal Tolerance</source>
      <translation type="unfinished">Equal Tolerance</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="38"/>
      <source>Assign same value to over and under tolerance</source>
      <translation type="unfinished">Assign same value to over and under tolerance</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="48"/>
      <source>Overtolerance:</source>
      <translation type="unfinished">Overtolerance:</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="61"/>
      <source>Overtolerance value
If &apos;Equal Tolerance&apos; is checked this is also
the negated value for &apos;Under Tolerance&apos;.</source>
      <translation type="unfinished">Overtolerance value
If &apos;Equal Tolerance&apos; is checked this is also
the negated value for &apos;Under Tolerance&apos;.</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="79"/>
      <source>Undertolerance:</source>
      <translation type="unfinished">Undertolerance:</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="92"/>
      <source>Undertolerance value
If &apos;Equal Tolerance&apos; is checked it will be replaced
by negative value of &apos;Over Tolerance&apos;.</source>
      <translation type="unfinished">Undertolerance value
If &apos;Equal Tolerance&apos; is checked it will be replaced
by negative value of &apos;Over Tolerance&apos;.</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="115"/>
      <source>Formatting</source>
      <translation type="unfinished">Formatting</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="123"/>
      <source>Format Specifier:</source>
      <translation type="unfinished">Format Specifier:</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="130"/>
      <source>Text to be displayed</source>
      <translation type="unfinished">Text to be displayed</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="141"/>
      <source>Arbitrary Text</source>
      <translation type="unfinished">Arbitrary Text</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="148"/>
      <source>OverTolerance Format Specifier:</source>
      <translation type="unfinished">OverTolerance Format Specifier:</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="155"/>
      <source>Specifies the overtolerance format in printf() style, or arbitrary text</source>
      <translation type="unfinished">Specifies the overtolerance format in printf() style, or arbitrary text</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="162"/>
      <source>UnderTolerance Format Specifier:</source>
      <translation type="unfinished">UnderTolerance Format Specifier:</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="169"/>
      <source>Specifies the undertolerance format in printf() style, or arbitrary text</source>
      <translation type="unfinished">Specifies the undertolerance format in printf() style, or arbitrary text</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="179"/>
      <source>Arbitrary Tolerance Text</source>
      <translation type="unfinished">Arbitrary Tolerance Text</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="191"/>
      <source>Display Style</source>
      <translation type="unfinished">Display Style</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="202"/>
      <source>Flip Arrowheads</source>
      <translation type="unfinished">Flip Arrowheads</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="209"/>
      <source>Color:</source>
      <translation>ৰং:</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="216"/>
      <source>Color of the dimension</source>
      <translation type="unfinished">Color of the dimension</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="230"/>
      <source>Font Size:</source>
      <translation type="unfinished">Font Size:</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="249"/>
      <source>Fontsize for &apos;Text&apos;</source>
      <translation type="unfinished">Fontsize for &apos;Text&apos;</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="271"/>
      <source>Drawing Style:</source>
      <translation type="unfinished">Drawing Style:</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="278"/>
      <source>Standard and style according to which dimension is drawn</source>
      <translation type="unfinished">Standard and style according to which dimension is drawn</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="282"/>
      <source>ISO Oriented</source>
      <translation type="unfinished">ISO Oriented</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="287"/>
      <source>ISO Referencing</source>
      <translation type="unfinished">ISO Referencing</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="292"/>
      <source>ASME Inlined</source>
      <translation type="unfinished">ASME Inlined</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="297"/>
      <source>ASME Referencing</source>
      <translation type="unfinished">ASME Referencing</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="310"/>
      <source>Lines</source>
      <translation type="unfinished">Lines</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="318"/>
      <source>Use override angles if checked. Use default angles if unchecked.</source>
      <translation type="unfinished">Use override angles if checked. Use default angles if unchecked.</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="321"/>
      <source>Override angles</source>
      <translation type="unfinished">Override angles</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="328"/>
      <source>Dimension line angle</source>
      <translation type="unfinished">Dimension line angle</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="335"/>
      <source>Angle of dimension line with drawing X axis (degrees)</source>
      <translation type="unfinished">Angle of dimension line with drawing X axis (degrees)</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="351"/>
      <source>Set dimension line angle to default (ortho view).</source>
      <translation type="unfinished">Set dimension line angle to default (ortho view).</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="354"/>
      <location filename="../../TaskDimension.ui" line="397"/>
      <source>Use default</source>
      <translation type="unfinished">Use default</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="361"/>
      <source>Set dimension line angle to match selected edge or vertices.</source>
      <translation type="unfinished">Set dimension line angle to match selected edge or vertices.</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="364"/>
      <location filename="../../TaskDimension.ui" line="407"/>
      <source>Use selection</source>
      <translation type="unfinished">Use selection</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="371"/>
      <source>Extension line angle</source>
      <translation type="unfinished">Extension line angle</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="378"/>
      <source>Angle of extension lines with drawing X axis (degrees)</source>
      <translation type="unfinished">Angle of extension lines with drawing X axis (degrees)</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="394"/>
      <source>Set extension line angle to default (ortho).</source>
      <translation type="unfinished">Set extension line angle to default (ortho).</translation>
    </message>
    <message>
      <location filename="../../TaskDimension.ui" line="404"/>
      <source>Set extension line angle to match selected edge or vertices.</source>
      <translation type="unfinished">Set extension line angle to match selected edge or vertices.</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskDlgLineDecor</name>
    <message>
      <location filename="../../TaskLineDecor.cpp" line="467"/>
      <source>Restore Invisible Lines</source>
      <translation type="unfinished">Restore Invisible Lines</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskGeomHatch</name>
    <message>
      <location filename="../../TaskGeomHatch.ui" line="26"/>
      <source>Apply Geometric Hatch to Face</source>
      <translation type="unfinished">Apply Geometric Hatch to Face</translation>
    </message>
    <message>
      <location filename="../../TaskGeomHatch.ui" line="38"/>
      <source>Define your pattern</source>
      <translation type="unfinished">Define your pattern</translation>
    </message>
    <message>
      <location filename="../../TaskGeomHatch.ui" line="46"/>
      <source>Pattern File</source>
      <translation type="unfinished">Pattern File</translation>
    </message>
    <message>
      <location filename="../../TaskGeomHatch.ui" line="59"/>
      <source>The PAT file containing your pattern</source>
      <translation type="unfinished">The PAT file containing your pattern</translation>
    </message>
    <message>
      <location filename="../../TaskGeomHatch.ui" line="77"/>
      <source>Rotation</source>
      <translation type="unfinished">Rotation</translation>
    </message>
    <message>
      <location filename="../../TaskGeomHatch.ui" line="97"/>
      <source>Pattern Name</source>
      <translation type="unfinished">Pattern Name</translation>
    </message>
    <message>
      <location filename="../../TaskGeomHatch.ui" line="104"/>
      <source>Offset X</source>
      <translation type="unfinished">Offset X</translation>
    </message>
    <message>
      <location filename="../../TaskGeomHatch.ui" line="117"/>
      <source>Name of pattern within file</source>
      <translation type="unfinished">Name of pattern within file</translation>
    </message>
    <message>
      <location filename="../../TaskGeomHatch.ui" line="124"/>
      <source>Line Width</source>
      <translation type="unfinished">Line Width</translation>
    </message>
    <message>
      <location filename="../../TaskGeomHatch.ui" line="223"/>
      <source>Offset Y</source>
      <translation type="unfinished">Offset Y</translation>
    </message>
    <message>
      <location filename="../../TaskGeomHatch.ui" line="70"/>
      <source>Pattern Scale</source>
      <translation type="unfinished">Pattern Scale</translation>
    </message>
    <message>
      <location filename="../../TaskGeomHatch.ui" line="201"/>
      <source>Enlarges/shrinks the pattern</source>
      <translation type="unfinished">Enlarges/shrinks the pattern</translation>
    </message>
    <message>
      <location filename="../../TaskGeomHatch.ui" line="153"/>
      <source>Thickness of lines within the pattern</source>
      <translation type="unfinished">Thickness of lines within the pattern</translation>
    </message>
    <message>
      <location filename="../../TaskGeomHatch.ui" line="188"/>
      <source>Line Color</source>
      <translation type="unfinished">Line Color</translation>
    </message>
    <message>
      <location filename="../../TaskGeomHatch.ui" line="90"/>
      <source>Color of pattern lines</source>
      <translation type="unfinished">Color of pattern lines</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskHatch</name>
    <message>
      <location filename="../../TaskHatch.ui" line="26"/>
      <source>Apply Hatch to Face</source>
      <translation type="unfinished">Apply Hatch to Face</translation>
    </message>
    <message>
      <location filename="../../TaskHatch.ui" line="41"/>
      <source>Pattern Parameters</source>
      <translation type="unfinished">Pattern Parameters</translation>
    </message>
    <message>
      <location filename="../../TaskHatch.ui" line="114"/>
      <source>Offset X</source>
      <translation type="unfinished">Offset X</translation>
    </message>
    <message>
      <location filename="../../TaskHatch.ui" line="38"/>
      <source>Select an SVG or Bitmap file</source>
      <translation type="unfinished">Select an SVG or Bitmap file</translation>
    </message>
    <message>
      <location filename="../../TaskHatch.ui" line="55"/>
      <source>Choose an SVG or Bitmap file as a pattern</source>
      <translation type="unfinished">Choose an SVG or Bitmap file as a pattern</translation>
    </message>
    <message>
      <location filename="../../TaskHatch.ui" line="85"/>
      <source>Enlarges/shrinks the pattern (SVG Only)</source>
      <translation type="unfinished">Enlarges/shrinks the pattern (SVG Only)</translation>
    </message>
    <message>
      <location filename="../../TaskHatch.ui" line="107"/>
      <source>SVG Line Color</source>
      <translation type="unfinished">SVG Line Color</translation>
    </message>
    <message>
      <location filename="../../TaskHatch.ui" line="133"/>
      <source>Color of pattern lines (SVG Only)</source>
      <translation type="unfinished">Color of pattern lines (SVG Only)</translation>
    </message>
    <message>
      <location filename="../../TaskHatch.ui" line="159"/>
      <source>SVG Pattern Scale</source>
      <translation type="unfinished">SVG Pattern Scale</translation>
    </message>
    <message>
      <location filename="../../TaskHatch.ui" line="166"/>
      <source>Rotation</source>
      <translation type="unfinished">Rotation</translation>
    </message>
    <message>
      <location filename="../../TaskHatch.ui" line="173"/>
      <source>Offset Y</source>
      <translation type="unfinished">Offset Y</translation>
    </message>
    <message>
      <location filename="../../TaskHatch.ui" line="140"/>
      <source>Rotation the pattern (degrees)</source>
      <translation type="unfinished">Rotation the pattern (degrees)</translation>
    </message>
    <message>
      <location filename="../../TaskHatch.ui" line="62"/>
      <source>Pattern File</source>
      <translation type="unfinished">Pattern File</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskLeaderLine</name>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="26"/>
      <source>Leader Line</source>
      <translation type="unfinished">Leader Line</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="38"/>
      <source>Base View</source>
      <translation type="unfinished">Base View</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="93"/>
      <source>Discard Changes</source>
      <translation type="unfinished">Discard Changes</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="113"/>
      <source>First pick the start point of the line,
then at least a second point.
You can pick further points to get line segments.</source>
      <translation type="unfinished">First pick the start point of the line,
then at least a second point.
You can pick further points to get line segments.</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="118"/>
      <location filename="../../TaskLeaderLine.cpp" line="501"/>
      <source>Pick Points</source>
      <translation type="unfinished">Pick Points</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="149"/>
      <source>Start Symbol</source>
      <translation type="unfinished">Start Symbol</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="169"/>
      <source>End Symbol</source>
      <translation type="unfinished">End Symbol</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="199"/>
      <source>Color</source>
      <translation type="unfinished">Color</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="212"/>
      <source>Line color</source>
      <translation type="unfinished">Line color</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="226"/>
      <source>Width</source>
      <translation type="unfinished">Width</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="242"/>
      <source>Line width</source>
      <translation type="unfinished">Line width</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="258"/>
      <source>Style</source>
      <translation type="unfinished">Style</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="271"/>
      <source>Line style</source>
      <translation type="unfinished">Line style</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="278"/>
      <source>NoLine</source>
      <translation type="unfinished">NoLine</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="287"/>
      <source>Continuous</source>
      <translation type="unfinished">Continuous</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="296"/>
      <source>Dash</source>
      <translation type="unfinished">Dash</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="305"/>
      <source>Dot</source>
      <translation type="unfinished">Dot</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="314"/>
      <source>DashDot</source>
      <translation type="unfinished">DashDot</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.ui" line="323"/>
      <source>DashDotDot</source>
      <translation type="unfinished">DashDotDot</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.cpp" line="226"/>
      <source>Pick points</source>
      <translation type="unfinished">Pick points</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.cpp" line="274"/>
      <location filename="../../TaskLeaderLine.cpp" line="688"/>
      <location filename="../../TaskLeaderLine.cpp" line="759"/>
      <location filename="../../TaskLeaderLine.cpp" line="781"/>
      <source>Edit points</source>
      <translation type="unfinished">Edit points</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.cpp" line="515"/>
      <source>Edit Points</source>
      <translation type="unfinished">Edit Points</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.cpp" line="532"/>
      <location filename="../../TaskLeaderLine.cpp" line="584"/>
      <source>Pick a starting point for leader line</source>
      <translation type="unfinished">Pick a starting point for leader line</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.cpp" line="535"/>
      <source>Save Points</source>
      <translation type="unfinished">Save Points</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.cpp" line="567"/>
      <source>Click and drag markers to adjust leader line</source>
      <translation type="unfinished">Click and drag markers to adjust leader line</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.cpp" line="570"/>
      <location filename="../../TaskLeaderLine.cpp" line="587"/>
      <source>Save changes</source>
      <translation type="unfinished">Save changes</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.cpp" line="618"/>
      <source>Left click to set a point</source>
      <translation type="unfinished">Left click to set a point</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.cpp" line="644"/>
      <source>Press OK or Cancel to continue</source>
      <translation type="unfinished">Press OK or Cancel to continue</translation>
    </message>
    <message>
      <location filename="../../TaskLeaderLine.cpp" line="776"/>
      <source>In progress edit abandoned. Start over.</source>
      <translation type="unfinished">In progress edit abandoned. Start over.</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskLineDecor</name>
    <message>
      <location filename="../../TaskLineDecor.ui" line="26"/>
      <source>Line Decoration</source>
      <translation type="unfinished">Line Decoration</translation>
    </message>
    <message>
      <location filename="../../TaskLineDecor.ui" line="92"/>
      <source>View</source>
      <translation type="unfinished">View</translation>
    </message>
    <message>
      <location filename="../../TaskLineDecor.ui" line="52"/>
      <source>Lines</source>
      <translation type="unfinished">Lines</translation>
    </message>
    <message>
      <location filename="../../TaskLineDecor.ui" line="99"/>
      <source>The use of the Qt line style is being phased out. Please use a standard line style instead.</source>
      <translation type="unfinished">The use of the Qt line style is being phased out. Please use a standard line style instead.</translation>
    </message>
    <message>
      <location filename="../../TaskLineDecor.ui" line="115"/>
      <source>Style</source>
      <translation type="unfinished">Style</translation>
    </message>
    <message>
      <location filename="../../TaskLineDecor.ui" line="85"/>
      <source>Color</source>
      <translation type="unfinished">Color</translation>
    </message>
    <message>
      <location filename="../../TaskLineDecor.ui" line="45"/>
      <source>Weight</source>
      <translation type="unfinished">Weight</translation>
    </message>
    <message>
      <location filename="../../TaskLineDecor.ui" line="145"/>
      <source>Thickness of pattern lines.</source>
      <translation type="unfinished">Thickness of pattern lines.</translation>
    </message>
    <message>
      <location filename="../../TaskLineDecor.ui" line="158"/>
      <source>Visible</source>
      <translation type="unfinished">Visible</translation>
    </message>
    <message>
      <location filename="../../TaskLineDecor.ui" line="72"/>
      <source>False</source>
      <translation type="unfinished">False</translation>
    </message>
    <message>
      <location filename="../../TaskLineDecor.ui" line="77"/>
      <source>True</source>
      <translation type="unfinished">True</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskLinkDim</name>
    <message>
      <location filename="../../TaskLinkDim.ui" line="26"/>
      <source>Link Dimension</source>
      <translation type="unfinished">Link Dimension</translation>
    </message>
    <message>
      <location filename="../../TaskLinkDim.ui" line="54"/>
      <source>Link This 3D Geometry</source>
      <translation type="unfinished">Link This 3D Geometry</translation>
    </message>
    <message>
      <location filename="../../TaskLinkDim.ui" line="67"/>
      <source>Feature1:</source>
      <translation type="unfinished">Feature1:</translation>
    </message>
    <message>
      <location filename="../../TaskLinkDim.ui" line="87"/>
      <source>Geometry1:</source>
      <translation type="unfinished">Geometry1:</translation>
    </message>
    <message>
      <location filename="../../TaskLinkDim.ui" line="107"/>
      <source>Feature2:</source>
      <translation type="unfinished">Feature2:</translation>
    </message>
    <message>
      <location filename="../../TaskLinkDim.ui" line="127"/>
      <source>Geometry2:</source>
      <translation type="unfinished">Geometry2:</translation>
    </message>
    <message>
      <location filename="../../TaskLinkDim.ui" line="153"/>
      <source>To These Dimensions</source>
      <translation type="unfinished">To These Dimensions</translation>
    </message>
    <message>
      <location filename="../../TaskLinkDim.cpp" line="58"/>
      <source>Available</source>
      <translation type="unfinished">Available</translation>
    </message>
    <message>
      <location filename="../../TaskLinkDim.cpp" line="59"/>
      <source>Selected</source>
      <translation type="unfinished">Selected</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskProjGroup</name>
    <message>
      <location filename="../../TaskProjGroup.ui" line="26"/>
      <source>Projection Group</source>
      <translation type="unfinished">Projection Group</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="120"/>
      <source>Direction</source>
      <translation type="unfinished">Direction</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="126"/>
      <source>Spin clock wise</source>
      <translation type="unfinished">Spin clock wise</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="552"/>
      <source>Projection</source>
      <translation type="unfinished">Projection</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="559"/>
      <source>First or Third Angle</source>
      <translation type="unfinished">First or Third Angle</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="563"/>
      <source>First Angle</source>
      <translation type="unfinished">First Angle</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="568"/>
      <source>Third Angle</source>
      <translation type="unfinished">Third Angle</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="45"/>
      <location filename="../../TaskProjGroup.ui" line="573"/>
      <source>Page</source>
      <translation>পৃষ্ঠা</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="34"/>
      <source>Scale</source>
      <translation type="unfinished">Scale</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="41"/>
      <source>Scale Page/Auto/Custom</source>
      <translation type="unfinished">Scale Page/Auto/Custom</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="50"/>
      <source>Automatic</source>
      <translation type="unfinished">Automatic</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="55"/>
      <source>Custom</source>
      <translation type="unfinished">Custom</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="76"/>
      <source>Scale Numerator</source>
      <translation type="unfinished">Scale Numerator</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="99"/>
      <source>Scale Denominator</source>
      <translation type="unfinished">Scale Denominator</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="153"/>
      <source>Rotate up</source>
      <translation type="unfinished">Rotate up</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="174"/>
      <source>Spin counter clock wise</source>
      <translation type="unfinished">Spin counter clock wise</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="195"/>
      <source>Rotate left</source>
      <translation type="unfinished">Rotate left</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="224"/>
      <source>Current primary view direction</source>
      <translation type="unfinished">Current primary view direction</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="231"/>
      <source>Rotate right</source>
      <translation type="unfinished">Rotate right</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="252"/>
      <source>Set document front view as primary direction.</source>
      <translation type="unfinished">Set document front view as primary direction.</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="282"/>
      <source>Rotate down</source>
      <translation type="unfinished">Rotate down</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="303"/>
      <source>Set direction of the camera, or selected face if any, as primary direction.</source>
      <translation type="unfinished">Set direction of the camera, or selected face if any, as primary direction.</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="333"/>
      <source>Secondary Projections</source>
      <translation type="unfinished">Secondary Projections</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="339"/>
      <source>LeftFrontTop</source>
      <translation type="unfinished">LeftFrontTop</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="362"/>
      <location filename="../../TaskProjGroup.cpp" line="661"/>
      <location filename="../../TaskProjGroup.cpp" line="668"/>
      <source>Top</source>
      <translation type="unfinished">Top</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="379"/>
      <source>RightFrontTop</source>
      <translation type="unfinished">RightFrontTop</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="409"/>
      <location filename="../../TaskProjGroup.cpp" line="663"/>
      <location filename="../../TaskProjGroup.cpp" line="665"/>
      <source>Left</source>
      <translation type="unfinished">Left</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="429"/>
      <source>Primary</source>
      <translation type="unfinished">Primary</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="449"/>
      <location filename="../../TaskProjGroup.cpp" line="663"/>
      <location filename="../../TaskProjGroup.cpp" line="665"/>
      <source>Right</source>
      <translation type="unfinished">Right</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="466"/>
      <location filename="../../TaskProjGroup.cpp" line="666"/>
      <source>Rear</source>
      <translation type="unfinished">Rear</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="496"/>
      <source>LeftFrontBottom</source>
      <translation type="unfinished">LeftFrontBottom</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="516"/>
      <location filename="../../TaskProjGroup.cpp" line="661"/>
      <location filename="../../TaskProjGroup.cpp" line="668"/>
      <source>Bottom</source>
      <translation type="unfinished">Bottom</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="533"/>
      <source>RightFrontBottom</source>
      <translation type="unfinished">RightFrontBottom</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="583"/>
      <source>Distributes projections automatically
using the given X/Y Spacing</source>
      <translation type="unfinished">Distributes projections automatically
using the given X/Y Spacing</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="587"/>
      <source>Auto Distribute</source>
      <translation type="unfinished">Auto Distribute</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="608"/>
      <source>X Spacing</source>
      <translation type="unfinished">X Spacing</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="640"/>
      <source>Horizontal space between borders of projections</source>
      <translation type="unfinished">Horizontal space between borders of projections</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="687"/>
      <source>Vertical space between borders of projections</source>
      <translation type="unfinished">Vertical space between borders of projections</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.ui" line="668"/>
      <source>Y Spacing</source>
      <translation type="unfinished">Y Spacing</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.cpp" line="660"/>
      <location filename="../../TaskProjGroup.cpp" line="669"/>
      <source>FrontTopLeft</source>
      <translation type="unfinished">FrontTopLeft</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.cpp" line="660"/>
      <location filename="../../TaskProjGroup.cpp" line="669"/>
      <source>FrontBottomRight</source>
      <translation type="unfinished">FrontBottomRight</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.cpp" line="662"/>
      <location filename="../../TaskProjGroup.cpp" line="667"/>
      <source>FrontTopRight</source>
      <translation type="unfinished">FrontTopRight</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.cpp" line="662"/>
      <location filename="../../TaskProjGroup.cpp" line="667"/>
      <source>FrontBottomLeft</source>
      <translation type="unfinished">FrontBottomLeft</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.cpp" line="664"/>
      <source>Front</source>
      <translation type="unfinished">Front</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskProjection</name>
    <message>
      <location filename="../../TaskProjection.ui" line="14"/>
      <source>Project shapes</source>
      <translation type="unfinished">Project shapes</translation>
    </message>
    <message>
      <location filename="../../TaskProjection.ui" line="22"/>
      <source>Visible sharp edges</source>
      <translation type="unfinished">Visible sharp edges</translation>
    </message>
    <message>
      <location filename="../../TaskProjection.ui" line="32"/>
      <source>Visible smooth edges</source>
      <translation type="unfinished">Visible smooth edges</translation>
    </message>
    <message>
      <location filename="../../TaskProjection.ui" line="42"/>
      <source>Visible sewn edges</source>
      <translation type="unfinished">Visible sewn edges</translation>
    </message>
    <message>
      <location filename="../../TaskProjection.ui" line="52"/>
      <source>Visible outline edges</source>
      <translation type="unfinished">Visible outline edges</translation>
    </message>
    <message>
      <location filename="../../TaskProjection.ui" line="62"/>
      <source>Visible isoparameters</source>
      <translation type="unfinished">Visible isoparameters</translation>
    </message>
    <message>
      <location filename="../../TaskProjection.ui" line="72"/>
      <source>Hidden sharp edges</source>
      <translation type="unfinished">Hidden sharp edges</translation>
    </message>
    <message>
      <location filename="../../TaskProjection.ui" line="79"/>
      <source>Hidden smooth edges</source>
      <translation type="unfinished">Hidden smooth edges</translation>
    </message>
    <message>
      <location filename="../../TaskProjection.ui" line="86"/>
      <source>Hidden sewn edges</source>
      <translation type="unfinished">Hidden sewn edges</translation>
    </message>
    <message>
      <location filename="../../TaskProjection.ui" line="93"/>
      <source>Hidden outline edges</source>
      <translation type="unfinished">Hidden outline edges</translation>
    </message>
    <message>
      <location filename="../../TaskProjection.ui" line="100"/>
      <source>Hidden isoparameters</source>
      <translation type="unfinished">Hidden isoparameters</translation>
    </message>
    <message>
      <location filename="../../TaskProjection.cpp" line="64"/>
      <source>No active document</source>
      <translation type="unfinished">No active document</translation>
    </message>
    <message>
      <location filename="../../TaskProjection.cpp" line="65"/>
      <source>There is currently no active document to complete the operation</source>
      <translation type="unfinished">There is currently no active document to complete the operation</translation>
    </message>
    <message>
      <location filename="../../TaskProjection.cpp" line="70"/>
      <source>No active view</source>
      <translation type="unfinished">No active view</translation>
    </message>
    <message>
      <location filename="../../TaskProjection.cpp" line="71"/>
      <source>There is currently no active view to complete the operation</source>
      <translation type="unfinished">There is currently no active view to complete the operation</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskRestoreLines</name>
    <message>
      <location filename="../../TaskRestoreLines.ui" line="14"/>
      <source>Restore Invisible Lines</source>
      <translation type="unfinished">Restore Invisible Lines</translation>
    </message>
    <message>
      <location filename="../../TaskRestoreLines.ui" line="22"/>
      <source>All</source>
      <translation type="unfinished">All</translation>
    </message>
    <message>
      <location filename="../../TaskRestoreLines.ui" line="39"/>
      <source>Geometry</source>
      <translation type="unfinished">Geometry</translation>
    </message>
    <message>
      <location filename="../../TaskRestoreLines.ui" line="56"/>
      <source>Cosmetic</source>
      <translation type="unfinished">Cosmetic</translation>
    </message>
    <message>
      <location filename="../../TaskRestoreLines.ui" line="73"/>
      <source>CenterLine</source>
      <translation type="unfinished">CenterLine</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskRichAnno</name>
    <message>
      <location filename="../../TaskRichAnno.ui" line="26"/>
      <source>Rich Text Annotation Block</source>
      <translation type="unfinished">Rich Text Annotation Block</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="53"/>
      <source>Base Feature</source>
      <translation type="unfinished">Base Feature</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="67"/>
      <source>Max Width</source>
      <translation type="unfinished">Max Width</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="74"/>
      <source>Maximal width, if -1 then automatic width</source>
      <translation type="unfinished">Maximal width, if -1 then automatic width</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="102"/>
      <source>Start Rich Text Editor</source>
      <translation type="unfinished">Start Rich Text Editor</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="121"/>
      <source>Show Frame</source>
      <translation type="unfinished">Show Frame</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="138"/>
      <source>Color</source>
      <translation type="unfinished">Color</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="148"/>
      <source>Line color</source>
      <translation type="unfinished">Line color</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="162"/>
      <source>Width</source>
      <translation type="unfinished">Width</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="172"/>
      <source>Line width</source>
      <translation type="unfinished">Line width</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="188"/>
      <source>Style</source>
      <translation type="unfinished">Style</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="198"/>
      <source>Line style</source>
      <translation type="unfinished">Line style</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="205"/>
      <source>NoLine</source>
      <translation type="unfinished">NoLine</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="210"/>
      <source>Continuous</source>
      <translation type="unfinished">Continuous</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="215"/>
      <source>Dash</source>
      <translation type="unfinished">Dash</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="220"/>
      <source>Dot</source>
      <translation type="unfinished">Dot</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="225"/>
      <source>DashDot</source>
      <translation type="unfinished">DashDot</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.ui" line="230"/>
      <source>DashDotDot</source>
      <translation type="unfinished">DashDotDot</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.cpp" line="180"/>
      <source>Input the annotation text directly or start the rich text editor</source>
      <translation type="unfinished">Input the annotation text directly or start the rich text editor</translation>
    </message>
    <message>
      <location filename="../../TaskRichAnno.cpp" line="282"/>
      <source>RichTextAnnotation</source>
      <translation type="unfinished">RichTextAnnotation</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskSectionView</name>
    <message>
      <location filename="../../TaskSectionView.ui" line="20"/>
      <source>Section Parameters</source>
      <translation type="unfinished">Section Parameters</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="28"/>
      <source>BaseView</source>
      <translation type="unfinished">BaseView</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="61"/>
      <source>Identifier</source>
      <translation type="unfinished">Identifier</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="74"/>
      <source>Identifier for this section</source>
      <translation type="unfinished">Identifier for this section</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="81"/>
      <source>Scale Type</source>
      <translation type="unfinished">Scale Type</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="94"/>
      <source>Scale Page/Auto/Custom</source>
      <translation type="unfinished">Scale Page/Auto/Custom</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="98"/>
      <source>Page</source>
      <translation>পৃষ্ঠা</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="103"/>
      <source>Automatic</source>
      <translation type="unfinished">Automatic</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="108"/>
      <source>Custom</source>
      <translation type="unfinished">Custom</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="116"/>
      <source>Scale</source>
      <translation type="unfinished">Scale</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="123"/>
      <source>Scale factor for the section view</source>
      <translation type="unfinished">Scale factor for the section view</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="150"/>
      <source>Set View Direction</source>
      <translation type="unfinished">Set View Direction</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="167"/>
      <source>Preset view direction looking up.</source>
      <translation type="unfinished">Preset view direction looking up.</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="203"/>
      <source>Preset view direction looking down.</source>
      <translation type="unfinished">Preset view direction looking down.</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="233"/>
      <source>Preset view direction looking left.</source>
      <translation type="unfinished">Preset view direction looking left.</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="263"/>
      <source>Preset view direction looking right.</source>
      <translation type="unfinished">Preset view direction looking right.</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="447"/>
      <source>Preview</source>
      <translation type="unfinished">Preview</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="455"/>
      <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Rebuild display now.  May be slow for complex models.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
      <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Rebuild display now.  May be slow for complex models.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="458"/>
      <source>Update Now</source>
      <translation type="unfinished">Update Now</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="465"/>
      <source>Check to update display after every property change.</source>
      <translation type="unfinished">Check to update display after every property change.</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="468"/>
      <source>Live Update</source>
      <translation type="unfinished">Live Update</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="295"/>
      <source>Position from the 3D origin of the object in the view</source>
      <translation type="unfinished">Position from the 3D origin of the object in the view</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.ui" line="298"/>
      <source>Section Plane Location</source>
      <translation type="unfinished">Section Plane Location</translation>
    </message>
    <message numerus="yes">
      <location filename="../../TaskSectionView.cpp" line="428"/>
      <source>%n update(s) pending</source>
      <translation type="unfinished">
        <numerusform>%n update(s) pending</numerusform>
        <numerusform>%n update(s) pending</numerusform>
      </translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.cpp" line="438"/>
      <source>Nothing to apply. No section direction picked yet</source>
      <translation type="unfinished">Nothing to apply. No section direction picked yet</translation>
    </message>
    <message>
      <location filename="../../TaskSectionView.cpp" line="639"/>
      <source>Can not continue. Object * %1 or %2 not found.</source>
      <translation type="unfinished">Can not continue. Object * %1 or %2 not found.</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskSelectLineAttributes</name>
    <message>
      <location filename="../../TaskSelectLineAttributes.ui" line="26"/>
      <source>Line attributes</source>
      <translation type="unfinished">Line attributes</translation>
    </message>
    <message>
      <location filename="../../TaskSelectLineAttributes.ui" line="34"/>
      <source>Line style:</source>
      <translation type="unfinished">Line style:</translation>
    </message>
    <message>
      <location filename="../../TaskSelectLineAttributes.ui" line="48"/>
      <source>Line width:</source>
      <translation type="unfinished">Line width:</translation>
    </message>
    <message>
      <location filename="../../TaskSelectLineAttributes.ui" line="55"/>
      <source>Thin 0,18</source>
      <translation type="unfinished">Thin 0,18</translation>
    </message>
    <message>
      <location filename="../../TaskSelectLineAttributes.ui" line="68"/>
      <source>Middle 0,35</source>
      <translation type="unfinished">Middle 0,35</translation>
    </message>
    <message>
      <location filename="../../TaskSelectLineAttributes.ui" line="84"/>
      <source>Thick 0,70</source>
      <translation type="unfinished">Thick 0,70</translation>
    </message>
    <message>
      <location filename="../../TaskSelectLineAttributes.ui" line="104"/>
      <source>Line color:</source>
      <translation type="unfinished">Line color:</translation>
    </message>
    <message>
      <location filename="../../TaskSelectLineAttributes.ui" line="124"/>
      <source>Cascade spacing</source>
      <translation type="unfinished">Cascade spacing</translation>
    </message>
    <message>
      <location filename="../../TaskSelectLineAttributes.ui" line="138"/>
      <source>Delta distance</source>
      <translation type="unfinished">Delta distance</translation>
    </message>
    <message>
      <location filename="../../TaskSelectLineAttributes.cpp" line="115"/>
      <source>Select line attributes</source>
      <translation type="unfinished">Select line attributes</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskSurfaceFinishSymbols</name>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.ui" line="26"/>
      <location filename="../../TaskSurfaceFinishSymbols.cpp" line="246"/>
      <source>Surface Finish Symbols</source>
      <translation type="unfinished">Surface Finish Symbols</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.ui" line="61"/>
      <source>Material removal prohibited, whole part</source>
      <translation type="unfinished">Material removal prohibited, whole part</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.ui" line="95"/>
      <source>Any method allowed, whole part</source>
      <translation type="unfinished">Any method allowed, whole part</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.ui" line="129"/>
      <source>Material removal required, whole part</source>
      <translation type="unfinished">Material removal required, whole part</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.ui" line="163"/>
      <source>Material removal required</source>
      <translation type="unfinished">Material removal required</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.ui" line="197"/>
      <source>Material removal prohibited</source>
      <translation type="unfinished">Material removal prohibited</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.ui" line="231"/>
      <source>Any method allowed</source>
      <translation type="unfinished">Any method allowed</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.ui" line="255"/>
      <source>Rotation angle</source>
      <translation type="unfinished">Rotation angle</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.ui" line="265"/>
      <source>Use ISO standard</source>
      <translation type="unfinished">Use ISO standard</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.ui" line="278"/>
      <source>Use ASME standard</source>
      <translation type="unfinished">Use ASME standard</translation>
    </message>
    <message>
      <location filename="../../TaskSurfaceFinishSymbols.ui" line="248"/>
      <source>Symbol angle:</source>
      <translation type="unfinished">Symbol angle:</translation>
    </message>
    <message>
      <location filename="../../TaskHoleShaftFit.ui" line="29"/>
      <source>Hole /Shaft Fit ISO 286</source>
      <translation type="unfinished">Hole /Shaft Fit ISO 286</translation>
    </message>
    <message>
      <location filename="../../TaskHoleShaftFit.ui" line="37"/>
      <source>Shaft fit</source>
      <translation type="unfinished">Shaft fit</translation>
    </message>
    <message>
      <location filename="../../TaskHoleShaftFit.ui" line="47"/>
      <source>Hole fit</source>
      <translation type="unfinished">Hole fit</translation>
    </message>
    <message>
      <location filename="../../TaskHoleShaftFit.ui" line="145"/>
      <source>loose fit</source>
      <translation type="unfinished">loose fit</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskWeldingSymbol</name>
    <message>
      <location filename="../../TaskWeldingSymbol.cpp" line="214"/>
      <location filename="../../TaskWeldingSymbol.cpp" line="236"/>
      <location filename="../../TaskWeldingSymbol.cpp" line="283"/>
      <location filename="../../TaskWeldingSymbol.cpp" line="295"/>
      <source>Symbol</source>
      <translation type="unfinished">Symbol</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.cpp" line="384"/>
      <source>arrow</source>
      <translation type="unfinished">arrow</translation>
    </message>
    <message>
      <location filename="../../TaskWeldingSymbol.cpp" line="385"/>
      <source>other</source>
      <translation type="unfinished">other</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::dlgTemplateField</name>
    <message>
      <location filename="../../DlgTemplateField.ui" line="17"/>
      <source>Change Editable Field</source>
      <translation type="unfinished">Change Editable Field</translation>
    </message>
    <message>
      <location filename="../../DlgTemplateField.ui" line="28"/>
      <source>Text Name:</source>
      <translation type="unfinished">Text Name:</translation>
    </message>
    <message>
      <location filename="../../DlgTemplateField.ui" line="35"/>
      <source>TextLabel</source>
      <translation type="unfinished">TextLabel</translation>
    </message>
    <message>
      <location filename="../../DlgTemplateField.ui" line="42"/>
      <source>Value:</source>
      <translation type="unfinished">Value:</translation>
    </message>
    <message>
      <location filename="../../DlgTemplateField.ui" line="52"/>
      <source>Check this box to reapply autofill to this field.  </source>
      <translation type="unfinished">Check this box to reapply autofill to this field.  </translation>
    </message>
    <message>
      <location filename="../../DlgTemplateField.ui" line="55"/>
      <source>Autofill</source>
      <translation type="unfinished">Autofill</translation>
    </message>
    <message>
      <location filename="../../DlgTemplateField.ui" line="65"/>
      <source>The autofill replacement value.</source>
      <translation type="unfinished">The autofill replacement value.</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_2LineCenterLine</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="660"/>
      <source>Adds a Centerline between 2 Lines</source>
      <translation type="unfinished">Adds a Centerline between 2 Lines</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_2PointCenterLine</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="664"/>
      <source>Adds a Centerline between 2 Points</source>
      <translation type="unfinished">Adds a Centerline between 2 Points</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_ComplexSection</name>
    <message>
      <location filename="../../Command.cpp" line="801"/>
      <source>Insert complex Section View</source>
      <translation type="unfinished">Insert complex Section View</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_CosmeticVertex</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="282"/>
      <source>Inserts a Cosmetic Vertex into a View</source>
      <translation type="unfinished">Inserts a Cosmetic Vertex into a View</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_ExtensionremovePrefixChar</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="416"/>
      <source>Remove Prefix</source>
      <translation type="unfinished">Remove Prefix</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="417"/>
      <source>Remove prefix symbols at the beginning of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Remove prefix symbols at the beginning of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_FaceCenterLine</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="656"/>
      <source>Adds a Centerline to Faces</source>
      <translation type="unfinished">Adds a Centerline to Faces</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_HorizontalExtent</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2036"/>
      <source>Insert Horizontal Extent Dimension</source>
      <translation type="unfinished">Insert Horizontal Extent Dimension</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_Midpoints</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="286"/>
      <source>Inserts Cosmetic Vertices at Midpoint of selected Edges</source>
      <translation type="unfinished">Inserts Cosmetic Vertices at Midpoint of selected Edges</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_Quadrants</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="290"/>
      <source>Inserts Cosmetic Vertices at Quadrant Points of selected Circles</source>
      <translation type="unfinished">Inserts Cosmetic Vertices at Quadrant Points of selected Circles</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_SectionView</name>
    <message>
      <location filename="../../Command.cpp" line="796"/>
      <source>Insert simple Section View</source>
      <translation type="unfinished">Insert simple Section View</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_StackBottom</name>
    <message>
      <location filename="../../CommandStack.cpp" line="148"/>
      <source>Move view to bottom of stack</source>
      <translation type="unfinished">Move view to bottom of stack</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_StackDown</name>
    <message>
      <location filename="../../CommandStack.cpp" line="156"/>
      <source>Move view down one level</source>
      <translation type="unfinished">Move view down one level</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_StackTop</name>
    <message>
      <location filename="../../CommandStack.cpp" line="144"/>
      <source>Move view to top of stack</source>
      <translation type="unfinished">Move view to top of stack</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_StackUp</name>
    <message>
      <location filename="../../CommandStack.cpp" line="152"/>
      <source>Move view up one level</source>
      <translation type="unfinished">Move view up one level</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_VerticalExtentDimension</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2040"/>
      <source>Insert Vertical Extent Dimension</source>
      <translation type="unfinished">Insert Vertical Extent Dimension</translation>
    </message>
  </context>
  <context>
    <name>Workbench</name>
    <message>
      <location filename="../../Workbench.cpp" line="39"/>
      <source>Dimensions</source>
      <translation type="unfinished">Dimensions</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="40"/>
      <source>Extensions: Attributes/Modifications</source>
      <translation type="unfinished">Extensions: Attributes/Modifications</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="41"/>
      <source>Extensions: Centerlines/Threading</source>
      <translation type="unfinished">Extensions: Centerlines/Threading</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="42"/>
      <source>Extensions: Dimensions</source>
      <translation type="unfinished">Extensions: Dimensions</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="43"/>
      <source>Annotations</source>
      <translation type="unfinished">Annotations</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="44"/>
      <source>Stacking</source>
      <translation type="unfinished">Stacking</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="45"/>
      <source>Add Lines</source>
      <translation type="unfinished">Add Lines</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="46"/>
      <source>Add Vertices</source>
      <translation type="unfinished">Add Vertices</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="47"/>
      <source>Page</source>
      <translation>পৃষ্ঠা</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="48"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="51"/>
      <source>TechDraw Attributes</source>
      <translation type="unfinished">TechDraw Attributes</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="52"/>
      <source>TechDraw Centerlines</source>
      <translation type="unfinished">TechDraw Centerlines</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="55"/>
      <source>TechDraw Extend Dimensions</source>
      <translation type="unfinished">TechDraw Extend Dimensions</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="57"/>
      <source>TechDraw Pages</source>
      <translation type="unfinished">TechDraw Pages</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="58"/>
      <source>TechDraw Stacking</source>
      <translation type="unfinished">TechDraw Stacking</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="60"/>
      <source>TechDraw Views</source>
      <translation type="unfinished">TechDraw Views</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="54"/>
      <source>TechDraw Dimensions</source>
      <translation type="unfinished">TechDraw Dimensions</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="59"/>
      <source>TechDraw Tool Attributes</source>
      <translation type="unfinished">TechDraw Tool Attributes</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="56"/>
      <source>TechDraw File Access</source>
      <translation type="unfinished">TechDraw File Access</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="53"/>
      <source>TechDraw Decoration</source>
      <translation type="unfinished">TechDraw Decoration</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="50"/>
      <source>TechDraw Annotation</source>
      <translation type="unfinished">TechDraw Annotation</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="61"/>
      <source>Views From Other Workbenches</source>
      <translation type="unfinished">Views From Other Workbenches</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="62"/>
      <source>Clipped Views</source>
      <translation type="unfinished">Clipped Views</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="63"/>
      <source>Hatching</source>
      <translation type="unfinished">Hatching</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="64"/>
      <source>Symbols</source>
      <translation type="unfinished">Symbols</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="65"/>
      <source>Views</source>
      <translation type="unfinished">Views</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_MoveView</name>
    <message>
      <location filename="../../../TechDrawTools/CommandMoveView.py" line="47"/>
      <source>Move View</source>
      <translation type="unfinished">Move View</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/CommandMoveView.py" line="50"/>
      <source>Move a View to a new Page</source>
      <translation type="unfinished">Move a View to a new Page</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskMoveView.py" line="48"/>
      <source>Move View to a different Page</source>
      <translation type="unfinished">Move View to a different Page</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskMoveView.py" line="80"/>
      <source>Select View to move from list.</source>
      <translation type="unfinished">Select View to move from list.</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskMoveView.py" line="81"/>
      <source>Select View</source>
      <translation type="unfinished">Select View</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskMoveView.py" line="103"/>
      <source>Select From Page.</source>
      <translation type="unfinished">Select From Page.</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskMoveView.py" line="104"/>
      <location filename="../../../TechDrawTools/TaskMoveView.py" line="127"/>
      <source>Select Page</source>
      <translation type="unfinished">Select Page</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskMoveView.py" line="126"/>
      <source>Select To Page.</source>
      <translation type="unfinished">Select To Page.</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_ShareView</name>
    <message>
      <location filename="../../../TechDrawTools/CommandShareView.py" line="47"/>
      <source>Share View</source>
      <translation type="unfinished">Share View</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/CommandShareView.py" line="50"/>
      <source>Share a View on a second Page</source>
      <translation type="unfinished">Share a View on a second Page</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskShareView.py" line="47"/>
      <source>Share View with another Page</source>
      <translation type="unfinished">Share View with another Page</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskShareView.py" line="48"/>
      <source>View to share</source>
      <translation type="unfinished">View to share</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskShareView.py" line="80"/>
      <source>Select View to share from list.</source>
      <translation type="unfinished">Select View to share from list.</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskShareView.py" line="81"/>
      <source>Select View</source>
      <translation type="unfinished">Select View</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskShareView.py" line="103"/>
      <source>Select From Page.</source>
      <translation type="unfinished">Select From Page.</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskShareView.py" line="104"/>
      <location filename="../../../TechDrawTools/TaskShareView.py" line="128"/>
      <source>Select Page</source>
      <translation type="unfinished">Select Page</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskShareView.py" line="127"/>
      <source>Select To Page.</source>
      <translation type="unfinished">Select To Page.</translation>
    </message>
  </context>
  <context>
    <name>TaskDimRepair</name>
    <message>
      <location filename="../../TaskDimRepair.ui" line="14"/>
      <source>Dimension Repair</source>
      <translation type="unfinished">Dimension Repair</translation>
    </message>
    <message>
      <location filename="../../TaskDimRepair.ui" line="20"/>
      <source>Dimension</source>
      <translation type="unfinished">Dimension</translation>
    </message>
    <message>
      <location filename="../../TaskDimRepair.ui" line="28"/>
      <source>Name</source>
      <translation type="unfinished">Name</translation>
    </message>
    <message>
      <location filename="../../TaskDimRepair.ui" line="35"/>
      <source>Label</source>
      <translation>লেবেল</translation>
    </message>
    <message>
      <location filename="../../TaskDimRepair.ui" line="86"/>
      <source>Replace References with Current Selection</source>
      <translation type="unfinished">Replace References with Current Selection</translation>
    </message>
    <message>
      <location filename="../../TaskDimRepair.ui" line="98"/>
      <source>References 2D</source>
      <translation type="unfinished">References 2D</translation>
    </message>
    <message>
      <location filename="../../TaskDimRepair.ui" line="106"/>
      <source>Object</source>
      <translation type="unfinished">Object</translation>
    </message>
    <message>
      <location filename="../../TaskDimRepair.ui" line="119"/>
      <source>The View that owns this Dimension</source>
      <translation type="unfinished">The View that owns this Dimension</translation>
    </message>
    <message>
      <location filename="../../TaskDimRepair.ui" line="138"/>
      <source>Geometry</source>
      <translation type="unfinished">Geometry</translation>
    </message>
    <message>
      <location filename="../../TaskDimRepair.ui" line="163"/>
      <source>The subelements of the View that define the geometry for this Dimension</source>
      <translation type="unfinished">The subelements of the View that define the geometry for this Dimension</translation>
    </message>
    <message>
      <location filename="../../TaskDimRepair.ui" line="187"/>
      <source>References 3D</source>
      <translation type="unfinished">References 3D</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::DlgStringListEditor</name>
    <message>
      <location filename="../../DlgStringListEditor.ui" line="17"/>
      <source>String List Editor</source>
      <translation type="unfinished">String List Editor</translation>
    </message>
    <message>
      <location filename="../../DlgStringListEditor.ui" line="31"/>
      <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Double click to edit a line.  New lines are added at the current location in the list.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
      <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Double click to edit a line.  New lines are added at the current location in the list.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawDimensionRepair</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2210"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="2211"/>
      <source>Repair Dimension References</source>
      <translation type="unfinished">Repair Dimension References</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskDimRepair</name>
    <message>
      <location filename="../../TaskDimRepair.cpp" line="81"/>
      <source>Object Name</source>
      <translation type="unfinished">Object Name</translation>
    </message>
    <message>
      <location filename="../../TaskDimRepair.cpp" line="81"/>
      <source>Object Label</source>
      <translation type="unfinished">Object Label</translation>
    </message>
    <message>
      <location filename="../../TaskDimRepair.cpp" line="81"/>
      <source>SubElement</source>
      <translation type="unfinished">SubElement</translation>
    </message>
    <message>
      <location filename="../../TaskDimRepair.cpp" line="236"/>
      <source>Repair Dimension</source>
      <translation type="unfinished">Repair Dimension</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_AxoLengthDimension</name>
    <message>
      <location filename="../../../TechDrawTools/CommandAxoLengthDimension.py" line="54"/>
      <source>Axonometric length dimension</source>
      <translation type="unfinished">Axonometric length dimension</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/CommandAxoLengthDimension.py" line="61"/>
      <source>Create an axonometric length dimension&lt;br&gt;
                - select first edge to define direction and length of the dimension line&lt;br&gt;
                - select second edge to define the direction of the extension lines&lt;br&gt;
                - optional: select two more vertexes which define the measurement instead of the length&lt;br&gt;
                  of the first selected edge</source>
      <translation type="unfinished">Create an axonometric length dimension&lt;br&gt;
                - select first edge to define direction and length of the dimension line&lt;br&gt;
                - select second edge to define the direction of the extension lines&lt;br&gt;
                - optional: select two more vertexes which define the measurement instead of the length&lt;br&gt;
                  of the first selected edge</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_HoleShaftFit</name>
    <message>
      <location filename="../../../TechDrawTools/CommandHoleShaftFit.py" line="51"/>
      <source>Add hole or shaft fit</source>
      <translation type="unfinished">Add hole or shaft fit</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/CommandHoleShaftFit.py" line="59"/>
      <source>Add a hole or shaft fit to a dimension
- select one length dimension or diameter dimension
- click the tool button, a panel opens
- select shaft fit / hole fit
- select the desired ISO 286 fit field using the combo box</source>
      <translation type="unfinished">Add a hole or shaft fit to a dimension
- select one length dimension or diameter dimension
- click the tool button, a panel opens
- select shaft fit / hole fit
- select the desired ISO 286 fit field using the combo box</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/CommandHoleShaftFit.py" line="74"/>
      <source>Add a hole or shaft fit to a dimension</source>
      <translation type="unfinished">Add a hole or shaft fit to a dimension</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/CommandHoleShaftFit.py" line="78"/>
      <source>Please select one length dimension or diameter dimension and retry</source>
      <translation type="unfinished">Please select one length dimension or diameter dimension and retry</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskHoleShaftFit.py" line="43"/>
      <source>loose fit</source>
      <translation type="unfinished">loose fit</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskHoleShaftFit.py" line="44"/>
      <source>snug fit</source>
      <translation type="unfinished">snug fit</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskHoleShaftFit.py" line="45"/>
      <source>press fit</source>
      <translation type="unfinished">press fit</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskHoleShaftFit.py" line="92"/>
      <source>Hole / Shaft Fit ISO 286</source>
      <translation type="unfinished">Hole / Shaft Fit ISO 286</translation>
    </message>
  </context>
  <context>
    <name>ArrowPropEnum</name>
    <message>
      <location filename="../../../App/ArrowPropEnum.cpp" line="32"/>
      <source>Filled Arrow</source>
      <translation type="unfinished">Filled Arrow</translation>
    </message>
    <message>
      <location filename="../../../App/ArrowPropEnum.cpp" line="33"/>
      <source>Open Arrow</source>
      <translation type="unfinished">Open Arrow</translation>
    </message>
    <message>
      <location filename="../../../App/ArrowPropEnum.cpp" line="34"/>
      <source>Tick</source>
      <translation type="unfinished">Tick</translation>
    </message>
    <message>
      <location filename="../../../App/ArrowPropEnum.cpp" line="35"/>
      <source>Dot</source>
      <translation type="unfinished">Dot</translation>
    </message>
    <message>
      <location filename="../../../App/ArrowPropEnum.cpp" line="36"/>
      <source>Open Circle</source>
      <translation type="unfinished">Open Circle</translation>
    </message>
    <message>
      <location filename="../../../App/ArrowPropEnum.cpp" line="37"/>
      <source>Fork</source>
      <translation type="unfinished">Fork</translation>
    </message>
    <message>
      <location filename="../../../App/ArrowPropEnum.cpp" line="38"/>
      <source>Filled Triangle</source>
      <translation type="unfinished">Filled Triangle</translation>
    </message>
    <message>
      <location filename="../../../App/ArrowPropEnum.cpp" line="39"/>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
  </context>
  <context>
    <name>DrawProjGroupItem</name>
    <message>
      <location filename="../../../App/DrawProjGroupItem.cpp" line="44"/>
      <source>Front</source>
      <translation type="unfinished">Front</translation>
    </message>
    <message>
      <location filename="../../../App/DrawProjGroupItem.cpp" line="45"/>
      <source>Left</source>
      <translation type="unfinished">Left</translation>
    </message>
    <message>
      <location filename="../../../App/DrawProjGroupItem.cpp" line="46"/>
      <source>Right</source>
      <translation type="unfinished">Right</translation>
    </message>
    <message>
      <location filename="../../../App/DrawProjGroupItem.cpp" line="47"/>
      <source>Rear</source>
      <translation type="unfinished">Rear</translation>
    </message>
    <message>
      <location filename="../../../App/DrawProjGroupItem.cpp" line="48"/>
      <source>Top</source>
      <translation type="unfinished">Top</translation>
    </message>
    <message>
      <location filename="../../../App/DrawProjGroupItem.cpp" line="49"/>
      <source>Bottom</source>
      <translation type="unfinished">Bottom</translation>
    </message>
    <message>
      <location filename="../../../App/DrawProjGroupItem.cpp" line="50"/>
      <source>FrontTopLeft</source>
      <translation type="unfinished">FrontTopLeft</translation>
    </message>
    <message>
      <location filename="../../../App/DrawProjGroupItem.cpp" line="51"/>
      <source>FrontTopRight</source>
      <translation type="unfinished">FrontTopRight</translation>
    </message>
    <message>
      <location filename="../../../App/DrawProjGroupItem.cpp" line="52"/>
      <source>FrontBottomLeft</source>
      <translation type="unfinished">FrontBottomLeft</translation>
    </message>
    <message>
      <location filename="../../../App/DrawProjGroupItem.cpp" line="53"/>
      <source>FrontBottomRight</source>
      <translation type="unfinished">FrontBottomRight</translation>
    </message>
  </context>
  <context>
    <name>TaskBalloon</name>
    <message>
      <location filename="../../ViewProviderBalloon.cpp" line="182"/>
      <source>You cannot delete this balloon now because
there is an open task dialog.</source>
      <translation type="unfinished">You cannot delete this balloon now because
there is an open task dialog.</translation>
    </message>
    <message>
      <location filename="../../ViewProviderBalloon.cpp" line="185"/>
      <source>Can Not Delete</source>
      <translation type="unfinished">Can Not Delete</translation>
    </message>
  </context>
  <context>
    <name>DrawPage</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="57"/>
      <source>Page</source>
      <translation>পৃষ্ঠা</translation>
    </message>
  </context>
  <context>
    <name>DrawSVGTemplate</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="58"/>
      <source>Template</source>
      <translation type="unfinished">Template</translation>
    </message>
  </context>
  <context>
    <name>DrawView</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="59"/>
      <source>View</source>
      <translation type="unfinished">View</translation>
    </message>
  </context>
  <context>
    <name>DrawViewPart</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="60"/>
      <source>View</source>
      <translation type="unfinished">View</translation>
    </message>
  </context>
  <context>
    <name>DrawViewSection</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="61"/>
      <source>Section</source>
      <translation type="unfinished">Section</translation>
    </message>
  </context>
  <context>
    <name>DrawComplexSection</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="62"/>
      <source>Section</source>
      <translation type="unfinished">Section</translation>
    </message>
  </context>
  <context>
    <name>DrawViewDetail</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="63"/>
      <source>Detail</source>
      <translation type="unfinished">Detail</translation>
    </message>
  </context>
  <context>
    <name>DrawActiveView</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="64"/>
      <source>ActiveView</source>
      <translation type="unfinished">ActiveView</translation>
    </message>
  </context>
  <context>
    <name>DrawViewAnnotation</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="65"/>
      <source>Annotation</source>
      <translation type="unfinished">Annotation</translation>
    </message>
  </context>
  <context>
    <name>DrawViewImage</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="66"/>
      <source>Image</source>
      <translation type="unfinished">Image</translation>
    </message>
  </context>
  <context>
    <name>DrawViewSymbol</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="67"/>
      <source>Symbol</source>
      <translation type="unfinished">Symbol</translation>
    </message>
  </context>
  <context>
    <name>DrawViewArch</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="68"/>
      <source>Arch</source>
      <translation type="unfinished">Arch</translation>
    </message>
  </context>
  <context>
    <name>DrawViewDraft</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="69"/>
      <source>Draft</source>
      <translation type="unfinished">Draft</translation>
    </message>
  </context>
  <context>
    <name>DrawLeaderLine</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="70"/>
      <source>LeaderLine</source>
      <translation type="unfinished">LeaderLine</translation>
    </message>
  </context>
  <context>
    <name>DrawViewBalloon</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="71"/>
      <source>Balloon</source>
      <translation type="unfinished">Balloon</translation>
    </message>
  </context>
  <context>
    <name>DrawViewDimension</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="72"/>
      <source>Dimension</source>
      <translation type="unfinished">Dimension</translation>
    </message>
  </context>
  <context>
    <name>DrawViewDimExtent</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="73"/>
      <source>Extent</source>
      <translation type="unfinished">Extent</translation>
    </message>
  </context>
  <context>
    <name>DrawHatch</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="74"/>
      <source>Hatch</source>
      <translation type="unfinished">Hatch</translation>
    </message>
  </context>
  <context>
    <name>DrawGeomHatch</name>
    <message>
      <location filename="../../../App/DrawView.cpp" line="75"/>
      <source>GeomHatch</source>
      <translation type="unfinished">GeomHatch</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskCosmeticCircle</name>
    <message>
      <location filename="../../TaskCosmeticCircle.ui" line="26"/>
      <source>Cosmetic Circle</source>
      <translation type="unfinished">Cosmetic Circle</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.ui" line="34"/>
      <source>View</source>
      <translation type="unfinished">View</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.ui" line="90"/>
      <source>Circle Center</source>
      <translation type="unfinished">Circle Center</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.ui" line="147"/>
      <source>Radius:</source>
      <translation type="unfinished">Radius:</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.ui" line="205"/>
      <source>Start Angle:</source>
      <translation type="unfinished">Start Angle:</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.ui" line="212"/>
      <source>Check this box to make an arc from start angle to end angle in a clockwise direction.</source>
      <translation type="unfinished">Check this box to make an arc from start angle to end angle in a clockwise direction.</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.ui" line="215"/>
      <source>Clockwise Angle</source>
      <translation type="unfinished">Clockwise Angle</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.ui" line="195"/>
      <source>End angle (conventional) of arc in degrees.</source>
      <translation type="unfinished">End angle (conventional) of arc in degrees.</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.ui" line="61"/>
      <source>Treat the center point as a 2D point within the parent View.  Z coordinate is ignored.</source>
      <translation type="unfinished">Treat the center point as a 2D point within the parent View.  Z coordinate is ignored.</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.ui" line="64"/>
      <source>2D Point</source>
      <translation type="unfinished">2D Point</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.ui" line="77"/>
      <source>Treat the center point as a 3D point and project it onto the parent View.</source>
      <translation type="unfinished">Treat the center point as a 3D point and project it onto the parent View.</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.ui" line="80"/>
      <source>3D Point</source>
      <translation type="unfinished">3D Point</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.ui" line="188"/>
      <source>End Angle:</source>
      <translation type="unfinished">End Angle:</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.ui" line="171"/>
      <source>Start angle (conventional) of arc in degrees.</source>
      <translation type="unfinished">Start angle (conventional) of arc in degrees.</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.ui" line="181"/>
      <source>Arc of Circle</source>
      <translation type="unfinished">Arc of Circle</translation>
    </message>
    <message>
      <location filename="../../TaskCosmeticCircle.cpp" line="182"/>
      <source>Radius must be non-zero positive number</source>
      <translation type="unfinished">Radius must be non-zero positive number</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawCosmeticCircle</name>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1134"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandAnnotate.cpp" line="1135"/>
      <source>Add Cosmetic Circle</source>
      <translation type="unfinished">Add Cosmetic Circle</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionArcLengthAnnotation</name>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1895"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1896"/>
      <source>Calculate the arc length of selected edges</source>
      <translation type="unfinished">Calculate the arc length of selected edges</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionPack.cpp" line="1897"/>
      <source>Select several edges&lt;br&gt;    - click this tool</source>
      <translation type="unfinished">Select several edges&lt;br&gt;    - click this tool</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::TaskAddOffsetVertex</name>
    <message>
      <location filename="../../TaskAddOffsetVertex.ui" line="14"/>
      <source>Cosmetic Vertex</source>
      <translation type="unfinished">Cosmetic Vertex</translation>
    </message>
    <message>
      <location filename="../../TaskAddOffsetVertex.ui" line="31"/>
      <source>Position from the view center</source>
      <translation type="unfinished">Position from the view center</translation>
    </message>
    <message>
      <location filename="../../TaskAddOffsetVertex.ui" line="34"/>
      <source>Position</source>
      <translation type="unfinished">Position</translation>
    </message>
    <message>
      <location filename="../../TaskAddOffsetVertex.ui" line="48"/>
      <source>X-Offset</source>
      <translation type="unfinished">X-Offset</translation>
    </message>
    <message>
      <location filename="../../TaskAddOffsetVertex.ui" line="55"/>
      <source>Y-Offset</source>
      <translation type="unfinished">Y-Offset</translation>
    </message>
    <message>
      <location filename="../../TaskAddOffsetVertex.ui" line="72"/>
      <source>Enter X offset value</source>
      <translation type="unfinished">Enter X offset value</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_AddOffsetVertex</name>
    <message>
      <location filename="../../../TechDrawTools/CommandVertexCreations.py" line="77"/>
      <source>Add an offset vertex</source>
      <translation type="unfinished">Add an offset vertex</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/CommandVertexCreations.py" line="83"/>
      <source>Create an offset vertex&lt;br&gt;
                - select one vertex&lt;br&gt;
                - start the tool&lt;br&gt;
                - enter offset values in panel</source>
      <translation type="unfinished">Create an offset vertex&lt;br&gt;
                - select one vertex&lt;br&gt;
                - start the tool&lt;br&gt;
                - enter offset values in panel</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskAddOffsetVertex.py" line="45"/>
      <source>Add offset vertex</source>
      <translation type="unfinished">Add offset vertex</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_FillTemplateFields</name>
    <message>
      <location filename="../../../TechDrawTools/CommandFillTemplateFields.py" line="50"/>
      <source>Update template fields</source>
      <translation type="unfinished">Update template fields</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/CommandFillTemplateFields.py" line="54"/>
      <source>Use document info to populate the template fields</source>
      <translation type="unfinished">Use document info to populate the template fields</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskFillTemplateFields.py" line="136"/>
      <source>Fill Template Fields in </source>
      <translation type="unfinished">Fill Template Fields in </translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskFillTemplateFields.py" line="143"/>
      <source>Update</source>
      <translation type="unfinished">Update</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskFillTemplateFields.py" line="352"/>
      <source>Update All</source>
      <translation type="unfinished">Update All</translation>
    </message>
  </context>
  <context>
    <name>Techdraw_FillTemplateFields</name>
    <message>
      <location filename="../../../TechDrawTools/TaskFillTemplateFields.py" line="81"/>
      <source> file does not contain the correct field names therefore exiting</source>
      <translation type="unfinished"> file does not contain the correct field names therefore exiting</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskFillTemplateFields.py" line="87"/>
      <source> file has not been found therefore exiting</source>
      <translation type="unfinished"> file has not been found therefore exiting</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskFillTemplateFields.py" line="108"/>
      <source>View or Projection Group missing</source>
      <translation type="unfinished">View or Projection Group missing</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TaskFillTemplateFields.py" line="382"/>
      <source>Corresponding template fields missing</source>
      <translation type="unfinished">Corresponding template fields missing</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_Utils</name>
    <message>
      <location filename="../../../TechDrawTools/TDToolsUtil.py" line="79"/>
      <source>No vertex selected</source>
      <translation type="unfinished">No vertex selected</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TDToolsUtil.py" line="91"/>
      <location filename="../../../TechDrawTools/TDToolsUtil.py" line="122"/>
      <source>Select at least </source>
      <translation type="unfinished">Select at least </translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TDToolsUtil.py" line="92"/>
      <source> vertexes</source>
      <translation type="unfinished"> vertexes</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TDToolsUtil.py" line="110"/>
      <source>No edge selected</source>
      <translation type="unfinished">No edge selected</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/TDToolsUtil.py" line="123"/>
      <source> edges</source>
      <translation type="unfinished"> edges</translation>
    </message>
  </context>
  <context>
    <name>ISOLineTypeEnum</name>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="59"/>
      <source>NoLine</source>
      <translation type="unfinished">NoLine</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="60"/>
      <source>Continuous</source>
      <translation type="unfinished">Continuous</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="61"/>
      <source>Dashed</source>
      <translation type="unfinished">Dashed</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="62"/>
      <source>DashedSpaced</source>
      <translation type="unfinished">DashedSpaced</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="63"/>
      <source>LongDashedDotted</source>
      <translation type="unfinished">LongDashedDotted</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="64"/>
      <source>LongDashedDoubleDotted</source>
      <translation type="unfinished">LongDashedDoubleDotted</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="65"/>
      <source>LongDashedTripleDotted</source>
      <translation type="unfinished">LongDashedTripleDotted</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="66"/>
      <source>Dotted</source>
      <translation type="unfinished">Dotted</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="67"/>
      <source>LongDashShortDash</source>
      <translation type="unfinished">LongDashShortDash</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="68"/>
      <source>LongDashDoubleShortDash</source>
      <translation type="unfinished">LongDashDoubleShortDash</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="69"/>
      <source>DashedDotted</source>
      <translation type="unfinished">DashedDotted</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="70"/>
      <source>DoubleDashedDotted</source>
      <translation type="unfinished">DoubleDashedDotted</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="71"/>
      <source>DashedDoubleDotted</source>
      <translation type="unfinished">DashedDoubleDotted</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="72"/>
      <source>DoubleDashedDoubleDotted</source>
      <translation type="unfinished">DoubleDashedDoubleDotted</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="73"/>
      <source>DashedTripleDotted</source>
      <translation type="unfinished">DashedTripleDotted</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="74"/>
      <source>DoubleDashedTripleDotted</source>
      <translation type="unfinished">DoubleDashedTripleDotted</translation>
    </message>
  </context>
  <context>
    <name>ANSILineTypeEnum</name>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="80"/>
      <source>NoLine</source>
      <translation type="unfinished">NoLine</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="81"/>
      <source>Continuous</source>
      <translation type="unfinished">Continuous</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="82"/>
      <source>Dashed</source>
      <translation type="unfinished">Dashed</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="83"/>
      <source>LongDashDashed</source>
      <translation type="unfinished">LongDashDashed</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="84"/>
      <source>LongDashDoubleDashed</source>
      <translation type="unfinished">LongDashDoubleDashed</translation>
    </message>
  </context>
  <context>
    <name>ASMELineTypeEnum</name>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="90"/>
      <source>NoLine</source>
      <translation type="unfinished">NoLine</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="91"/>
      <source>Visible</source>
      <translation type="unfinished">Visible</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="92"/>
      <source>Hidden</source>
      <translation type="unfinished">Hidden</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="93"/>
      <source>Section</source>
      <translation type="unfinished">Section</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="94"/>
      <source>Center</source>
      <translation type="unfinished">Center</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="95"/>
      <source>Symmetry</source>
      <translation type="unfinished">Symmetry</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="96"/>
      <source>Dimension</source>
      <translation type="unfinished">Dimension</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="97"/>
      <source>Extension</source>
      <translation type="unfinished">Extension</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="98"/>
      <source>Leader</source>
      <translation type="unfinished">Leader</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="99"/>
      <source>CuttingPlane</source>
      <translation type="unfinished">CuttingPlane</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="100"/>
      <source>ViewingPlane</source>
      <translation type="unfinished">ViewingPlane</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="101"/>
      <source>OtherPlane</source>
      <translation type="unfinished">OtherPlane</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="102"/>
      <source>Break1</source>
      <translation type="unfinished">Break1</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="103"/>
      <source>Break2</source>
      <translation type="unfinished">Break2</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="104"/>
      <source>Phantom</source>
      <translation type="unfinished">Phantom</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="105"/>
      <source>Stitch1</source>
      <translation type="unfinished">Stitch1</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="106"/>
      <source>Stitch2</source>
      <translation type="unfinished">Stitch2</translation>
    </message>
    <message>
      <location filename="../../../App/LineNameEnum.cpp" line="107"/>
      <source>Chain</source>
      <translation type="unfinished">Chain</translation>
    </message>
  </context>
  <context>
    <name>TechDraw_PositionSectionView</name>
    <message>
      <location filename="../../../TechDrawTools/CommandPositionSectionView.py" line="51"/>
      <source>Position Section View</source>
      <translation type="unfinished">Position Section View</translation>
    </message>
    <message>
      <location filename="../../../TechDrawTools/CommandPositionSectionView.py" line="59"/>
      <source>Orthogonally align a section view with its source view:&lt;br&gt;
                - Select a single section view&lt;br&gt;
                - Click this tool&lt;br&gt;
                - optional: select one edge in the section view and it&apos;s corresponding vertex in the base view&lt;br&gt;
                  Click this tool</source>
      <translation type="unfinished">Orthogonally align a section view with its source view:&lt;br&gt;
                - Select a single section view&lt;br&gt;
                - Click this tool&lt;br&gt;
                - optional: select one edge in the section view and it&apos;s corresponding vertex in the base view&lt;br&gt;
                  Click this tool</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawExtensionInsertRepetition</name>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="221"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="222"/>
      <location filename="../../CommandExtensionDims.cpp" line="409"/>
      <source>Insert &apos;n×&apos; Prefix</source>
      <translation type="unfinished">Insert &apos;n×&apos; Prefix</translation>
    </message>
    <message>
      <location filename="../../CommandExtensionDims.cpp" line="223"/>
      <location filename="../../CommandExtensionDims.cpp" line="410"/>
      <source>Insert repeated feature count at the beginning of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</source>
      <translation type="unfinished">Insert repeated feature count at the beginning of the dimension text:&lt;br&gt;- Select one or more dimensions&lt;br&gt;- Click this tool</translation>
    </message>
  </context>
  <context>
    <name>Preferences</name>
    <message>
      <location filename="../../../App/Preferences.cpp" line="466"/>
      <source>The LineStandard parameter is invalid. Using zero instead.</source>
      <translation type="unfinished">The LineStandard parameter is invalid. Using zero instead.</translation>
    </message>
  </context>
  <context>
    <name>TaskDimension</name>
    <message>
      <location filename="../../ViewProviderDimension.cpp" line="301"/>
      <source>You cannot delete this dimension now because
there is an open task dialog.</source>
      <translation type="unfinished">You cannot delete this dimension now because
there is an open task dialog.</translation>
    </message>
    <message>
      <location filename="../../ViewProviderDimension.cpp" line="304"/>
      <source>Can Not Delete</source>
      <translation type="unfinished">Can Not Delete</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawBrokenView</name>
    <message>
      <location filename="../../Command.cpp" line="550"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="551"/>
      <location filename="../../Command.cpp" line="552"/>
      <source>Insert Broken View</source>
      <translation type="unfinished">Insert Broken View</translation>
    </message>
  </context>
  <context>
    <name>TechDrawGui::DirectionEditDialog</name>
    <message>
      <location filename="../../TaskProjGroup.cpp" line="955"/>
      <source>Direction</source>
      <translation type="unfinished">Direction</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.cpp" line="992"/>
      <source>OK</source>
      <translation type="unfinished">OK</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.cpp" line="993"/>
      <source>Cancel</source>
      <translation type="unfinished">Cancel</translation>
    </message>
    <message>
      <location filename="../../TaskProjGroup.cpp" line="999"/>
      <source>Rotate by</source>
      <translation type="unfinished">Rotate by</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawCompDimensionTools</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1448"/>
      <source>Dimension</source>
      <translation type="unfinished">Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1449"/>
      <source>Dimension tools.</source>
      <translation type="unfinished">Dimension tools.</translation>
    </message>
  </context>
  <context>
    <name>CmdTechDrawAreaDimension</name>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1834"/>
      <source>TechDraw</source>
      <translation type="unfinished">TechDraw</translation>
    </message>
    <message>
      <location filename="../../CommandCreateDims.cpp" line="1835"/>
      <source>Insert Area Annotation</source>
      <translation type="unfinished">Insert Area Annotation</translation>
    </message>
  </context>
  <context>
    <name>DrawBrokenView</name>
    <message>
      <location filename="../../../App/DrawBrokenView.cpp" line="102"/>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
    <message>
      <location filename="../../../App/DrawBrokenView.cpp" line="103"/>
      <source>ZigZag</source>
      <translation type="unfinished">ZigZag</translation>
    </message>
    <message>
      <location filename="../../../App/DrawBrokenView.cpp" line="104"/>
      <source>Simple</source>
      <translation type="unfinished">Simple</translation>
    </message>
  </context>
  <context>
    <name>MattingPropEnum</name>
    <message>
      <location filename="../../../App/MattingPropEnum.cpp" line="32"/>
      <source>Circle</source>
      <translation type="unfinished">Circle</translation>
    </message>
    <message>
      <location filename="../../../App/MattingPropEnum.cpp" line="33"/>
      <source>Square</source>
      <translation type="unfinished">Square</translation>
    </message>
  </context>
  <context>
    <name>BalloonPropEnum</name>
    <message>
      <location filename="../../../App/BalloonPropEnum.cpp" line="32"/>
      <source>Circular</source>
      <translation type="unfinished">Circular</translation>
    </message>
    <message>
      <location filename="../../../App/BalloonPropEnum.cpp" line="33"/>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
    <message>
      <location filename="../../../App/BalloonPropEnum.cpp" line="34"/>
      <source>Triangle</source>
      <translation type="unfinished">Triangle</translation>
    </message>
    <message>
      <location filename="../../../App/BalloonPropEnum.cpp" line="35"/>
      <source>Inspection</source>
      <translation type="unfinished">Inspection</translation>
    </message>
    <message>
      <location filename="../../../App/BalloonPropEnum.cpp" line="36"/>
      <source>Hexagon</source>
      <translation type="unfinished">Hexagon</translation>
    </message>
    <message>
      <location filename="../../../App/BalloonPropEnum.cpp" line="37"/>
      <source>Square</source>
      <translation type="unfinished">Square</translation>
    </message>
    <message>
      <location filename="../../../App/BalloonPropEnum.cpp" line="38"/>
      <source>Rectangle</source>
      <translation type="unfinished">Rectangle</translation>
    </message>
    <message>
      <location filename="../../../App/BalloonPropEnum.cpp" line="39"/>
      <source>Line</source>
      <translation type="unfinished">Line</translation>
    </message>
  </context>
</TS>
