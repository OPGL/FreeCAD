<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="as" sourcelanguage="en">
  <context>
    <name>NavigationIndicator</name>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="85"/>
      <source>Select</source>
      <translation type="unfinished">Select</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="86"/>
      <source>Zoom</source>
      <translation type="unfinished">Zoom</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="87"/>
      <source>Rotate</source>
      <translation type="unfinished">Rotate</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="88"/>
      <source>Pan</source>
      <translation type="unfinished">Pan</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="89"/>
      <source>Tilt</source>
      <translation type="unfinished">Tilt</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="90"/>
      <source>Navigation style</source>
      <translation type="unfinished">Navigation style</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="91"/>
      <source>Page Up or Page Down key.</source>
      <translation type="unfinished">Page Up or Page Down key.</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="92"/>
      <source>Rotation focus</source>
      <translation type="unfinished">Rotation focus</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="93"/>
      <source>Middle mouse button or H key.</source>
      <translation type="unfinished">Middle mouse button or H key.</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="95"/>
      <source>Middle mouse button.</source>
      <translation type="unfinished">Middle mouse button.</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="98"/>
      <source>Navigation style not recognized.</source>
      <translation type="unfinished">Navigation style not recognized.</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="569"/>
      <source>Settings</source>
      <translation type="unfinished">Settings</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="570"/>
      <source>Orbit style</source>
      <translation type="unfinished">Orbit style</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="571"/>
      <source>Compact</source>
      <translation type="unfinished">Compact</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="572"/>
      <source>Tooltip</source>
      <translation type="unfinished">Tooltip</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="573"/>
      <source>Turntable</source>
      <translation type="unfinished">Turntable</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="574"/>
      <source>Free Turntable</source>
      <translation type="unfinished">Free Turntable</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="575"/>
      <source>Trackball</source>
      <translation type="unfinished">Trackball</translation>
    </message>
    <message>
      <location filename="../../NavigationIndicatorGui.py" line="576"/>
      <source>Undefined</source>
      <translation type="unfinished">Undefined</translation>
    </message>
  </context>
</TS>
