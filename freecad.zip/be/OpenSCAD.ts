<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="be" sourcelanguage="en">
  <context>
    <name>Gui::Dialog::DlgSettingsOpenSCAD</name>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="14"/>
      <source>General settings</source>
      <translation>Агульныя налады</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="35"/>
      <source>General OpenSCAD Settings</source>
      <translation>Агульныя налады OpenSCAD</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="43"/>
      <source>OpenSCAD executable</source>
      <translation>Файл OpenSCAD</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="56"/>
      <source>The path to the OpenSCAD executable</source>
      <translation>Шлях да файла OpenSCAD</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="74"/>
      <source>OpenSCAD import</source>
      <translation>Імпарт OpenSCAD</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="82"/>
      <source>Print debug information in the Console</source>
      <translation>Друк адладачную інфармацыю ў кансолі</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="99"/>
      <source>If this is checked, Features will claim their children in the tree view</source>
      <translation>Калі птушка, Аб'екты будуць паказваць іх дачынныя аб'екты ў дрэве прагляду</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="102"/>
      <source>Use ViewProvider in Tree View</source>
      <translation>Ужываць ViewProvider у дрэве прагляду</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="119"/>
      <source>If this is checked, Multmatrix Object will be Parametric</source>
      <translation>Калі птушка, аб'ект Multmatrix будзе Параметрычным</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="122"/>
      <source>Use Multmatrix Feature</source>
      <translation>Ужыць функцыю Multmatrix</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="139"/>
      <location filename="../ui/openscadprefs-base.ui" line="162"/>
      <source>The maximum number of faces of a polygon, prism or frustum. If fn is greater than this value the object is considered to be a circular. Set to 0 for no limit</source>
      <translation>Найбольшая колькасць граняў шматкутніка, прызмы ці ўсечанага конусу. Калі fn болей гэтага значэння, то аб'ект лічыцца кругавым. Ужыць 0, каб адключыць абмежаванні</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="142"/>
      <source>Maximum number of faces for polygons (fn)</source>
      <translation>Найбольшая колькасць граняў для шматкутніка (fn)</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="182"/>
      <source>Send to OpenSCAD via:</source>
      <translation>Адправіць у OpenSCAD праз:</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="195"/>
      <source>The transfer mechanism for getting data to and from OpenSCAD</source>
      <translation>Механізм перадачы дадзеных у OpenSCAD і з яго</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="205"/>
      <source>Standard temp directory</source>
      <translation>Стандартны часовы каталог</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="210"/>
      <source>User-specified directory</source>
      <translation>Карыстальніцкі каталог</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="215"/>
      <source>stdout pipe (requires OpenSCAD &gt;= 2021.1)</source>
      <translation>stdout pipe (патрабуецца OpenSCAD &gt;= 2021.1)</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="227"/>
      <source>Transfer directory</source>
      <translation>Каталог перадачы дадзеных</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="243"/>
      <source>The path to the directory for transferring files to and from OpenSCAD</source>
      <translation>Шлях да каталогу для перадачы файлаў у і з OpenSCAD</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="261"/>
      <source>OpenSCAD export</source>
      <translation>Экспарт OpenSCAD</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="269"/>
      <source>Maximum fragment size</source>
      <translation>Найбольшы памер фрагменту</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="292"/>
      <source>angle (fa)</source>
      <translation>вугал (fa)</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="388"/>
      <source>Convexity</source>
      <translation>Выпукласць</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="289"/>
      <location filename="../ui/openscadprefs-base.ui" line="299"/>
      <source>Minimum angle for a fragment</source>
      <translation>Найменшы вугал фрагменту</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="331"/>
      <location filename="../ui/openscadprefs-base.ui" line="356"/>
      <source>Minimum size of a fragment</source>
      <translation>Найменшы памер фрагменту</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="334"/>
      <source>size (fs)</source>
      <translation>памер (fs)</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="362"/>
      <source>mm</source>
      <translation>мм</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="425"/>
      <source>Mesh fallback</source>
      <translation>Адмена паліганальнай сеткі</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="445"/>
      <location filename="../ui/openscadprefs-base.ui" line="462"/>
      <source>Deflection</source>
      <translation>Адхіленне</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="448"/>
      <source>deflection</source>
      <translation>адхіленне</translation>
    </message>
    <message>
      <location filename="../ui/openscadprefs-base.ui" line="455"/>
      <source>Triangulation settings</source>
      <translation>Налады трыянгуляцыі</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD</name>
    <message>
      <location filename="../../InitGui.py" line="130"/>
      <source>It looks like you may be using a Snap version of OpenSCAD.</source>
      <translation>Падобна на тое, што вы, магчыма, ужываеце Snap-версію OpenSCAD.</translation>
    </message>
    <message>
      <location filename="../../InitGui.py" line="135"/>
      <location filename="../../InitGui.py" line="148"/>
      <source>If OpenSCAD execution fails to load the temporary file, use FreeCAD's OpenSCAD Workbench Preferences to change the transfer mechanism.</source>
      <translation>Калі пры запуске OpenSCAD не атрымаецца загрузіць часовы файл, будуць ужывацца Налады FreeCAD OpenSCAD Workbench, каб змяніць механізм перадачы дадзеных.</translation>
    </message>
    <message>
      <location filename="../../InitGui.py" line="143"/>
      <source>It looks like you may be using a sandboxed version of FreeCAD.</source>
      <translation>Падобна на тое, што вы, магчыма, ужываеце ізаляваную версію FreeCAD.</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="92"/>
      <source>Unable to explode %s</source>
      <translation>Немагчыма раз'яднаць %s</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="139"/>
      <source>Convert Edges to Faces</source>
      <translation>Пераўтварыць рэбры ў грані</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="301"/>
      <source>Please select 3 objects first</source>
      <translation>Калі ласка, спачатку абярыце 3 аб'екты</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="334"/>
      <location filename="../../OpenSCADCommands.py" line="365"/>
      <source>Add</source>
      <translation>Дадаць</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="369"/>
      <source>Clear</source>
      <translation>Ачысціць</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="366"/>
      <source>Load</source>
      <translation>Загрузіць</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="367"/>
      <source>Save</source>
      <translation>Захаваць</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="335"/>
      <location filename="../../OpenSCADCommands.py" line="368"/>
      <source>Refresh</source>
      <translation>Абнавіць</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="336"/>
      <source>Clear code</source>
      <translation>Ачысціць код</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="337"/>
      <source>Open...</source>
      <translation>Адчыніць...</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="338"/>
      <source>Save...</source>
      <translation>Захаваць...</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="339"/>
      <location filename="../../OpenSCADCommands.py" line="370"/>
      <source>as Mesh</source>
      <translation>як Паліганальная сетка</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="352"/>
      <location filename="../../OpenSCADCommands.py" line="371"/>
      <source>Add OpenSCAD Element</source>
      <translation>Дадаць элемент OpenSCAD</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="428"/>
      <source>Open file</source>
      <translation>Адчыніць файл</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="430"/>
      <location filename="../../OpenSCADCommands.py" line="444"/>
      <source>OpenSCAD Files</source>
      <translation>Файлы OpenSCAD</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="442"/>
      <source>Save file</source>
      <translation>Захаваць файл</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="456"/>
      <location filename="../../OpenSCADCommands.py" line="485"/>
      <source>Perform</source>
      <translation>Выканаць</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="482"/>
      <location filename="../../OpenSCADCommands.py" line="486"/>
      <source>Mesh Boolean</source>
      <translation>Лагічная аперацыя з паліганальнай сеткай</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="487"/>
      <source>Minkowski sum</source>
      <translation>Сума Мінкоўскага</translation>
    </message>
    <message>
      <location filename="../../OpenSCADUtils.py" line="654"/>
      <source>OpenSCAD file contains both 2D and 3D shapes. That is not supported in this importer, all shapes must have the same dimensionality.</source>
      <translation>Файл OpenSCAD змяшчае як двухмерныя, так і трохмерныя фігуры. У гэтым сродку імпартавання такое не падтрымліваецца, усе формы павінны мець аднолькавую памернасць.</translation>
    </message>
    <message>
      <location filename="../../OpenSCADUtils.py" line="665"/>
      <source>Error: either all shapes must be 2D or all shapes must be 3D</source>
      <translation>Памылка: альбо ўсе фігуры павінны быць дзвюхмернымі, альбо ўсе фігуры павінны быць трохмернымі</translation>
    </message>
    <message>
      <location filename="../../importCSG.py" line="549"/>
      <location filename="../../importCSG.py" line="1434"/>
      <source>Unsupported Function</source>
      <translation>Функцыя не падтрымліваецца</translation>
    </message>
    <message>
      <location filename="../../importCSG.py" line="549"/>
      <location filename="../../importCSG.py" line="1434"/>
      <source>Press OK</source>
      <translation>Націсніце ОК</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_ExplodeGroup</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="100"/>
      <source>Explode Group</source>
      <translation>Разбіць суполку</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="103"/>
      <source>Remove fusion, apply placement to children, and color randomly</source>
      <translation>Выдаліць зліццё, ужыць размяшчэнне па даччыным элементам, і пафарбаваць выпадковым чынам</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_ColorCodeShape</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="116"/>
      <source>Color Shapes</source>
      <translation>Колеры фігур</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="119"/>
      <source>Color Shapes by validity and type</source>
      <translation>Колеру фігур па крытэрыю важнасці і тыпу</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_Edgestofaces</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="136"/>
      <source>Convert Edges To Faces</source>
      <translation>Пераўтварыць рэбры ў грані</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_RefineShapeFeature</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="156"/>
      <source>Refine Shape Feature</source>
      <translation>Функцыя ўдасканалення фігур</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="159"/>
      <source>Create Refine Shape Feature</source>
      <translation>Стварыць функцыю ўдасканалення фігур</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_MirrorMeshFeature</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="186"/>
      <source>Mirror Mesh Feature...</source>
      <translation>Функцыя сіметрычнага пераўтварэння паліганальнай сеткі...</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="189"/>
      <source>Create Mirror Mesh Feature</source>
      <translation>Стварыць функцыю сіметрычнага пераўтварэння паліганальнай сеткі</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_ScaleMeshFeature</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="215"/>
      <source>Scale Mesh Feature...</source>
      <translation>Функцыя маштабу паліганальнай сеткі...</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="219"/>
      <source>Create Scale Mesh Feature</source>
      <translation>Стварыць функцыю маштабу паліганальнай сеткі</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_ResizeMeshFeature</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="245"/>
      <source>Resize Mesh Feature...</source>
      <translation>Функцыя змены памеру паліганальнай сеткі...</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="249"/>
      <source>Create Resize Mesh Feature</source>
      <translation>Стварыць функцыю змены памеру паліганальнай сеткі</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_IncreaseToleranceFeature</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="266"/>
      <source>Increase Tolerance Feature</source>
      <translation>Функцыя павелічэння дакладнасці</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="269"/>
      <source>Create Feature that allows increasing the tolerance</source>
      <translation>Стварыць функцыю, які дазваляе павялічыць дакладнасць</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_ExpandPlacements</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="283"/>
      <source>Expand Placements</source>
      <translation>Пашырыць месца размяшчэнне</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="286"/>
      <source>Expand all placements downwards in the Tree view</source>
      <translation>Пашырыць усе месцы размяшчэння ўнізе па дрэву прагляда</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_ReplaceObject</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="304"/>
      <source>Replace Object</source>
      <translation>Замяніць аб'ект</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="307"/>
      <source>Replace an object in the Tree view. Please select old, new, and parent object</source>
      <translation>Замяніць аб'ект у дрэве прагляду. Калі ласка, абярыце стары, новы і бацькоўскі аб'ект</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_RemoveSubtree</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="317"/>
      <source>Remove Objects and their Children</source>
      <translation>Выдаліць аб'екты і іх даччыныя элементы</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="320"/>
      <source>Removes the selected objects and all children that are not referenced from other objects</source>
      <translation>Выдаліць абраныя аб'екты і ўсе даччыныя элементы, на якія адсутнічаюць спасылкі з іншых аб'ектаў</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_AddOpenSCADElement</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="530"/>
      <source>Add OpenSCAD Element...</source>
      <translation>Дадаць элемент OpenSCAD...</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="534"/>
      <source>Add an OpenSCAD element by entering OpenSCAD code and executing the OpenSCAD binary</source>
      <translation>Дадаць элемент OpenSCAD, увесці код OpenSCAD, і выканаць двайковы файл OpenSCAD</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_MeshBoolean</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="545"/>
      <source>Mesh Boolean...</source>
      <translation>Лагічная аперацыя з паліганальнай сеткай...</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="549"/>
      <source>Export objects as meshes and use OpenSCAD to perform a boolean operation</source>
      <translation>Экспартаваць аб'екты ў выглядзе паліганальных сетак і ўжыць OpenSCAD, каб выканаць лагічную аперацыю</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_Hull</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="566"/>
      <source>Hull</source>
      <translation>Корпус</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="569"/>
      <source>Use OpenSCAD to create a hull</source>
      <translation>Ужываць OpenSCAD каб стварыць корпус</translation>
    </message>
  </context>
  <context>
    <name>Workbench</name>
    <message>
      <location filename="../../InitGui.py" line="152"/>
      <source>OpenSCAD Tools</source>
      <translation>Інструменты OpenSCAD</translation>
    </message>
    <message>
      <location filename="../../InitGui.py" line="156"/>
      <source>Frequently-used Part WB tools</source>
      <translation>Часта ўжываемыя інструменты варштата для апрацоўкі дэталяў</translation>
    </message>
  </context>
  <context>
    <name>OpenSCAD_Minkowski</name>
    <message>
      <location filename="../../OpenSCADCommands.py" line="586"/>
      <source>Minkowski sum</source>
      <translation>Сума Мінкоўскага</translation>
    </message>
    <message>
      <location filename="../../OpenSCADCommands.py" line="589"/>
      <source>Use OpenSCAD to create a Minkowski sum</source>
      <translation>Ужываць OpenSCAD каб стварыць суму Мінкоўскага</translation>
    </message>
  </context>
</TS>
