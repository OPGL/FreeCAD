<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="be" sourcelanguage="en">
  <context>
    <name>UnitsApi</name>
    <message>
      <location filename="../../UnitsApi.cpp" line="58"/>
      <source>Standard (mm, kg, s, °)</source>
      <translation>Стандартная (мм, кг, с, °)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="60"/>
      <source>MKS (m, kg, s, °)</source>
      <translation>Сістэма МКС (м, кг, с, °)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="62"/>
      <source>US customary (in, lb)</source>
      <translation>Звычайная Злучаных Штатаў (цалі, фунты)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="64"/>
      <source>Imperial decimal (in, lb)</source>
      <translation>Брытанская сістэма (цалі, фунты)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="66"/>
      <source>Building Euro (cm, m², m³)</source>
      <translation>Еўрапейская будаўнічая (см, м², м³)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="68"/>
      <source>Building US (ft-in, sqft, cft)</source>
      <translation>Будаўнічая Злучаных Штатаў (футы-цалі, кв. футы, куб. футы)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="70"/>
      <source>Metric small parts &amp; CNC (mm, mm/min)</source>
      <translation>Малыя метрычныя дэталі і CNC (мм, мм/хв)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="72"/>
      <source>Imperial for Civil Eng (ft, ft/s)</source>
      <translation>Брытанская для грамадскіх інжынераў (футы, футы/с)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="74"/>
      <source>FEM (mm, N, s)</source>
      <translation>МКЭ (мм, Н, с)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="76"/>
      <source>Meter decimal (m, m², m³)</source>
      <translation>Метрычная сістэма (м, м², м³)</translation>
    </message>
    <message>
      <location filename="../../UnitsApi.cpp" line="78"/>
      <source>Unknown schema</source>
      <translation>Невядомая схема</translation>
    </message>
  </context>
</TS>
