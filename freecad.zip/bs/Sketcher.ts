<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="bs" sourcelanguage="en">
  <context>
    <name>CmdSketcherBSplineComb</name>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="127"/>
      <source>Show/hide B-spline curvature comb</source>
      <translation type="unfinished">Show/hide B-spline curvature comb</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="129"/>
      <source>Switches between showing and hiding the curvature comb for all B-splines</source>
      <translation type="unfinished">Switches between showing and hiding the curvature comb for all B-splines</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherBSplineDegree</name>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="68"/>
      <source>Show/hide B-spline degree</source>
      <translation type="unfinished">Show/hide B-spline degree</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="69"/>
      <source>Switches between showing and hiding the degree for all B-splines</source>
      <translation type="unfinished">Switches between showing and hiding the degree for all B-splines</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherBSplineKnotMultiplicity</name>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="157"/>
      <source>Show/hide B-spline knot multiplicity</source>
      <translation type="unfinished">Show/hide B-spline knot multiplicity</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="159"/>
      <source>Switches between showing and hiding the knot multiplicity for all B-splines</source>
      <translation type="unfinished">Switches between showing and hiding the knot multiplicity for all B-splines</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherBSplinePoleWeight</name>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="187"/>
      <source>Show/hide B-spline control point weight</source>
      <translation type="unfinished">Show/hide B-spline control point weight</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="188"/>
      <source>Switches between showing and hiding the control point weight for all B-splines</source>
      <translation type="unfinished">Switches between showing and hiding the control point weight for all B-splines</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherBSplinePolygon</name>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="97"/>
      <source>Show/hide B-spline control polygon</source>
      <translation type="unfinished">Show/hide B-spline control polygon</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="99"/>
      <source>Switches between showing and hiding the control polygons for all B-splines</source>
      <translation type="unfinished">Switches between showing and hiding the control polygons for all B-splines</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCarbonCopy</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1578"/>
      <source>Create carbon copy</source>
      <translation type="unfinished">Create carbon copy</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1579"/>
      <source>Copy the geometry of another sketch</source>
      <translation type="unfinished">Copy the geometry of another sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherClone</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1521"/>
      <source>Clone</source>
      <translation type="unfinished">Clone</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1523"/>
      <source>Creates a clone of the geometry taking as reference the last selected point</source>
      <translation type="unfinished">Creates a clone of the geometry taking as reference the last selected point</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompBSplineShowHideGeometryInformation</name>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="218"/>
      <source>Show/hide B-spline information layer</source>
      <translation type="unfinished">Show/hide B-spline information layer</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="300"/>
      <source>Show/hide B-spline degree</source>
      <translation type="unfinished">Show/hide B-spline degree</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="309"/>
      <source>Show/hide B-spline control polygon</source>
      <translation type="unfinished">Show/hide B-spline control polygon</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="318"/>
      <source>Show/hide B-spline curvature comb</source>
      <translation type="unfinished">Show/hide B-spline curvature comb</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="327"/>
      <source>Show/hide B-spline knot multiplicity</source>
      <translation type="unfinished">Show/hide B-spline knot multiplicity</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="337"/>
      <source>Show/hide B-spline control point weight</source>
      <translation type="unfinished">Show/hide B-spline control point weight</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompConstrainRadDia</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="8502"/>
      <source>Constrain arc or circle</source>
      <translation type="unfinished">Constrain arc or circle</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="8503"/>
      <source>Constrain an arc or a circle</source>
      <translation type="unfinished">Constrain an arc or a circle</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="8613"/>
      <source>Constrain radius</source>
      <translation type="unfinished">Constrain radius</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="8619"/>
      <source>Constrain diameter</source>
      <translation type="unfinished">Constrain diameter</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="8625"/>
      <source>Constrain auto radius/diameter</source>
      <translation type="unfinished">Constrain auto radius/diameter</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompCopy</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1603"/>
      <source>Clone</source>
      <translation type="unfinished">Clone</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1605"/>
      <source>Creates a clone of the geometry taking as reference the last selected point</source>
      <translation type="unfinished">Creates a clone of the geometry taking as reference the last selected point</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompCreateArc</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="530"/>
      <source>Create arc</source>
      <translation type="unfinished">Create arc</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="531"/>
      <source>Create an arc in the sketch</source>
      <translation type="unfinished">Create an arc in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompCreateBSpline</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="992"/>
      <source>Create B-spline</source>
      <translation type="unfinished">Create B-spline</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="993"/>
      <source>Create a B-spline in the sketch</source>
      <translation type="unfinished">Create a B-spline in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompCreateConic</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="784"/>
      <source>Create conic</source>
      <translation type="unfinished">Create conic</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="785"/>
      <source>Create a conic in the sketch</source>
      <translation type="unfinished">Create a conic in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompCreateRectangles</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="333"/>
      <source>Create rectangle</source>
      <translation type="unfinished">Create rectangle</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="334"/>
      <source>Creates a rectangle in the sketch</source>
      <translation type="unfinished">Creates a rectangle in the sketch</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="431"/>
      <source>Rectangle</source>
      <translation type="unfinished">Rectangle</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="437"/>
      <source>Centered rectangle</source>
      <translation type="unfinished">Centered rectangle</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="443"/>
      <source>Rounded rectangle</source>
      <translation type="unfinished">Rounded rectangle</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompCreateRegularPolygon</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1937"/>
      <source>Create regular polygon</source>
      <translation type="unfinished">Create regular polygon</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1938"/>
      <source>Create a regular polygon in the sketcher</source>
      <translation type="unfinished">Create a regular polygon in the sketcher</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="2063"/>
      <source>Triangle</source>
      <translation type="unfinished">Triangle</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="2071"/>
      <source>Square</source>
      <translation type="unfinished">Square</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="2078"/>
      <source>Pentagon</source>
      <translation type="unfinished">Pentagon</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="2086"/>
      <source>Hexagon</source>
      <translation type="unfinished">Hexagon</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="2094"/>
      <source>Heptagon</source>
      <translation type="unfinished">Heptagon</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="2102"/>
      <source>Octagon</source>
      <translation type="unfinished">Octagon</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="2111"/>
      <source>Regular polygon</source>
      <translation type="unfinished">Regular polygon</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompModifyKnotMultiplicity</name>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="636"/>
      <source>Modify knot multiplicity</source>
      <translation type="unfinished">Modify knot multiplicity</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="637"/>
      <source>Modifies the multiplicity of the selected knot of a B-spline</source>
      <translation type="unfinished">Modifies the multiplicity of the selected knot of a B-spline</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="702"/>
      <source>Increase knot multiplicity</source>
      <translation type="unfinished">Increase knot multiplicity</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="711"/>
      <source>Decrease knot multiplicity</source>
      <translation type="unfinished">Decrease knot multiplicity</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainAngle</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="8662"/>
      <source>Constrain angle</source>
      <translation type="unfinished">Constrain angle</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="8663"/>
      <source>Fix the angle of a line or the angle between two lines</source>
      <translation type="unfinished">Fix the angle of a line or the angle between two lines</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainBlock</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3575"/>
      <source>Constrain block</source>
      <translation type="unfinished">Constrain block</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3576"/>
      <source>Block the selected edge from moving</source>
      <translation type="unfinished">Block the selected edge from moving</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainCoincident</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4291"/>
      <source>Constrain coincident</source>
      <translation type="unfinished">Constrain coincident</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4292"/>
      <source>Create a coincident constraint between points, or a concentric constraint between circles, arcs, and ellipses</source>
      <translation type="unfinished">Create a coincident constraint between points, or a concentric constraint between circles, arcs, and ellipses</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainDiameter</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="7815"/>
      <source>Constrain diameter</source>
      <translation type="unfinished">Constrain diameter</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="7816"/>
      <source>Fix the diameter of a circle or an arc</source>
      <translation type="unfinished">Fix the diameter of a circle or an arc</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainDistance</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4395"/>
      <source>Constrain distance</source>
      <translation type="unfinished">Constrain distance</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4396"/>
      <source>Fix a length of a line or the distance between a line and a vertex or between two circles</source>
      <translation type="unfinished">Fix a length of a line or the distance between a line and a vertex or between two circles</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainDistanceX</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5047"/>
      <source>Constrain horizontal distance</source>
      <translation type="unfinished">Constrain horizontal distance</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5048"/>
      <source>Fix the horizontal distance between two points or line ends</source>
      <translation type="unfinished">Fix the horizontal distance between two points or line ends</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainDistanceY</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5351"/>
      <source>Constrain vertical distance</source>
      <translation type="unfinished">Constrain vertical distance</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5352"/>
      <source>Fix the vertical distance between two points or line ends</source>
      <translation type="unfinished">Fix the vertical distance between two points or line ends</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainEqual</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9115"/>
      <source>Constrain equal</source>
      <translation type="unfinished">Constrain equal</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9117"/>
      <source>Create an equality constraint between two lines or between circles and arcs</source>
      <translation type="unfinished">Create an equality constraint between two lines or between circles and arcs</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainHorizontal</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3197"/>
      <source>Constrain horizontal</source>
      <translation type="unfinished">Constrain horizontal</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3198"/>
      <source>Create a horizontal constraint on the selected item</source>
      <translation type="unfinished">Create a horizontal constraint on the selected item</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainLock</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3288"/>
      <source>Constrain lock</source>
      <translation type="unfinished">Constrain lock</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3289"/>
      <source>Create both a horizontal and a vertical distance constraint
on the selected vertex</source>
      <translation type="unfinished">Create both a horizontal and a vertical distance constraint
on the selected vertex</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainParallel</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5649"/>
      <source>Constrain parallel</source>
      <translation type="unfinished">Constrain parallel</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5650"/>
      <source>Create a parallel constraint between two lines</source>
      <translation type="unfinished">Create a parallel constraint between two lines</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainPerpendicular</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5812"/>
      <source>Constrain perpendicular</source>
      <translation type="unfinished">Constrain perpendicular</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5813"/>
      <source>Create a perpendicular constraint between two lines</source>
      <translation type="unfinished">Create a perpendicular constraint between two lines</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainPointOnObject</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4343"/>
      <source>Constrain point on object</source>
      <translation type="unfinished">Constrain point on object</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4344"/>
      <source>Fix a point onto an object</source>
      <translation type="unfinished">Fix a point onto an object</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainRadiam</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="8133"/>
      <source>Constrain auto radius/diameter</source>
      <translation type="unfinished">Constrain auto radius/diameter</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="8134"/>
      <source>Fix the diameter if a circle is chosen, or the radius if an arc/spline pole is chosen</source>
      <translation type="unfinished">Fix the diameter if a circle is chosen, or the radius if an arc/spline pole is chosen</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainSnellsLaw</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9714"/>
      <source>Constrain refraction (Snell's law)</source>
      <translation type="unfinished">Constrain refraction (Snell's law)</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9715"/>
      <source>Create a refraction law (Snell's law)constraint between two endpoints of rays
and an edge as an interface.</source>
      <translation type="unfinished">Create a refraction law (Snell's law)constraint between two endpoints of rays
and an edge as an interface.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainSymmetric</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9357"/>
      <source>Constrain symmetric</source>
      <translation type="unfinished">Constrain symmetric</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9358"/>
      <source>Create a symmetry constraint between two points
with respect to a line or a third point</source>
      <translation type="unfinished">Create a symmetry constraint between two points
with respect to a line or a third point</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainVertical</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3242"/>
      <source>Constrain vertical</source>
      <translation type="unfinished">Constrain vertical</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3243"/>
      <source>Create a vertical constraint on the selected item</source>
      <translation type="unfinished">Create a vertical constraint on the selected item</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConvertToNURBS</name>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="115"/>
      <source>Convert geometry to B-spline</source>
      <translation type="unfinished">Convert geometry to B-spline</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="116"/>
      <source>Converts the selected geometry to a B-spline</source>
      <translation type="unfinished">Converts the selected geometry to a B-spline</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCopy</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1470"/>
      <source>Copy</source>
      <translation type="unfinished">Copy</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1471"/>
      <source>Creates a simple copy of the geometry taking as reference the last selected point</source>
      <translation type="unfinished">Creates a simple copy of the geometry taking as reference the last selected point</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreate3PointArc</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="495"/>
      <source>Create arc by 3 points</source>
      <translation type="unfinished">Create arc by 3 points</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="496"/>
      <source>Create an arc by its end points and a point along the arc</source>
      <translation type="unfinished">Create an arc by its end points and a point along the arc</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreate3PointCircle</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1164"/>
      <source>Create circle by 3 points</source>
      <translation type="unfinished">Create circle by 3 points</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1165"/>
      <source>Create a circle by 3 perimeter points</source>
      <translation type="unfinished">Create a circle by 3 perimeter points</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateArc</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="463"/>
      <source>Create arc by center</source>
      <translation type="unfinished">Create arc by center</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="464"/>
      <source>Create an arc by its center and by its end points</source>
      <translation type="unfinished">Create an arc by its center and by its end points</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateArcOfEllipse</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="696"/>
      <source>Create arc of ellipse</source>
      <translation type="unfinished">Create arc of ellipse</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="697"/>
      <source>Create an arc of ellipse in the sketch</source>
      <translation type="unfinished">Create an arc of ellipse in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateArcOfHyperbola</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="725"/>
      <source>Create arc of hyperbola</source>
      <translation type="unfinished">Create arc of hyperbola</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="726"/>
      <source>Create an arc of hyperbola in the sketch</source>
      <translation type="unfinished">Create an arc of hyperbola in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateArcOfParabola</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="753"/>
      <source>Create arc of parabola</source>
      <translation type="unfinished">Create arc of parabola</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="754"/>
      <source>Create an arc of parabola in the sketch</source>
      <translation type="unfinished">Create an arc of parabola in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateBSpline</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="849"/>
      <source>Create B-spline</source>
      <translation type="unfinished">Create B-spline</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="850"/>
      <source>Create a B-spline by control points in the sketch.</source>
      <translation type="unfinished">Create a B-spline by control points in the sketch.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateCircle</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="598"/>
      <source>Create circle by center</source>
      <translation type="unfinished">Create circle by center</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="599"/>
      <source>Create a circle in the sketch</source>
      <translation type="unfinished">Create a circle in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateEllipseBy3Points</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="665"/>
      <source>Create ellipse by 3 points</source>
      <translation type="unfinished">Create ellipse by 3 points</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="666"/>
      <source>Create an ellipse by 3 points in the sketch</source>
      <translation type="unfinished">Create an ellipse by 3 points in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateEllipseByCenter</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="632"/>
      <source>Create ellipse by center</source>
      <translation type="unfinished">Create ellipse by center</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="633"/>
      <source>Create an ellipse by center in the sketch</source>
      <translation type="unfinished">Create an ellipse by center in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateFillet</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1227"/>
      <source>Create fillet</source>
      <translation type="unfinished">Create fillet</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1228"/>
      <source>Create a fillet between two lines or at a coincident point</source>
      <translation type="unfinished">Create a fillet between two lines or at a coincident point</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateHeptagon</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1844"/>
      <source>Create heptagon</source>
      <translation type="unfinished">Create heptagon</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1845"/>
      <source>Create a heptagon in the sketch</source>
      <translation type="unfinished">Create a heptagon in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateHexagon</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1815"/>
      <source>Create hexagon</source>
      <translation type="unfinished">Create hexagon</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1816"/>
      <source>Create a hexagon in the sketch</source>
      <translation type="unfinished">Create a hexagon in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateLine</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="171"/>
      <source>Create line</source>
      <translation type="unfinished">Create line</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="172"/>
      <source>Create a line in the sketch</source>
      <translation type="unfinished">Create a line in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateOblong</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="299"/>
      <source>Create rounded rectangle</source>
      <translation type="unfinished">Create rounded rectangle</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="300"/>
      <source>Create a rounded rectangle in the sketch</source>
      <translation type="unfinished">Create a rounded rectangle in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateOctagon</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1873"/>
      <source>Create octagon</source>
      <translation type="unfinished">Create octagon</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1874"/>
      <source>Create an octagon in the sketch</source>
      <translation type="unfinished">Create an octagon in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreatePentagon</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1785"/>
      <source>Create pentagon</source>
      <translation type="unfinished">Create pentagon</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1786"/>
      <source>Create a pentagon in the sketch</source>
      <translation type="unfinished">Create a pentagon in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreatePeriodicBSpline</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="884"/>
      <source>Create periodic B-spline</source>
      <translation type="unfinished">Create periodic B-spline</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="885"/>
      <source>Create a periodic B-spline by control points in the sketch.</source>
      <translation type="unfinished">Create a periodic B-spline by control points in the sketch.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreatePoint</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1198"/>
      <source>Create point</source>
      <translation type="unfinished">Create point</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1199"/>
      <source>Create a point in the sketch</source>
      <translation type="unfinished">Create a point in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreatePolyline</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="202"/>
      <source>Create polyline</source>
      <translation type="unfinished">Create polyline</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="203"/>
      <source>Create a polyline in the sketch. 'M' Key cycles behaviour</source>
      <translation type="unfinished">Create a polyline in the sketch. 'M' Key cycles behaviour</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateRectangle</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="234"/>
      <source>Create rectangle</source>
      <translation type="unfinished">Create rectangle</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="235"/>
      <source>Create a rectangle in the sketch</source>
      <translation type="unfinished">Create a rectangle in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateRectangleCenter</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="265"/>
      <source>Create centered rectangle</source>
      <translation type="unfinished">Create centered rectangle</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="266"/>
      <source>Create a centered rectangle in the sketch</source>
      <translation type="unfinished">Create a centered rectangle in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateRegularPolygon</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1902"/>
      <source>Create regular polygon</source>
      <translation type="unfinished">Create regular polygon</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1903"/>
      <source>Create a regular polygon in the sketch</source>
      <translation type="unfinished">Create a regular polygon in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateSlot</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1665"/>
      <source>Create slot</source>
      <translation type="unfinished">Create slot</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1666"/>
      <source>Create a slot in the sketch</source>
      <translation type="unfinished">Create a slot in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateSquare</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1756"/>
      <source>Create square</source>
      <translation type="unfinished">Create square</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1757"/>
      <source>Create a square in the sketch</source>
      <translation type="unfinished">Create a square in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateTriangle</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1727"/>
      <source>Create equilateral triangle</source>
      <translation type="unfinished">Create equilateral triangle</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1728"/>
      <source>Create an equilateral triangle in the sketch</source>
      <translation type="unfinished">Create an equilateral triangle in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherDecreaseDegree</name>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="268"/>
      <source>Decrease B-spline degree</source>
      <translation type="unfinished">Decrease B-spline degree</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="269"/>
      <source>Decreases the degree of the B-spline</source>
      <translation type="unfinished">Decreases the degree of the B-spline</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherDecreaseKnotMultiplicity</name>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="498"/>
      <source>Decrease knot multiplicity</source>
      <translation type="unfinished">Decrease knot multiplicity</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="499"/>
      <source>Decreases the multiplicity of the selected knot of a B-spline</source>
      <translation type="unfinished">Decreases the multiplicity of the selected knot of a B-spline</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherDeleteAllConstraints</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2126"/>
      <source>Delete all constraints</source>
      <translation type="unfinished">Delete all constraints</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2127"/>
      <source>Delete all constraints in the sketch</source>
      <translation type="unfinished">Delete all constraints in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherDeleteAllGeometry</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2061"/>
      <source>Delete all geometry</source>
      <translation type="unfinished">Delete all geometry</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2062"/>
      <source>Delete all geometry and constraints in the current sketch, with the exception of external geometry</source>
      <translation type="unfinished">Delete all geometry and constraints in the current sketch, with the exception of external geometry</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherEditSketch</name>
    <message>
      <location filename="../../Command.cpp" line="310"/>
      <source>Edit sketch</source>
      <translation type="unfinished">Edit sketch</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="311"/>
      <source>Edit the selected sketch.</source>
      <translation type="unfinished">Edit the selected sketch.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherExtend</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1353"/>
      <source>Extend edge</source>
      <translation type="unfinished">Extend edge</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1354"/>
      <source>Extend an edge with respect to the picked position</source>
      <translation type="unfinished">Extend an edge with respect to the picked position</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherIncreaseDegree</name>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="191"/>
      <source>Increase B-spline degree</source>
      <translation type="unfinished">Increase B-spline degree</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="192"/>
      <source>Increases the degree of the B-spline</source>
      <translation type="unfinished">Increases the degree of the B-spline</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherIncreaseKnotMultiplicity</name>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="350"/>
      <source>Increase knot multiplicity</source>
      <translation type="unfinished">Increase knot multiplicity</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="351"/>
      <source>Increases the multiplicity of the selected knot of a B-spline</source>
      <translation type="unfinished">Increases the multiplicity of the selected knot of a B-spline</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherInsertKnot</name>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="890"/>
      <source>Insert knot</source>
      <translation type="unfinished">Insert knot</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="891"/>
      <source>Inserts knot at given parameter. If a knot already exists at that parameter, it's multiplicity is increased by one.</source>
      <translation type="unfinished">Inserts knot at given parameter. If a knot already exists at that parameter, it's multiplicity is increased by one.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherJoinCurves</name>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="958"/>
      <source>Join curves</source>
      <translation type="unfinished">Join curves</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="959"/>
      <source>Join two curves at selected end points</source>
      <translation type="unfinished">Join two curves at selected end points</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherLeaveSketch</name>
    <message>
      <location filename="../../Command.cpp" line="341"/>
      <source>Leave sketch</source>
      <translation type="unfinished">Leave sketch</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="342"/>
      <source>Finish editing the active sketch.</source>
      <translation type="unfinished">Finish editing the active sketch.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherMapSketch</name>
    <message>
      <location filename="../../Command.cpp" line="552"/>
      <source>Attach sketch...</source>
      <translation type="unfinished">Attach sketch...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="553"/>
      <source>Set the 'AttachmentSupport' of a sketch.
First select the supporting geometry, for example, a face or an edge of a solid object,
then call this command, then choose the desired sketch.</source>
      <translation type="unfinished">Set the 'AttachmentSupport' of a sketch.
First select the supporting geometry, for example, a face or an edge of a solid object,
then call this command, then choose the desired sketch.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="647"/>
      <source>Some of the selected objects depend on the sketch to be mapped. Circular dependencies are not allowed.</source>
      <translation type="unfinished">Some of the selected objects depend on the sketch to be mapped. Circular dependencies are not allowed.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherMergeSketches</name>
    <message>
      <location filename="../../Command.cpp" line="983"/>
      <source>Merge sketches</source>
      <translation type="unfinished">Merge sketches</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="984"/>
      <source>Create a new sketch from merging two or more selected sketches.</source>
      <translation type="unfinished">Create a new sketch from merging two or more selected sketches.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="999"/>
      <source>Wrong selection</source>
      <translation type="unfinished">Wrong selection</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1000"/>
      <source>Select at least two sketches.</source>
      <translation type="unfinished">Select at least two sketches.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherMirrorSketch</name>
    <message>
      <location filename="../../Command.cpp" line="856"/>
      <source>Mirror sketch</source>
      <translation type="unfinished">Mirror sketch</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="857"/>
      <source>Creates a new mirrored sketch for each selected sketch
by using the X or Y axes, or the origin point,
as mirroring reference.</source>
      <translation type="unfinished">Creates a new mirrored sketch for each selected sketch
by using the X or Y axes, or the origin point,
as mirroring reference.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="874"/>
      <source>Wrong selection</source>
      <translation type="unfinished">Wrong selection</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="875"/>
      <source>Select one or more sketches.</source>
      <translation type="unfinished">Select one or more sketches.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherMove</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1569"/>
      <source>Move</source>
      <translation>Pomjeriti</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1570"/>
      <source>Moves the geometry taking as reference the last selected point</source>
      <translation type="unfinished">Moves the geometry taking as reference the last selected point</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherNewSketch</name>
    <message>
      <location filename="../../Command.cpp" line="155"/>
      <source>Create sketch</source>
      <translation type="unfinished">Create sketch</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="156"/>
      <source>Create a new sketch.</source>
      <translation type="unfinished">Create a new sketch.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherRectangularArray</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1909"/>
      <source>Rectangular array</source>
      <translation type="unfinished">Rectangular array</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1910"/>
      <source>Creates a rectangular array pattern of the geometry taking as reference the last selected point</source>
      <translation type="unfinished">Creates a rectangular array pattern of the geometry taking as reference the last selected point</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherRemoveAxesAlignment</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2193"/>
      <source>Remove axes alignment</source>
      <translation type="unfinished">Remove axes alignment</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2194"/>
      <source>Modifies constraints to remove axes alignment while trying to preserve the constraint relationship of the selection</source>
      <translation type="unfinished">Modifies constraints to remove axes alignment while trying to preserve the constraint relationship of the selection</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherReorientSketch</name>
    <message>
      <location filename="../../Command.cpp" line="415"/>
      <source>Reorient sketch...</source>
      <translation type="unfinished">Reorient sketch...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="416"/>
      <source>Place the selected sketch on one of the global coordinate planes.
This will clear the 'AttachmentSupport' property, if any.</source>
      <translation type="unfinished">Place the selected sketch on one of the global coordinate planes.
This will clear the 'AttachmentSupport' property, if any.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherRestoreInternalAlignmentGeometry</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="980"/>
      <source>Show/hide internal geometry</source>
      <translation type="unfinished">Show/hide internal geometry</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="981"/>
      <source>Show all internal geometry or hide unused internal geometry</source>
      <translation type="unfinished">Show all internal geometry or hide unused internal geometry</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherSelectConflictingConstraints</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="713"/>
      <location filename="../../CommandSketcherTools.cpp" line="714"/>
      <source>Select conflicting constraints</source>
      <translation type="unfinished">Select conflicting constraints</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherSelectConstraints</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="338"/>
      <source>Select associated constraints</source>
      <translation type="unfinished">Select associated constraints</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="340"/>
      <source>Select the constraints associated with the selected geometrical elements</source>
      <translation type="unfinished">Select the constraints associated with the selected geometrical elements</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherSelectElementsAssociatedWithConstraints</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="771"/>
      <source>Select associated geometry</source>
      <translation type="unfinished">Select associated geometry</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="773"/>
      <source>Select the geometrical elements associated with the selected constraints</source>
      <translation type="unfinished">Select the geometrical elements associated with the selected constraints</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherSelectElementsWithDoFs</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="891"/>
      <source>Select under-constrained elements</source>
      <translation type="unfinished">Select under-constrained elements</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="892"/>
      <source>Select geometrical elements where the solver still detects unconstrained degrees of freedom.</source>
      <translation type="unfinished">Select geometrical elements where the solver still detects unconstrained degrees of freedom.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherSelectHorizontalAxis</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="504"/>
      <source>Select horizontal axis</source>
      <translation type="unfinished">Select horizontal axis</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="505"/>
      <source>Select the local horizontal axis of the sketch</source>
      <translation type="unfinished">Select the local horizontal axis of the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherSelectMalformedConstraints</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="602"/>
      <location filename="../../CommandSketcherTools.cpp" line="603"/>
      <source>Select malformed constraints</source>
      <translation type="unfinished">Select malformed constraints</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherSelectOrigin</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="419"/>
      <source>Select origin</source>
      <translation type="unfinished">Select origin</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="420"/>
      <source>Select the local origin point of the sketch</source>
      <translation type="unfinished">Select the local origin point of the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherSelectPartiallyRedundantConstraints</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="657"/>
      <location filename="../../CommandSketcherTools.cpp" line="658"/>
      <source>Select partially redundant constraints</source>
      <translation type="unfinished">Select partially redundant constraints</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherSelectRedundantConstraints</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="544"/>
      <location filename="../../CommandSketcherTools.cpp" line="545"/>
      <source>Select redundant constraints</source>
      <translation type="unfinished">Select redundant constraints</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherSelectVerticalAxis</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="463"/>
      <source>Select vertical axis</source>
      <translation type="unfinished">Select vertical axis</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="464"/>
      <source>Select the local vertical axis of the sketch</source>
      <translation type="unfinished">Select the local vertical axis of the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherSplit</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1384"/>
      <source>Split edge</source>
      <translation type="unfinished">Split edge</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1385"/>
      <source>Splits an edge into two while preserving constraints</source>
      <translation type="unfinished">Splits an edge into two while preserving constraints</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherStopOperation</name>
    <message>
      <location filename="../../Command.cpp" line="379"/>
      <source>Stop operation</source>
      <translation type="unfinished">Stop operation</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="380"/>
      <source>When in edit mode, stop the active operation (drawing, constraining, etc.).</source>
      <translation type="unfinished">When in edit mode, stop the active operation (drawing, constraining, etc.).</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherSwitchVirtualSpace</name>
    <message>
      <location filename="../../CommandSketcherVirtualSpace.cpp" line="97"/>
      <source>Switch virtual space</source>
      <translation type="unfinished">Switch virtual space</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherVirtualSpace.cpp" line="99"/>
      <source>Switches the selected constraints or the view to the other virtual space</source>
      <translation type="unfinished">Switches the selected constraints or the view to the other virtual space</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherSymmetry</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1095"/>
      <source>Symmetry</source>
      <translation type="unfinished">Symmetry</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1097"/>
      <source>Creates symmetric of selected geometry. After starting the tool select the reference line or point.</source>
      <translation type="unfinished">Creates symmetric of selected geometry. After starting the tool select the reference line or point.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherToggleActiveConstraint</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="10124"/>
      <source>Activate/deactivate constraint</source>
      <translation type="unfinished">Activate/deactivate constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="10125"/>
      <source>Activates or deactivates the selected constraints</source>
      <translation type="unfinished">Activates or deactivates the selected constraints</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherToggleConstruction</name>
    <message>
      <location filename="../../CommandAlterGeometry.cpp" line="73"/>
      <source>Toggle construction geometry</source>
      <translation type="unfinished">Toggle construction geometry</translation>
    </message>
    <message>
      <location filename="../../CommandAlterGeometry.cpp" line="74"/>
      <source>Toggles the toolbar or selected geometry to/from construction mode</source>
      <translation type="unfinished">Toggles the toolbar or selected geometry to/from construction mode</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherToggleDrivingConstraint</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9967"/>
      <source>Toggle driving/reference constraint</source>
      <translation type="unfinished">Toggle driving/reference constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9968"/>
      <source>Set the toolbar, or the selected constraints,
into driving or reference mode</source>
      <translation type="unfinished">Set the toolbar, or the selected constraints,
into driving or reference mode</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherTrimming</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1322"/>
      <source>Trim edge</source>
      <translation type="unfinished">Trim edge</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1323"/>
      <source>Trim an edge with respect to the picked position</source>
      <translation type="unfinished">Trim an edge with respect to the picked position</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherValidateSketch</name>
    <message>
      <location filename="../../Command.cpp" line="816"/>
      <source>Validate sketch...</source>
      <translation type="unfinished">Validate sketch...</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="817"/>
      <source>Validates a sketch by looking at missing coincidences,
invalid constraints, degenerated geometry, etc.</source>
      <translation type="unfinished">Validates a sketch by looking at missing coincidences,
invalid constraints, degenerated geometry, etc.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="833"/>
      <source>Wrong selection</source>
      <translation type="unfinished">Wrong selection</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="834"/>
      <source>Select only one sketch.</source>
      <translation type="unfinished">Select only one sketch.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherViewSection</name>
    <message>
      <location filename="../../Command.cpp" line="1075"/>
      <source>View section</source>
      <translation type="unfinished">View section</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1076"/>
      <source>When in edit mode, switch between section view and full view.</source>
      <translation type="unfinished">When in edit mode, switch between section view and full view.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherViewSketch</name>
    <message>
      <location filename="../../Command.cpp" line="781"/>
      <source>View sketch</source>
      <translation type="unfinished">View sketch</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="782"/>
      <source>When in edit mode, set the camera orientation perpendicular to the sketch plane.</source>
      <translation type="unfinished">When in edit mode, set the camera orientation perpendicular to the sketch plane.</translation>
    </message>
  </context>
  <context>
    <name>Command</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3376"/>
      <source>Add 'Lock' constraint</source>
      <translation type="unfinished">Add 'Lock' constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3430"/>
      <source>Add relative 'Lock' constraint</source>
      <translation type="unfinished">Add relative 'Lock' constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3495"/>
      <source>Add fixed constraint</source>
      <translation type="unfinished">Add fixed constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3666"/>
      <source>Add 'Block' constraint</source>
      <translation type="unfinished">Add 'Block' constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3715"/>
      <source>Add block constraint</source>
      <translation type="unfinished">Add block constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4057"/>
      <location filename="../../CommandConstraints.cpp" line="4246"/>
      <source>Add coincident constraint</source>
      <translation type="unfinished">Add coincident constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4478"/>
      <location filename="../../CommandConstraints.cpp" line="4802"/>
      <source>Add distance from horizontal axis constraint</source>
      <translation type="unfinished">Add distance from horizontal axis constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4490"/>
      <location filename="../../CommandConstraints.cpp" line="4816"/>
      <source>Add distance from vertical axis constraint</source>
      <translation type="unfinished">Add distance from vertical axis constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4502"/>
      <location filename="../../CommandConstraints.cpp" line="4829"/>
      <source>Add point to point distance constraint</source>
      <translation type="unfinished">Add point to point distance constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1855"/>
      <location filename="../../CommandConstraints.cpp" line="4545"/>
      <location filename="../../CommandConstraints.cpp" line="4917"/>
      <source>Add point to line Distance constraint</source>
      <translation type="unfinished">Add point to line Distance constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4626"/>
      <location filename="../../CommandConstraints.cpp" line="4972"/>
      <source>Add circle to circle distance constraint</source>
      <translation type="unfinished">Add circle to circle distance constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4669"/>
      <source>Add circle to line distance constraint</source>
      <translation type="unfinished">Add circle to line distance constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1953"/>
      <location filename="../../CommandConstraints.cpp" line="1976"/>
      <location filename="../../CommandConstraints.cpp" line="2044"/>
      <location filename="../../CommandConstraints.cpp" line="2128"/>
      <location filename="../../CommandConstraints.cpp" line="4717"/>
      <location filename="../../CommandConstraints.cpp" line="4744"/>
      <location filename="../../CommandConstraints.cpp" line="4866"/>
      <source>Add length constraint</source>
      <translation type="unfinished">Add length constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1414"/>
      <location filename="../../CommandConstraints.cpp" line="1603"/>
      <location filename="../../CommandConstraints.cpp" line="2761"/>
      <source>Dimension</source>
      <translation type="unfinished">Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1824"/>
      <source>Add lock constraint</source>
      <translation type="unfinished">Add lock constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1820"/>
      <source>Add 'Distance to origin' constraint</source>
      <translation type="unfinished">Add 'Distance to origin' constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1836"/>
      <location filename="../../CommandConstraints.cpp" line="2450"/>
      <location filename="../../CommandConstraints.cpp" line="2679"/>
      <source>Add Distance constraint</source>
      <translation type="unfinished">Add Distance constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1841"/>
      <location filename="../../CommandConstraints.cpp" line="1870"/>
      <location filename="../../CommandConstraints.cpp" line="1904"/>
      <source>Add 'Horizontal' constraints</source>
      <translation type="unfinished">Add 'Horizontal' constraints</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1845"/>
      <location filename="../../CommandConstraints.cpp" line="1877"/>
      <location filename="../../CommandConstraints.cpp" line="1911"/>
      <source>Add 'Vertical' constraints</source>
      <translation type="unfinished">Add 'Vertical' constraints</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1860"/>
      <location filename="../../CommandConstraints.cpp" line="1923"/>
      <source>Add Symmetry constraint</source>
      <translation type="unfinished">Add Symmetry constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1883"/>
      <location filename="../../CommandConstraints.cpp" line="2055"/>
      <source>Add Symmetry constraints</source>
      <translation type="unfinished">Add Symmetry constraints</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1928"/>
      <location filename="../../CommandConstraints.cpp" line="1940"/>
      <source>Add Distance constraints</source>
      <translation type="unfinished">Add Distance constraints</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1986"/>
      <source>Add Horizontal constraint</source>
      <translation type="unfinished">Add Horizontal constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1991"/>
      <source>Add Vertical constraint</source>
      <translation type="unfinished">Add Vertical constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1995"/>
      <source>Add Block constraint</source>
      <translation type="unfinished">Add Block constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2010"/>
      <source>Add Angle constraint</source>
      <translation type="unfinished">Add Angle constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2020"/>
      <location filename="../../CommandConstraints.cpp" line="2143"/>
      <location filename="../../CommandConstraints.cpp" line="2153"/>
      <location filename="../../CommandConstraints.cpp" line="2191"/>
      <source>Add Equality constraint</source>
      <translation type="unfinished">Add Equality constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2031"/>
      <source>Add Equality constraints</source>
      <translation type="unfinished">Add Equality constraints</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2088"/>
      <location filename="../../CommandConstraints.cpp" line="2092"/>
      <location filename="../../CommandConstraints.cpp" line="2099"/>
      <location filename="../../CommandConstraints.cpp" line="2104"/>
      <source>Add Radius constraint</source>
      <translation type="unfinished">Add Radius constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="10168"/>
      <source>Activate/Deactivate constraints</source>
      <translation type="unfinished">Activate/Deactivate constraints</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2079"/>
      <location filename="../../CommandConstraints.cpp" line="2112"/>
      <source>Add arc angle constraint</source>
      <translation type="unfinished">Add arc angle constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2133"/>
      <source>Add concentric and length constraint</source>
      <translation type="unfinished">Add concentric and length constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2657"/>
      <source>Add DistanceX constraint</source>
      <translation type="unfinished">Add DistanceX constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2668"/>
      <source>Add DistanceY constraint</source>
      <translation type="unfinished">Add DistanceY constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4575"/>
      <source>Add point to circle Distance constraint</source>
      <translation type="unfinished">Add point to circle Distance constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3975"/>
      <location filename="../../CommandConstraints.cpp" line="4160"/>
      <source>Add point on object constraint</source>
      <translation type="unfinished">Add point on object constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2084"/>
      <location filename="../../CommandConstraints.cpp" line="2116"/>
      <source>Add arc length constraint</source>
      <translation type="unfinished">Add arc length constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5160"/>
      <location filename="../../CommandConstraints.cpp" line="5287"/>
      <source>Add point to point horizontal distance constraint</source>
      <translation type="unfinished">Add point to point horizontal distance constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5201"/>
      <source>Add fixed x-coordinate constraint</source>
      <translation type="unfinished">Add fixed x-coordinate constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5462"/>
      <location filename="../../CommandConstraints.cpp" line="5586"/>
      <source>Add point to point vertical distance constraint</source>
      <translation type="unfinished">Add point to point vertical distance constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5500"/>
      <source>Add fixed y-coordinate constraint</source>
      <translation type="unfinished">Add fixed y-coordinate constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5734"/>
      <location filename="../../CommandConstraints.cpp" line="5778"/>
      <source>Add parallel constraint</source>
      <translation type="unfinished">Add parallel constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5918"/>
      <location filename="../../CommandConstraints.cpp" line="6017"/>
      <location filename="../../CommandConstraints.cpp" line="6180"/>
      <location filename="../../CommandConstraints.cpp" line="6230"/>
      <location filename="../../CommandConstraints.cpp" line="6381"/>
      <location filename="../../CommandConstraints.cpp" line="6430"/>
      <location filename="../../CommandConstraints.cpp" line="6486"/>
      <source>Add perpendicular constraint</source>
      <translation type="unfinished">Add perpendicular constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="6056"/>
      <source>Add perpendicularity constraint</source>
      <translation type="unfinished">Add perpendicularity constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="6623"/>
      <source>Swap coincident+tangency with ptp tangency</source>
      <translation type="unfinished">Swap coincident+tangency with ptp tangency</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="6753"/>
      <location filename="../../CommandConstraints.cpp" line="6855"/>
      <location filename="../../CommandConstraints.cpp" line="6904"/>
      <location filename="../../CommandConstraints.cpp" line="7091"/>
      <location filename="../../CommandConstraints.cpp" line="7259"/>
      <location filename="../../CommandConstraints.cpp" line="7329"/>
      <location filename="../../CommandConstraints.cpp" line="7362"/>
      <source>Add tangent constraint</source>
      <translation type="unfinished">Add tangent constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="6950"/>
      <location filename="../../CommandConstraints.cpp" line="6961"/>
      <location filename="../../CommandConstraints.cpp" line="6973"/>
      <location filename="../../CommandConstraints.cpp" line="6997"/>
      <location filename="../../CommandConstraints.cpp" line="7010"/>
      <location filename="../../CommandConstraints.cpp" line="7034"/>
      <location filename="../../CommandConstraints.cpp" line="7046"/>
      <location filename="../../CommandConstraints.cpp" line="7071"/>
      <location filename="../../CommandConstraints.cpp" line="7164"/>
      <location filename="../../CommandConstraints.cpp" line="7175"/>
      <location filename="../../CommandConstraints.cpp" line="7187"/>
      <location filename="../../CommandConstraints.cpp" line="7211"/>
      <location filename="../../CommandConstraints.cpp" line="7223"/>
      <location filename="../../CommandConstraints.cpp" line="7247"/>
      <source>Add tangent constraint point</source>
      <translation type="unfinished">Add tangent constraint point</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="7582"/>
      <location filename="../../CommandConstraints.cpp" line="7626"/>
      <location filename="../../CommandConstraints.cpp" line="7655"/>
      <location filename="../../CommandConstraints.cpp" line="7732"/>
      <source>Add radius constraint</source>
      <translation type="unfinished">Add radius constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="7933"/>
      <location filename="../../CommandConstraints.cpp" line="7965"/>
      <location filename="../../CommandConstraints.cpp" line="7986"/>
      <location filename="../../CommandConstraints.cpp" line="8062"/>
      <source>Add diameter constraint</source>
      <translation type="unfinished">Add diameter constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="8259"/>
      <location filename="../../CommandConstraints.cpp" line="8307"/>
      <location filename="../../CommandConstraints.cpp" line="8342"/>
      <location filename="../../CommandConstraints.cpp" line="8431"/>
      <source>Add radiam constraint</source>
      <translation type="unfinished">Add radiam constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="263"/>
      <location filename="../../CommandConstraints.cpp" line="8764"/>
      <location filename="../../CommandConstraints.cpp" line="8880"/>
      <location filename="../../CommandConstraints.cpp" line="8906"/>
      <location filename="../../CommandConstraints.cpp" line="9001"/>
      <source>Add angle constraint</source>
      <translation type="unfinished">Add angle constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="6646"/>
      <source>Swap point on object and tangency with point to curve tangency</source>
      <translation type="unfinished">Swap point on object and tangency with point to curve tangency</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9263"/>
      <location filename="../../CommandConstraints.cpp" line="9318"/>
      <source>Add equality constraint</source>
      <translation type="unfinished">Add equality constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9452"/>
      <location filename="../../CommandConstraints.cpp" line="9511"/>
      <location filename="../../CommandConstraints.cpp" line="9532"/>
      <location filename="../../CommandConstraints.cpp" line="9639"/>
      <location filename="../../CommandConstraints.cpp" line="9685"/>
      <source>Add symmetric constraint</source>
      <translation type="unfinished">Add symmetric constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9849"/>
      <source>Add Snell's law constraint</source>
      <translation type="unfinished">Add Snell's law constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="10080"/>
      <source>Toggle constraint to driving/reference</source>
      <translation type="unfinished">Toggle constraint to driving/reference</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="231"/>
      <source>Create a new sketch on a face</source>
      <translation type="unfinished">Create a new sketch on a face</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="272"/>
      <source>Create a new sketch</source>
      <translation type="unfinished">Create a new sketch</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="526"/>
      <source>Reorient sketch</source>
      <translation type="unfinished">Reorient sketch</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="737"/>
      <source>Attach sketch</source>
      <translation type="unfinished">Attach sketch</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="745"/>
      <source>Detach sketch</source>
      <translation type="unfinished">Detach sketch</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="890"/>
      <source>Create a mirrored sketch for each selected sketch</source>
      <translation type="unfinished">Create a mirrored sketch for each selected sketch</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1009"/>
      <source>Merge sketches</source>
      <translation type="unfinished">Merge sketches</translation>
    </message>
    <message>
      <location filename="../../CommandAlterGeometry.cpp" line="184"/>
      <source>Toggle draft from/to draft</source>
      <translation type="unfinished">Toggle draft from/to draft</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerLine.h" line="126"/>
      <source>Add sketch line</source>
      <translation type="unfinished">Add sketch line</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerRectangle.h" line="342"/>
      <source>Add sketch box</source>
      <translation type="unfinished">Add sketch box</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerArc.h" line="232"/>
      <source>Add sketch arc</source>
      <translation type="unfinished">Add sketch arc</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerCircle.h" line="158"/>
      <source>Add sketch circle</source>
      <translation type="unfinished">Add sketch circle</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerEllipse.h" line="155"/>
      <source>Add sketch ellipse</source>
      <translation type="unfinished">Add sketch ellipse</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerArcOfEllipse.h" line="292"/>
      <source>Add sketch arc of ellipse</source>
      <translation type="unfinished">Add sketch arc of ellipse</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerArcOfHyperbola.h" line="302"/>
      <source>Add sketch arc of hyperbola</source>
      <translation type="unfinished">Add sketch arc of hyperbola</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerArcOfParabola.h" line="229"/>
      <source>Add sketch arc of Parabola</source>
      <translation type="unfinished">Add sketch arc of Parabola</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerPoint.h" line="82"/>
      <source>Add sketch point</source>
      <translation type="unfinished">Add sketch point</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerFillet.h" line="206"/>
      <location filename="../../DrawSketchHandlerFillet.h" line="261"/>
      <source>Create fillet</source>
      <translation type="unfinished">Create fillet</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerTrimming.h" line="171"/>
      <source>Trim edge</source>
      <translation type="unfinished">Trim edge</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerExtend.h" line="288"/>
      <source>Extend edge</source>
      <translation type="unfinished">Extend edge</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerSplitting.h" line="147"/>
      <source>Split edge</source>
      <translation type="unfinished">Split edge</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerExternal.h" line="167"/>
      <source>Add external geometry</source>
      <translation type="unfinished">Add external geometry</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerSlot.h" line="150"/>
      <source>Add slot</source>
      <translation type="unfinished">Add slot</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="141"/>
      <source>Convert to NURBS</source>
      <translation type="unfinished">Convert to NURBS</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="217"/>
      <source>Increase B-spline degree</source>
      <translation type="unfinished">Increase B-spline degree</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="296"/>
      <source>Decrease B-spline degree</source>
      <translation type="unfinished">Decrease B-spline degree</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="388"/>
      <source>Increase knot multiplicity</source>
      <translation type="unfinished">Increase knot multiplicity</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="536"/>
      <source>Decrease knot multiplicity</source>
      <translation type="unfinished">Decrease knot multiplicity</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="779"/>
      <source>Insert knot</source>
      <translation type="unfinished">Insert knot</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="1068"/>
      <source>Join Curves</source>
      <translation type="unfinished">Join Curves</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="268"/>
      <source>Cut in Sketcher</source>
      <translation type="unfinished">Cut in Sketcher</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="313"/>
      <source>Paste in Sketcher</source>
      <translation type="unfinished">Paste in Sketcher</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1057"/>
      <source>Exposing Internal Geometry</source>
      <translation type="unfinished">Exposing Internal Geometry</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1256"/>
      <source>Copy/clone/move geometry</source>
      <translation type="unfinished">Copy/clone/move geometry</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1837"/>
      <source>Create copy of geometry</source>
      <translation type="unfinished">Create copy of geometry</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2087"/>
      <source>Delete all geometry</source>
      <translation type="unfinished">Delete all geometry</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2151"/>
      <source>Delete All Constraints</source>
      <translation type="unfinished">Delete All Constraints</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2285"/>
      <source>Remove Axes Alignment</source>
      <translation type="unfinished">Remove Axes Alignment</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherVirtualSpace.cpp" line="169"/>
      <source>Toggle constraints to the other virtual space</source>
      <translation type="unfinished">Toggle constraints to the other virtual space</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherVirtualSpace.cpp" line="179"/>
      <location filename="../../TaskSketcherConstraints.cpp" line="1129"/>
      <location filename="../../TaskSketcherConstraints.cpp" line="1242"/>
      <location filename="../../TaskSketcherConstraints.cpp" line="1519"/>
      <source>Update constraint's virtual space</source>
      <translation type="unfinished">Update constraint's virtual space</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandler.cpp" line="761"/>
      <location filename="../../DrawSketchDefaultHandler.h" line="903"/>
      <source>Add auto constraints</source>
      <translation type="unfinished">Add auto constraints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="707"/>
      <source>Swap constraint names</source>
      <translation type="unfinished">Swap constraint names</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="1227"/>
      <source>Rename sketch constraint</source>
      <translation type="unfinished">Rename sketch constraint</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="1670"/>
      <source>Drag Point</source>
      <translation type="unfinished">Drag Point</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="1670"/>
      <source>Drag Curve</source>
      <translation type="unfinished">Drag Curve</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="1671"/>
      <source>Drag geometries</source>
      <translation type="unfinished">Drag geometries</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="1052"/>
      <source>Drag Constraint</source>
      <translation type="unfinished">Drag Constraint</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="1251"/>
      <source>Modify sketch constraints</source>
      <translation type="unfinished">Modify sketch constraints</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerCarbonCopy.h" line="168"/>
      <source>Create a carbon copy</source>
      <translation type="unfinished">Create a carbon copy</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerOffset.h" line="374"/>
      <source>Offset</source>
      <translation>Pomak</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerPolygon.h" line="110"/>
      <source>Add polygon</source>
      <translation type="unfinished">Add polygon</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerArcSlot.h" line="172"/>
      <source>Add sketch arc slot</source>
      <translation type="unfinished">Add sketch arc slot</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerRotate.h" line="119"/>
      <source>Rotate geometries</source>
      <translation type="unfinished">Rotate geometries</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerScale.h" line="115"/>
      <source>Scale geometries</source>
      <translation type="unfinished">Scale geometries</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerTranslate.h" line="114"/>
      <source>Translate geometries</source>
      <translation type="unfinished">Translate geometries</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerSymmetry.h" line="134"/>
      <source>Symmetry geometries</source>
      <translation type="unfinished">Symmetry geometries</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerBSpline.h" line="94"/>
      <source>Add sketch bSpline</source>
      <translation type="unfinished">Add sketch bSpline</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerBSpline.h" line="558"/>
      <location filename="../../DrawSketchHandlerBSpline.h" line="696"/>
      <source>Add sketch B-spline</source>
      <translation type="unfinished">Add sketch B-spline</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerLineSet.h" line="449"/>
      <source>Add line to sketch polyline</source>
      <translation type="unfinished">Add line to sketch polyline</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerLineSet.h" line="477"/>
      <source>Add arc to sketch polyline</source>
      <translation type="unfinished">Add arc to sketch polyline</translation>
    </message>
  </context>
  <context>
    <name>CommandGroup</name>
    <message>
      <location filename="../../Workbench.cpp" line="36"/>
      <source>Sketcher</source>
      <translation type="unfinished">Sketcher</translation>
    </message>
  </context>
  <context>
    <name>Exceptions</name>
    <message>
      <location filename="../../../App/SketchObject.cpp" line="2958"/>
      <source>Unable to guess intersection of curves. Try adding a coincident constraint between the vertices of the curves you are intending to fillet.</source>
      <translation type="unfinished">Unable to guess intersection of curves. Try adding a coincident constraint between the vertices of the curves you are intending to fillet.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchObject.cpp" line="7037"/>
      <source>You are requesting no change in knot multiplicity.</source>
      <translation type="unfinished">You are requesting no change in knot multiplicity.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchObject.cpp" line="7031"/>
      <location filename="../../../App/SketchObject.cpp" line="7217"/>
      <source>B-spline Geometry Index (GeoID) is out of bounds.</source>
      <translation type="unfinished">B-spline Geometry Index (GeoID) is out of bounds.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchObject.cpp" line="7043"/>
      <location filename="../../../App/SketchObject.cpp" line="7227"/>
      <source>The Geometry Index (GeoId) provided is not a B-spline.</source>
      <translation type="unfinished">The Geometry Index (GeoId) provided is not a B-spline.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchObject.cpp" line="7052"/>
      <source>The knot index is out of bounds. Note that in accordance with OCC notation, the first knot has index 1 and not zero.</source>
      <translation type="unfinished">The knot index is out of bounds. Note that in accordance with OCC notation, the first knot has index 1 and not zero.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchObject.cpp" line="7063"/>
      <source>The multiplicity cannot be increased beyond the degree of the B-spline.</source>
      <translation type="unfinished">The multiplicity cannot be increased beyond the degree of the B-spline.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchObject.cpp" line="7071"/>
      <source>The multiplicity cannot be decreased beyond zero.</source>
      <translation type="unfinished">The multiplicity cannot be decreased beyond zero.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchObject.cpp" line="7085"/>
      <source>OCC is unable to decrease the multiplicity within the maximum tolerance.</source>
      <translation type="unfinished">OCC is unable to decrease the multiplicity within the maximum tolerance.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchObject.cpp" line="7221"/>
      <source>Knot cannot have zero multiplicity.</source>
      <translation type="unfinished">Knot cannot have zero multiplicity.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchObject.cpp" line="7238"/>
      <source>Knot multiplicity cannot be higher than the degree of the B-spline.</source>
      <translation type="unfinished">Knot multiplicity cannot be higher than the degree of the B-spline.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchObject.cpp" line="7244"/>
      <source>Knot cannot be inserted outside the B-spline parameter range.</source>
      <translation type="unfinished">Knot cannot be inserted outside the B-spline parameter range.</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.cpp" line="321"/>
      <location filename="../../SketcherToolDefaultWidget.cpp" line="340"/>
      <location filename="../../SketcherToolDefaultWidget.cpp" line="367"/>
      <location filename="../../SketcherToolDefaultWidget.cpp" line="380"/>
      <location filename="../../SketcherToolDefaultWidget.cpp" line="393"/>
      <location filename="../../SketcherToolDefaultWidget.cpp" line="406"/>
      <location filename="../../SketcherToolDefaultWidget.cpp" line="418"/>
      <location filename="../../SketcherToolDefaultWidget.cpp" line="432"/>
      <location filename="../../SketcherToolDefaultWidget.cpp" line="459"/>
      <location filename="../../SketcherToolDefaultWidget.cpp" line="575"/>
      <source>ToolWidget parameter index out of range</source>
      <translation type="unfinished">ToolWidget parameter index out of range</translation>
    </message>
    <message>
      <location filename="../../../App/SketchAnalysis.cpp" line="675"/>
      <source>Autoconstraint error: Unsolvable sketch while applying coincident constraints.</source>
      <translation type="unfinished">Autoconstraint error: Unsolvable sketch while applying coincident constraints.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchAnalysis.cpp" line="722"/>
      <source>Autoconstraint error: Unsolvable sketch while applying vertical/horizontal constraints.</source>
      <translation type="unfinished">Autoconstraint error: Unsolvable sketch while applying vertical/horizontal constraints.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchAnalysis.cpp" line="814"/>
      <source>Autoconstraint error: Unsolvable sketch while applying equality constraints.</source>
      <translation type="unfinished">Autoconstraint error: Unsolvable sketch while applying equality constraints.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchAnalysis.cpp" line="854"/>
      <source>Autoconstraint error: Unsolvable sketch without constraints.</source>
      <translation type="unfinished">Autoconstraint error: Unsolvable sketch without constraints.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchAnalysis.cpp" line="868"/>
      <source>Autoconstraint error: Unsolvable sketch after applying horizontal and vertical constraints.</source>
      <translation type="unfinished">Autoconstraint error: Unsolvable sketch after applying horizontal and vertical constraints.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchAnalysis.cpp" line="883"/>
      <source>Autoconstraint error: Unsolvable sketch after applying point-on-point constraints.</source>
      <translation type="unfinished">Autoconstraint error: Unsolvable sketch after applying point-on-point constraints.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchAnalysis.cpp" line="904"/>
      <source>Autoconstraint error: Unsolvable sketch after applying equality constraints.</source>
      <translation type="unfinished">Autoconstraint error: Unsolvable sketch after applying equality constraints.</translation>
    </message>
  </context>
  <context>
    <name>Gui::TaskView::TaskSketcherCreateCommands</name>
    <message>
      <location filename="../../TaskSketcherCreateCommands.cpp" line="36"/>
      <source>Appearance</source>
      <translation type="unfinished">Appearance</translation>
    </message>
  </context>
  <context>
    <name>QObject</name>
    <message>
      <location filename="../../AppSketcherGui.cpp" line="141"/>
      <location filename="../../AppSketcherGui.cpp" line="143"/>
      <location filename="../../AppSketcherGui.cpp" line="145"/>
      <location filename="../../AppSketcherGui.cpp" line="147"/>
      <source>Sketcher</source>
      <translation type="unfinished">Sketcher</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="122"/>
      <source>There are no modes that accept the selected set of subelements</source>
      <translation type="unfinished">There are no modes that accept the selected set of subelements</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="125"/>
      <source>Broken link to support subelements</source>
      <translation type="unfinished">Broken link to support subelements</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="128"/>
      <location filename="../../Command.cpp" line="138"/>
      <source>Unexpected error</source>
      <translation type="unfinished">Unexpected error</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="132"/>
      <source>Face is non-planar</source>
      <translation type="unfinished">Face is non-planar</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="134"/>
      <source>Selected shapes are of wrong form (e.g., a curved edge where a straight one is needed)</source>
      <translation type="unfinished">Selected shapes are of wrong form (e.g., a curved edge where a straight one is needed)</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="178"/>
      <source>Sketch mapping</source>
      <translation type="unfinished">Sketch mapping</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="179"/>
      <source>Can't map the sketch to selected object. %1.</source>
      <translation type="unfinished">Can't map the sketch to selected object. %1.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="186"/>
      <location filename="../../Command.cpp" line="676"/>
      <source>Don't attach</source>
      <translation type="unfinished">Don't attach</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherVirtualSpace.cpp" line="122"/>
      <location filename="../../CommandSketcherVirtualSpace.cpp" line="131"/>
      <location filename="../../CommandSketcherVirtualSpace.cpp" line="158"/>
      <location filename="../../CommandAlterGeometry.cpp" line="169"/>
      <location filename="../../CommandAlterGeometry.cpp" line="178"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="169"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="244"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="327"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="380"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="440"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="528"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="576"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="938"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="1048"/>
      <location filename="../../CommandConstraints.cpp" line="173"/>
      <location filename="../../CommandConstraints.cpp" line="180"/>
      <location filename="../../CommandConstraints.cpp" line="2429"/>
      <location filename="../../CommandConstraints.cpp" line="2588"/>
      <location filename="../../CommandConstraints.cpp" line="2604"/>
      <location filename="../../CommandConstraints.cpp" line="2912"/>
      <location filename="../../CommandConstraints.cpp" line="3321"/>
      <location filename="../../CommandConstraints.cpp" line="3348"/>
      <location filename="../../CommandConstraints.cpp" line="3353"/>
      <location filename="../../CommandConstraints.cpp" line="3606"/>
      <location filename="../../CommandConstraints.cpp" line="3639"/>
      <location filename="../../CommandConstraints.cpp" line="3644"/>
      <location filename="../../CommandConstraints.cpp" line="3939"/>
      <location filename="../../CommandConstraints.cpp" line="3969"/>
      <location filename="../../CommandConstraints.cpp" line="3992"/>
      <location filename="../../CommandConstraints.cpp" line="4023"/>
      <location filename="../../CommandConstraints.cpp" line="4041"/>
      <location filename="../../CommandConstraints.cpp" line="4175"/>
      <location filename="../../CommandConstraints.cpp" line="4197"/>
      <location filename="../../CommandConstraints.cpp" line="4228"/>
      <location filename="../../CommandConstraints.cpp" line="4435"/>
      <location filename="../../CommandConstraints.cpp" line="4447"/>
      <location filename="../../CommandConstraints.cpp" line="4696"/>
      <location filename="../../CommandConstraints.cpp" line="4704"/>
      <location filename="../../CommandConstraints.cpp" line="4770"/>
      <location filename="../../CommandConstraints.cpp" line="4890"/>
      <location filename="../../CommandConstraints.cpp" line="4996"/>
      <location filename="../../CommandConstraints.cpp" line="5083"/>
      <location filename="../../CommandConstraints.cpp" line="5096"/>
      <location filename="../../CommandConstraints.cpp" line="5129"/>
      <location filename="../../CommandConstraints.cpp" line="5191"/>
      <location filename="../../CommandConstraints.cpp" line="5227"/>
      <location filename="../../CommandConstraints.cpp" line="5263"/>
      <location filename="../../CommandConstraints.cpp" line="5386"/>
      <location filename="../../CommandConstraints.cpp" line="5399"/>
      <location filename="../../CommandConstraints.cpp" line="5430"/>
      <location filename="../../CommandConstraints.cpp" line="5492"/>
      <location filename="../../CommandConstraints.cpp" line="5526"/>
      <location filename="../../CommandConstraints.cpp" line="5562"/>
      <location filename="../../CommandConstraints.cpp" line="5684"/>
      <location filename="../../CommandConstraints.cpp" line="5719"/>
      <location filename="../../CommandConstraints.cpp" line="5728"/>
      <location filename="../../CommandConstraints.cpp" line="5767"/>
      <location filename="../../CommandConstraints.cpp" line="5866"/>
      <location filename="../../CommandConstraints.cpp" line="5878"/>
      <location filename="../../CommandConstraints.cpp" line="5913"/>
      <location filename="../../CommandConstraints.cpp" line="5989"/>
      <location filename="../../CommandConstraints.cpp" line="5999"/>
      <location filename="../../CommandConstraints.cpp" line="6040"/>
      <location filename="../../CommandConstraints.cpp" line="6051"/>
      <location filename="../../CommandConstraints.cpp" line="6080"/>
      <location filename="../../CommandConstraints.cpp" line="6101"/>
      <location filename="../../CommandConstraints.cpp" line="6281"/>
      <location filename="../../CommandConstraints.cpp" line="6302"/>
      <location filename="../../CommandConstraints.cpp" line="6481"/>
      <location filename="../../CommandConstraints.cpp" line="6702"/>
      <location filename="../../CommandConstraints.cpp" line="6714"/>
      <location filename="../../CommandConstraints.cpp" line="6748"/>
      <location filename="../../CommandConstraints.cpp" line="6820"/>
      <location filename="../../CommandConstraints.cpp" line="6840"/>
      <location filename="../../CommandConstraints.cpp" line="6849"/>
      <location filename="../../CommandConstraints.cpp" line="6878"/>
      <location filename="../../CommandConstraints.cpp" line="6887"/>
      <location filename="../../CommandConstraints.cpp" line="6898"/>
      <location filename="../../CommandConstraints.cpp" line="6926"/>
      <location filename="../../CommandConstraints.cpp" line="7085"/>
      <location filename="../../CommandConstraints.cpp" line="7138"/>
      <location filename="../../CommandConstraints.cpp" line="7312"/>
      <location filename="../../CommandConstraints.cpp" line="7357"/>
      <location filename="../../CommandConstraints.cpp" line="7483"/>
      <location filename="../../CommandConstraints.cpp" line="7496"/>
      <location filename="../../CommandConstraints.cpp" line="7562"/>
      <location filename="../../CommandConstraints.cpp" line="7570"/>
      <location filename="../../CommandConstraints.cpp" line="7726"/>
      <location filename="../../CommandConstraints.cpp" line="7846"/>
      <location filename="../../CommandConstraints.cpp" line="7859"/>
      <location filename="../../CommandConstraints.cpp" line="7904"/>
      <location filename="../../CommandConstraints.cpp" line="7922"/>
      <location filename="../../CommandConstraints.cpp" line="8048"/>
      <location filename="../../CommandConstraints.cpp" line="8056"/>
      <location filename="../../CommandConstraints.cpp" line="8165"/>
      <location filename="../../CommandConstraints.cpp" line="8178"/>
      <location filename="../../CommandConstraints.cpp" line="8239"/>
      <location filename="../../CommandConstraints.cpp" line="8247"/>
      <location filename="../../CommandConstraints.cpp" line="8425"/>
      <location filename="../../CommandConstraints.cpp" line="8708"/>
      <location filename="../../CommandConstraints.cpp" line="8721"/>
      <location filename="../../CommandConstraints.cpp" line="8757"/>
      <location filename="../../CommandConstraints.cpp" line="8855"/>
      <location filename="../../CommandConstraints.cpp" line="8868"/>
      <location filename="../../CommandConstraints.cpp" line="8933"/>
      <location filename="../../CommandConstraints.cpp" line="8994"/>
      <location filename="../../CommandConstraints.cpp" line="9148"/>
      <location filename="../../CommandConstraints.cpp" line="9162"/>
      <location filename="../../CommandConstraints.cpp" line="9180"/>
      <location filename="../../CommandConstraints.cpp" line="9187"/>
      <location filename="../../CommandConstraints.cpp" line="9208"/>
      <location filename="../../CommandConstraints.cpp" line="9241"/>
      <location filename="../../CommandConstraints.cpp" line="9257"/>
      <location filename="../../CommandConstraints.cpp" line="9312"/>
      <location filename="../../CommandConstraints.cpp" line="9404"/>
      <location filename="../../CommandConstraints.cpp" line="9418"/>
      <location filename="../../CommandConstraints.cpp" line="9445"/>
      <location filename="../../CommandConstraints.cpp" line="9474"/>
      <location filename="../../CommandConstraints.cpp" line="9504"/>
      <location filename="../../CommandConstraints.cpp" line="9554"/>
      <location filename="../../CommandConstraints.cpp" line="9583"/>
      <location filename="../../CommandConstraints.cpp" line="9632"/>
      <location filename="../../CommandConstraints.cpp" line="9656"/>
      <location filename="../../CommandConstraints.cpp" line="9750"/>
      <location filename="../../CommandConstraints.cpp" line="9760"/>
      <location filename="../../CommandConstraints.cpp" line="9785"/>
      <location filename="../../CommandConstraints.cpp" line="9795"/>
      <location filename="../../CommandConstraints.cpp" line="9813"/>
      <location filename="../../CommandConstraints.cpp" line="9948"/>
      <location filename="../../CommandConstraints.cpp" line="10026"/>
      <location filename="../../CommandConstraints.cpp" line="10038"/>
      <location filename="../../CommandConstraints.cpp" line="10074"/>
      <location filename="../../CommandConstraints.cpp" line="10150"/>
      <location filename="../../CommandConstraints.cpp" line="10162"/>
      <location filename="../../CommandSketcherTools.cpp" line="80"/>
      <location filename="../../CommandSketcherTools.cpp" line="363"/>
      <location filename="../../CommandSketcherTools.cpp" line="1004"/>
      <location filename="../../CommandSketcherTools.cpp" line="1328"/>
      <location filename="../../CommandSketcherTools.cpp" line="1338"/>
      <location filename="../../CommandSketcherTools.cpp" line="1400"/>
      <location filename="../../CommandSketcherTools.cpp" line="1929"/>
      <location filename="../../CommandSketcherTools.cpp" line="1939"/>
      <location filename="../../CommandSketcherTools.cpp" line="2003"/>
      <location filename="../../CommandSketcherTools.cpp" line="2213"/>
      <location filename="../../CommandSketcherTools.cpp" line="2223"/>
      <location filename="../../CommandSketcherTools.cpp" line="2270"/>
      <location filename="../../CommandSketcherTools.cpp" line="2335"/>
      <source>Wrong selection</source>
      <translation type="unfinished">Wrong selection</translation>
    </message>
    <message>
      <location filename="../../CommandAlterGeometry.cpp" line="170"/>
      <location filename="../../CommandAlterGeometry.cpp" line="179"/>
      <source>Select edge(s) from the sketch.</source>
      <translation type="unfinished">Select edge(s) from the sketch.</translation>
    </message>
    <message>
      <location filename="../../EditDatumDialog.cpp" line="81"/>
      <source>Not allowed to edit the datum because the sketch contains conflicting constraints</source>
      <translation type="unfinished">Not allowed to edit the datum because the sketch contains conflicting constraints</translation>
    </message>
    <message>
      <location filename="../../EditDatumDialog.cpp" line="80"/>
      <source>Dimensional constraint</source>
      <translation type="unfinished">Dimensional constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="174"/>
      <source>Cannot add a constraint between two external geometries.</source>
      <translation type="unfinished">Cannot add a constraint between two external geometries.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="181"/>
      <source>Cannot add a constraint between two fixed geometries. Fixed geometries include external geometry, blocked geometry, and special points such as B-spline knot points.</source>
      <translation type="unfinished">Cannot add a constraint between two fixed geometries. Fixed geometries include external geometry, blocked geometry, and special points such as B-spline knot points.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="755"/>
      <source>Sketcher Constraint Substitution</source>
      <translation type="unfinished">Sketcher Constraint Substitution</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="761"/>
      <source>Keep notifying me of constraint substitutions</source>
      <translation type="unfinished">Keep notifying me of constraint substitutions</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="839"/>
      <location filename="../../CommandConstraints.cpp" line="850"/>
      <location filename="../../CommandConstraints.cpp" line="862"/>
      <source>Only sketch and its support are allowed to be selected.</source>
      <translation type="unfinished">Only sketch and its support are allowed to be selected.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="871"/>
      <source>One of the selected has to be on the sketch.</source>
      <translation type="unfinished">One of the selected has to be on the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2913"/>
      <source>Select an edge from the sketch.</source>
      <translation type="unfinished">Select an edge from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2877"/>
      <location filename="../../CommandConstraints.cpp" line="2886"/>
      <location filename="../../CommandConstraints.cpp" line="2938"/>
      <location filename="../../CommandConstraints.cpp" line="2962"/>
      <location filename="../../CommandConstraints.cpp" line="3016"/>
      <location filename="../../CommandConstraints.cpp" line="3050"/>
      <source>Impossible constraint</source>
      <translation type="unfinished">Impossible constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2939"/>
      <location filename="../../CommandConstraints.cpp" line="3051"/>
      <source>The selected edge is not a line segment.</source>
      <translation type="unfinished">The selected edge is not a line segment.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2869"/>
      <location filename="../../CommandConstraints.cpp" line="3656"/>
      <location filename="../../CommandConstraints.cpp" line="3709"/>
      <source>Double constraint</source>
      <translation type="unfinished">Double constraint</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2870"/>
      <source>The selected edge already has a horizontal constraint!</source>
      <translation type="unfinished">The selected edge already has a horizontal constraint!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2878"/>
      <source>The selected edge already has a vertical constraint!</source>
      <translation type="unfinished">The selected edge already has a vertical constraint!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2887"/>
      <location filename="../../CommandConstraints.cpp" line="3657"/>
      <location filename="../../CommandConstraints.cpp" line="3710"/>
      <source>The selected edge already has a Block constraint!</source>
      <translation type="unfinished">The selected edge already has a Block constraint!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3017"/>
      <source>There are more than one fixed points selected. Select a maximum of one fixed point!</source>
      <translation type="unfinished">There are more than one fixed points selected. Select a maximum of one fixed point!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3322"/>
      <location filename="../../CommandConstraints.cpp" line="3607"/>
      <location filename="../../CommandConstraints.cpp" line="4436"/>
      <source>Select vertices from the sketch.</source>
      <translation type="unfinished">Select vertices from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3349"/>
      <source>Select one vertex from the sketch other than the origin.</source>
      <translation type="unfinished">Select one vertex from the sketch other than the origin.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3354"/>
      <source>Select only vertices from the sketch. The last selected vertex may be the origin.</source>
      <translation type="unfinished">Select only vertices from the sketch. The last selected vertex may be the origin.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3620"/>
      <source>Wrong solver status</source>
      <translation type="unfinished">Wrong solver status</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3621"/>
      <source>A Block constraint cannot be added if the sketch is unsolved or there are redundant and conflicting constraints.</source>
      <translation type="unfinished">A Block constraint cannot be added if the sketch is unsolved or there are redundant and conflicting constraints.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3640"/>
      <source>Select one edge from the sketch.</source>
      <translation type="unfinished">Select one edge from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3645"/>
      <source>Select only edges from the sketch.</source>
      <translation type="unfinished">Select only edges from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4024"/>
      <source>None of the selected points were constrained onto the respective curves, because they are part of the same element, they are both external geometry, or the edge is not eligible.</source>
      <translation type="unfinished">None of the selected points were constrained onto the respective curves, because they are part of the same element, they are both external geometry, or the edge is not eligible.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="7086"/>
      <source>Only tangent-via-point is supported with a B-spline.</source>
      <translation type="unfinished">Only tangent-via-point is supported with a B-spline.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="7571"/>
      <location filename="../../CommandConstraints.cpp" line="8248"/>
      <source>Select either only one or more B-spline poles or only one or more arcs or circles from the sketch, but not mixed.</source>
      <translation type="unfinished">Select either only one or more B-spline poles or only one or more arcs or circles from the sketch, but not mixed.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9735"/>
      <source>Select two endpoints of lines to act as rays, and an edge representing a boundary. The first selected point corresponds to index n1, second to n2, and the value sets the ratio n2/n1.</source>
      <comment>Constraint_SnellsLaw</comment>
      <translation type="unfinished">Select two endpoints of lines to act as rays, and an edge representing a boundary. The first selected point corresponds to index n1, second to n2, and the value sets the ratio n2/n1.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9761"/>
      <source>Number of selected objects is not 3</source>
      <translation type="unfinished">Number of selected objects is not 3</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="566"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="1085"/>
      <location filename="../../CommandConstraints.cpp" line="786"/>
      <source>Error</source>
      <translation type="unfinished">Error</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="787"/>
      <source>Unexpected error. More information may be available in the Report View.</source>
      <translation type="unfinished">Unexpected error. More information may be available in the Report View.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2963"/>
      <source>The selected item(s) can't accept a horizontal or vertical constraint!</source>
      <translation type="unfinished">The selected item(s) can't accept a horizontal or vertical constraint!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3872"/>
      <source>Endpoint to endpoint tangency was applied instead.</source>
      <translation type="unfinished">Endpoint to endpoint tangency was applied instead.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4042"/>
      <source>Select two or more vertices from the sketch for a coincident constraint, or two or more circles, ellipses, arcs or arcs of ellipse for a concentric constraint.</source>
      <translation type="unfinished">Select two or more vertices from the sketch for a coincident constraint, or two or more circles, ellipses, arcs or arcs of ellipse for a concentric constraint.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4229"/>
      <source>Select two vertices from the sketch for a coincident constraint, or two circles, ellipses, arcs or arcs of ellipse for a concentric constraint.</source>
      <translation type="unfinished">Select two vertices from the sketch for a coincident constraint, or two circles, ellipses, arcs or arcs of ellipse for a concentric constraint.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4448"/>
      <source>Select exactly one line or one point and one line or two points from the sketch.</source>
      <translation type="unfinished">Select exactly one line or one point and one line or two points from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4705"/>
      <source>Cannot add a length constraint on an axis!</source>
      <translation type="unfinished">Cannot add a length constraint on an axis!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4771"/>
      <location filename="../../CommandConstraints.cpp" line="4997"/>
      <source>Select exactly one line or one point and one line or two points or two circles from the sketch.</source>
      <translation type="unfinished">Select exactly one line or one point and one line or two points or two circles from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4891"/>
      <source>This constraint does not make sense for non-linear curves.</source>
      <translation type="unfinished">This constraint does not make sense for non-linear curves.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3824"/>
      <source>Endpoint to edge tangency was applied instead.</source>
      <translation type="unfinished">Endpoint to edge tangency was applied instead.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5084"/>
      <location filename="../../CommandConstraints.cpp" line="5387"/>
      <location filename="../../CommandConstraints.cpp" line="7484"/>
      <location filename="../../CommandConstraints.cpp" line="7847"/>
      <location filename="../../CommandConstraints.cpp" line="8166"/>
      <location filename="../../CommandConstraints.cpp" line="8709"/>
      <source>Select the right things from the sketch.</source>
      <translation type="unfinished">Select the right things from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3993"/>
      <location filename="../../CommandConstraints.cpp" line="4176"/>
      <location filename="../../CommandConstraints.cpp" line="5914"/>
      <location filename="../../CommandConstraints.cpp" line="6052"/>
      <location filename="../../CommandConstraints.cpp" line="6102"/>
      <location filename="../../CommandConstraints.cpp" line="6303"/>
      <location filename="../../CommandConstraints.cpp" line="6482"/>
      <location filename="../../CommandConstraints.cpp" line="6749"/>
      <location filename="../../CommandConstraints.cpp" line="6899"/>
      <location filename="../../CommandConstraints.cpp" line="6927"/>
      <location filename="../../CommandConstraints.cpp" line="7139"/>
      <location filename="../../CommandConstraints.cpp" line="7358"/>
      <location filename="../../CommandConstraints.cpp" line="7905"/>
      <location filename="../../CommandConstraints.cpp" line="8057"/>
      <location filename="../../CommandConstraints.cpp" line="8758"/>
      <location filename="../../CommandConstraints.cpp" line="8856"/>
      <location filename="../../CommandConstraints.cpp" line="8995"/>
      <location filename="../../CommandConstraints.cpp" line="9814"/>
      <source>Select an edge that is not a B-spline weight.</source>
      <translation type="unfinished">Select an edge that is not a B-spline weight.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="229"/>
      <source>One or two point on object constraint(s) was/were deleted, since the latest constraint being applied internally applies point-on-object as well.</source>
      <translation type="unfinished">One or two point on object constraint(s) was/were deleted, since the latest constraint being applied internally applies point-on-object as well.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3914"/>
      <source>Select either several points, or several conics for concentricity.</source>
      <translation type="unfinished">Select either several points, or several conics for concentricity.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3917"/>
      <source>Select either one point and several curves, or one curve and several points</source>
      <translation type="unfinished">Select either one point and several curves, or one curve and several points</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3920"/>
      <source>Select either one point and several curves or one curve and several points for pointOnObject, or several points for coincidence, or several conics for concentricity.</source>
      <translation type="unfinished">Select either one point and several curves or one curve and several points for pointOnObject, or several points for coincidence, or several conics for concentricity.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4198"/>
      <source>None of the selected points were constrained onto the respective curves, either because they are parts of the same element, or because they are both external geometry.</source>
      <translation type="unfinished">None of the selected points were constrained onto the respective curves, either because they are parts of the same element, or because they are both external geometry.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="4697"/>
      <source>Cannot add a length constraint on this selection!</source>
      <translation type="unfinished">Cannot add a length constraint on this selection!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5097"/>
      <location filename="../../CommandConstraints.cpp" line="5228"/>
      <location filename="../../CommandConstraints.cpp" line="5400"/>
      <location filename="../../CommandConstraints.cpp" line="5527"/>
      <source>Select exactly one line or up to two points from the sketch.</source>
      <translation type="unfinished">Select exactly one line or up to two points from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5130"/>
      <source>Cannot add a horizontal length constraint on an axis!</source>
      <translation type="unfinished">Cannot add a horizontal length constraint on an axis!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5192"/>
      <source>Cannot add a fixed x-coordinate constraint on the origin point!</source>
      <translation type="unfinished">Cannot add a fixed x-coordinate constraint on the origin point!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5264"/>
      <location filename="../../CommandConstraints.cpp" line="5563"/>
      <source>This constraint only makes sense on a line segment or a pair of points.</source>
      <translation type="unfinished">This constraint only makes sense on a line segment or a pair of points.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5431"/>
      <source>Cannot add a vertical length constraint on an axis!</source>
      <translation type="unfinished">Cannot add a vertical length constraint on an axis!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5493"/>
      <source>Cannot add a fixed y-coordinate constraint on the origin point!</source>
      <translation type="unfinished">Cannot add a fixed y-coordinate constraint on the origin point!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5685"/>
      <source>Select two or more lines from the sketch.</source>
      <translation type="unfinished">Select two or more lines from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5720"/>
      <source>One selected edge is not a valid line.</source>
      <translation type="unfinished">One selected edge is not a valid line.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5729"/>
      <location filename="../../CommandConstraints.cpp" line="9163"/>
      <source>Select at least two lines from the sketch.</source>
      <translation type="unfinished">Select at least two lines from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5768"/>
      <source>The selected edge is not a valid line.</source>
      <translation type="unfinished">The selected edge is not a valid line.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5857"/>
      <source>There is a number of ways this constraint can be applied.

Accepted combinations: two curves; an endpoint and a curve; two endpoints; two curves and a point.</source>
      <comment>perpendicular constraint</comment>
      <translation type="unfinished">There is a number of ways this constraint can be applied.

Accepted combinations: two curves; an endpoint and a curve; two endpoints; two curves and a point.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5862"/>
      <source>Select some geometry from the sketch.</source>
      <comment>perpendicular constraint</comment>
      <translation type="unfinished">Select some geometry from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="6000"/>
      <location filename="../../CommandConstraints.cpp" line="6041"/>
      <source>Cannot add a perpendicularity constraint at an unconnected point!</source>
      <translation type="unfinished">Cannot add a perpendicularity constraint at an unconnected point!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="6081"/>
      <location filename="../../CommandConstraints.cpp" line="6282"/>
      <source>One of the selected edges should be a line.</source>
      <translation type="unfinished">One of the selected edges should be a line.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="6634"/>
      <source>Endpoint to endpoint tangency was applied. The coincident constraint was deleted.</source>
      <translation type="unfinished">Endpoint to endpoint tangency was applied. The coincident constraint was deleted.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="6662"/>
      <source>Endpoint to edge tangency was applied. The point on object constraint was deleted.</source>
      <translation type="unfinished">Endpoint to edge tangency was applied. The point on object constraint was deleted.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="6693"/>
      <source>There are a number of ways this constraint can be applied.

Accepted combinations: two curves; an endpoint and a curve; two endpoints; two curves and a point.</source>
      <comment>tangent constraint</comment>
      <translation type="unfinished">There are a number of ways this constraint can be applied.

Accepted combinations: two curves; an endpoint and a curve; two endpoints; two curves and a point.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="6698"/>
      <source>Select some geometry from the sketch.</source>
      <comment>tangent constraint</comment>
      <translation type="unfinished">Select some geometry from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="6850"/>
      <location filename="../../CommandConstraints.cpp" line="6888"/>
      <location filename="../../CommandConstraints.cpp" line="7313"/>
      <source>Cannot add a tangency constraint at an unconnected point!</source>
      <translation type="unfinished">Cannot add a tangency constraint at an unconnected point!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="6841"/>
      <location filename="../../CommandConstraints.cpp" line="6879"/>
      <source>Tangent constraint at B-spline knot is only supported with lines!</source>
      <translation type="unfinished">Tangent constraint at B-spline knot is only supported with lines!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3892"/>
      <source>B-spline knot to endpoint tangency was applied instead.</source>
      <translation type="unfinished">B-spline knot to endpoint tangency was applied instead.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5879"/>
      <location filename="../../CommandConstraints.cpp" line="6715"/>
      <source>Wrong number of selected objects!</source>
      <translation type="unfinished">Wrong number of selected objects!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="5990"/>
      <location filename="../../CommandConstraints.cpp" line="6821"/>
      <source>With 3 objects, there must be 2 curves and 1 point.</source>
      <translation type="unfinished">With 3 objects, there must be 2 curves and 1 point.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="7497"/>
      <location filename="../../CommandConstraints.cpp" line="7563"/>
      <location filename="../../CommandConstraints.cpp" line="7860"/>
      <location filename="../../CommandConstraints.cpp" line="7923"/>
      <location filename="../../CommandConstraints.cpp" line="8179"/>
      <location filename="../../CommandConstraints.cpp" line="8240"/>
      <source>Select one or more arcs or circles from the sketch.</source>
      <translation type="unfinished">Select one or more arcs or circles from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="7727"/>
      <location filename="../../CommandConstraints.cpp" line="8049"/>
      <location filename="../../CommandConstraints.cpp" line="8426"/>
      <source>Constraint only applies to arcs or circles.</source>
      <translation type="unfinished">Constraint only applies to arcs or circles.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="8722"/>
      <location filename="../../CommandConstraints.cpp" line="8934"/>
      <source>Select one or two lines from the sketch. Or select two edges and a point.</source>
      <translation type="unfinished">Select one or two lines from the sketch. Or select two edges and a point.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="257"/>
      <source>Parallel lines</source>
      <translation type="unfinished">Parallel lines</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="258"/>
      <source>An angle constraint cannot be set for two parallel lines.</source>
      <translation type="unfinished">An angle constraint cannot be set for two parallel lines.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="8869"/>
      <source>Cannot add an angle constraint on an axis!</source>
      <translation type="unfinished">Cannot add an angle constraint on an axis!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9149"/>
      <source>Select two edges from the sketch.</source>
      <translation type="unfinished">Select two edges from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9181"/>
      <source>Select two or more compatible edges.</source>
      <translation type="unfinished">Select two or more compatible edges.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9188"/>
      <source>Sketch axes cannot be used in equality constraints.</source>
      <translation type="unfinished">Sketch axes cannot be used in equality constraints.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9209"/>
      <source>Equality for B-spline edge currently unsupported.</source>
      <translation type="unfinished">Equality for B-spline edge currently unsupported.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2430"/>
      <location filename="../../CommandConstraints.cpp" line="9242"/>
      <location filename="../../CommandConstraints.cpp" line="9258"/>
      <location filename="../../CommandConstraints.cpp" line="9313"/>
      <source>Select two or more edges of similar type.</source>
      <translation type="unfinished">Select two or more edges of similar type.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9405"/>
      <location filename="../../CommandConstraints.cpp" line="9419"/>
      <location filename="../../CommandConstraints.cpp" line="9475"/>
      <location filename="../../CommandConstraints.cpp" line="9555"/>
      <location filename="../../CommandConstraints.cpp" line="9657"/>
      <source>Select two points and a symmetry line, two points and a symmetry point or a line and a symmetry point from the sketch.</source>
      <translation type="unfinished">Select two points and a symmetry line, two points and a symmetry point or a line and a symmetry point from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9446"/>
      <location filename="../../CommandConstraints.cpp" line="9633"/>
      <source>Cannot add a symmetry constraint between a line and its end points.</source>
      <translation type="unfinished">Cannot add a symmetry constraint between a line and its end points.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2589"/>
      <location filename="../../CommandConstraints.cpp" line="2605"/>
      <location filename="../../CommandConstraints.cpp" line="9505"/>
      <location filename="../../CommandConstraints.cpp" line="9584"/>
      <source>Cannot add a symmetry constraint between a line and its end points!</source>
      <translation type="unfinished">Cannot add a symmetry constraint between a line and its end points!</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9744"/>
      <source>Selected objects are not just geometry from one sketch.</source>
      <translation type="unfinished">Selected objects are not just geometry from one sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9786"/>
      <source>Cannot create constraint with external geometry only.</source>
      <translation type="unfinished">Cannot create constraint with external geometry only.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9796"/>
      <source>Incompatible geometry is selected.</source>
      <translation type="unfinished">Incompatible geometry is selected.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9949"/>
      <source>Select one dimensional constraint from the sketch.</source>
      <translation type="unfinished">Select one dimensional constraint from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="10027"/>
      <location filename="../../CommandConstraints.cpp" line="10039"/>
      <location filename="../../CommandConstraints.cpp" line="10075"/>
      <location filename="../../CommandConstraints.cpp" line="10151"/>
      <location filename="../../CommandConstraints.cpp" line="10163"/>
      <source>Select constraints from the sketch.</source>
      <translation type="unfinished">Select constraints from the sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherVirtualSpace.cpp" line="123"/>
      <location filename="../../CommandSketcherVirtualSpace.cpp" line="132"/>
      <location filename="../../CommandSketcherVirtualSpace.cpp" line="159"/>
      <source>Select constraint(s) from the sketch.</source>
      <translation type="unfinished">Select constraint(s) from the sketch.</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerFillet.h" line="280"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="421"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="796"/>
      <source>CAD Kernel Error</source>
      <translation type="unfinished">CAD Kernel Error</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="170"/>
      <source>None of the selected elements is an edge.</source>
      <translation type="unfinished">None of the selected elements is an edge.</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="381"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="529"/>
      <source>The selection comprises more than one item. Please select just one knot.</source>
      <translation type="unfinished">The selection comprises more than one item. Please select just one knot.</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="430"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="804"/>
      <source>Input Error</source>
      <translation type="unfinished">Input Error</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="441"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="577"/>
      <source>None of the selected elements is a knot of a B-spline</source>
      <translation type="unfinished">None of the selected elements is a knot of a B-spline</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="920"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="993"/>
      <source>Selection is empty</source>
      <translation type="unfinished">Selection is empty</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="245"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="328"/>
      <source>At least one of the selected objects was not a B-spline and was ignored.</source>
      <translation type="unfinished">At least one of the selected objects was not a B-spline and was ignored.</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="921"/>
      <source>Nothing is selected. Please select a B-spline.</source>
      <translation type="unfinished">Nothing is selected. Please select a B-spline.</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="939"/>
      <source>Please select a B-spline to insert a knot (not a knot on it). If the curve is not a B-spline, please convert it into one first.</source>
      <translation type="unfinished">Please select a B-spline to insert a knot (not a knot on it). If the curve is not a B-spline, please convert it into one first.</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="994"/>
      <source>Nothing is selected. Please select end points of curves.</source>
      <translation type="unfinished">Nothing is selected. Please select end points of curves.</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="1021"/>
      <source>Too many curves on point</source>
      <translation type="unfinished">Too many curves on point</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="1022"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="1032"/>
      <source>Exactly two curves should end at the selected point to be able to join them.</source>
      <translation type="unfinished">Exactly two curves should end at the selected point to be able to join them.</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="1031"/>
      <source>Too few curves on point</source>
      <translation type="unfinished">Too few curves on point</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="1049"/>
      <source>Two end points, or coincident point should be selected.</source>
      <translation type="unfinished">Two end points, or coincident point should be selected.</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="81"/>
      <location filename="../../CommandSketcherTools.cpp" line="364"/>
      <location filename="../../CommandSketcherTools.cpp" line="1005"/>
      <location filename="../../CommandSketcherTools.cpp" line="1329"/>
      <location filename="../../CommandSketcherTools.cpp" line="1339"/>
      <location filename="../../CommandSketcherTools.cpp" line="1930"/>
      <location filename="../../CommandSketcherTools.cpp" line="1940"/>
      <location filename="../../CommandSketcherTools.cpp" line="2214"/>
      <location filename="../../CommandSketcherTools.cpp" line="2224"/>
      <location filename="../../CommandSketcherTools.cpp" line="2336"/>
      <source>Select elements from a single sketch.</source>
      <translation type="unfinished">Select elements from a single sketch.</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="869"/>
      <source>No constraint selected</source>
      <translation type="unfinished">No constraint selected</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="870"/>
      <source>At least one constraint must be selected</source>
      <translation type="unfinished">At least one constraint must be selected</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1401"/>
      <location filename="../../CommandSketcherTools.cpp" line="2004"/>
      <source>A copy requires at least one selected non-external geometric element</source>
      <translation type="unfinished">A copy requires at least one selected non-external geometric element</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2077"/>
      <source>Delete All Geometry</source>
      <translation type="unfinished">Delete All Geometry</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2078"/>
      <source>Are you really sure you want to delete all geometry and constraints?</source>
      <translation type="unfinished">Are you really sure you want to delete all geometry and constraints?</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2141"/>
      <source>Delete All Constraints</source>
      <translation type="unfinished">Delete All Constraints</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2142"/>
      <source>Are you really sure you want to delete all the constraints?</source>
      <translation type="unfinished">Are you really sure you want to delete all the constraints?</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2271"/>
      <source>Removal of axes alignment requires at least one selected non-external geometric element</source>
      <translation type="unfinished">Removal of axes alignment requires at least one selected non-external geometric element</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="603"/>
      <location filename="../../TaskSketcherElements.cpp" line="650"/>
      <source>Unsupported visual layer operation</source>
      <translation type="unfinished">Unsupported visual layer operation</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="604"/>
      <location filename="../../TaskSketcherElements.cpp" line="651"/>
      <source>It is currently unsupported to move external geometry to another visual layer. External geometry will be omitted</source>
      <translation type="unfinished">It is currently unsupported to move external geometry to another visual layer. External geometry will be omitted</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerFillet.h" line="288"/>
      <source>Value Error</source>
      <translation type="unfinished">Value Error</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerFillet.h" line="350"/>
      <source>Fillet/Chamfer parameters</source>
      <translation type="unfinished">Fillet/Chamfer parameters</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerLine.h" line="213"/>
      <source>Line parameters</source>
      <translation type="unfinished">Line parameters</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerOffset.h" line="180"/>
      <source>Offset parameters</source>
      <translation type="unfinished">Offset parameters</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerPolygon.h" line="202"/>
      <source>Polygon parameters</source>
      <translation type="unfinished">Polygon parameters</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerRectangle.h" line="587"/>
      <source>Rectangle parameters</source>
      <translation type="unfinished">Rectangle parameters</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerArc.h" line="339"/>
      <source>Arc parameters</source>
      <translation type="unfinished">Arc parameters</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerArcSlot.h" line="269"/>
      <source>Arc Slot parameters</source>
      <translation type="unfinished">Arc Slot parameters</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerCircle.h" line="263"/>
      <source>Circle parameters</source>
      <translation type="unfinished">Circle parameters</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerEllipse.h" line="276"/>
      <source>Ellipse parameters</source>
      <translation type="unfinished">Ellipse parameters</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerRotate.h" line="178"/>
      <source>Rotate parameters</source>
      <translation type="unfinished">Rotate parameters</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerScale.h" line="174"/>
      <source>Scale parameters</source>
      <translation type="unfinished">Scale parameters</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerTranslate.h" line="173"/>
      <source>Translate parameters</source>
      <translation type="unfinished">Translate parameters</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerSymmetry.h" line="194"/>
      <source>Symmetry parameters</source>
      <translation type="unfinished">Symmetry parameters</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerBSpline.h" line="451"/>
      <source>B-spline parameters</source>
      <translation type="unfinished">B-spline parameters</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::CarbonCopySelection</name>
    <message>
      <location filename="../../DrawSketchHandlerCarbonCopy.h" line="78"/>
      <source>Carbon copy would cause a circular dependency.</source>
      <translation type="unfinished">Carbon copy would cause a circular dependency.</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerCarbonCopy.h" line="81"/>
      <source>This object is in another document.</source>
      <translation type="unfinished">This object is in another document.</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerCarbonCopy.h" line="84"/>
      <source>This object belongs to another body. Hold Ctrl to allow cross-references.</source>
      <translation type="unfinished">This object belongs to another body. Hold Ctrl to allow cross-references.</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerCarbonCopy.h" line="89"/>
      <source>This object belongs to another body and it contains external geometry. Cross-reference not allowed.</source>
      <translation type="unfinished">This object belongs to another body and it contains external geometry. Cross-reference not allowed.</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerCarbonCopy.h" line="93"/>
      <source>This object belongs to another part.</source>
      <translation type="unfinished">This object belongs to another part.</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerCarbonCopy.h" line="97"/>
      <source>The selected sketch is not parallel to this sketch. Hold Ctrl+Alt to allow non-parallel sketches.</source>
      <translation type="unfinished">The selected sketch is not parallel to this sketch. Hold Ctrl+Alt to allow non-parallel sketches.</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerCarbonCopy.h" line="102"/>
      <source>The XY axes of the selected sketch do not have the same direction as this sketch. Hold Ctrl+Alt to disregard it.</source>
      <translation type="unfinished">The XY axes of the selected sketch do not have the same direction as this sketch. Hold Ctrl+Alt to disregard it.</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerCarbonCopy.h" line="107"/>
      <source>The origin of the selected sketch is not aligned with the origin of this sketch. Hold Ctrl+Alt to disregard it.</source>
      <translation type="unfinished">The origin of the selected sketch is not aligned with the origin of this sketch. Hold Ctrl+Alt to disregard it.</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::ConstraintFilterList</name>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="109"/>
      <source>All</source>
      <translation type="unfinished">All</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="110"/>
      <source>Geometric</source>
      <translation type="unfinished">Geometric</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="111"/>
      <source>Coincident</source>
      <translation type="unfinished">Coincident</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="112"/>
      <source>Point on Object</source>
      <translation type="unfinished">Point on Object</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="113"/>
      <source>Vertical</source>
      <translation type="unfinished">Vertical</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="114"/>
      <source>Horizontal</source>
      <translation type="unfinished">Horizontal</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="115"/>
      <source>Parallel</source>
      <translation type="unfinished">Parallel</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="116"/>
      <source>Perpendicular</source>
      <translation type="unfinished">Perpendicular</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="117"/>
      <source>Tangent</source>
      <translation type="unfinished">Tangent</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="118"/>
      <source>Equality</source>
      <translation type="unfinished">Equality</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="119"/>
      <source>Symmetric</source>
      <translation type="unfinished">Symmetric</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="120"/>
      <source>Block</source>
      <translation type="unfinished">Block</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="121"/>
      <source>Internal Alignment</source>
      <translation type="unfinished">Internal Alignment</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="122"/>
      <source>Datums</source>
      <translation type="unfinished">Datums</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="123"/>
      <source>Horizontal Distance</source>
      <translation type="unfinished">Horizontal Distance</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="124"/>
      <source>Vertical Distance</source>
      <translation type="unfinished">Vertical Distance</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="125"/>
      <source>Distance</source>
      <translation type="unfinished">Distance</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="126"/>
      <source>Radius</source>
      <translation type="unfinished">Radius</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="127"/>
      <source>Weight</source>
      <translation type="unfinished">Weight</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="128"/>
      <source>Diameter</source>
      <translation type="unfinished">Diameter</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="129"/>
      <source>Angle</source>
      <translation type="unfinished">Angle</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="130"/>
      <source>Snell's Law</source>
      <translation type="unfinished">Snell's Law</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="131"/>
      <source>Named</source>
      <translation type="unfinished">Named</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="132"/>
      <source>Reference</source>
      <translation type="unfinished">Reference</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="133"/>
      <source>Selected constraints</source>
      <translation type="unfinished">Selected constraints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.h" line="134"/>
      <source>Associated constraints</source>
      <translation type="unfinished">Associated constraints</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::ConstraintView</name>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="66"/>
      <source>Select Elements</source>
      <translation type="unfinished">Select Elements</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="562"/>
      <source>Change value</source>
      <translation type="unfinished">Change value</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="567"/>
      <source>Toggle to/from reference</source>
      <translation type="unfinished">Toggle to/from reference</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="571"/>
      <source>Deactivate</source>
      <translation type="unfinished">Deactivate</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="571"/>
      <source>Activate</source>
      <translation type="unfinished">Activate</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="575"/>
      <source>Show constraints</source>
      <translation type="unfinished">Show constraints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="577"/>
      <source>Hide constraints</source>
      <translation type="unfinished">Hide constraints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="587"/>
      <source>Rename</source>
      <translation type="unfinished">Rename</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="594"/>
      <source>Center sketch</source>
      <translation type="unfinished">Center sketch</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="597"/>
      <source>Delete</source>
      <translation type="unfinished">Delete</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="602"/>
      <source>Swap constraint names</source>
      <translation type="unfinished">Swap constraint names</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="697"/>
      <source>Unnamed constraint</source>
      <translation type="unfinished">Unnamed constraint</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="698"/>
      <source>Only the names of named constraints can be swapped.</source>
      <translation type="unfinished">Only the names of named constraints can be swapped.</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::EditDatumDialog</name>
    <message>
      <location filename="../../EditDatumDialog.cpp" line="98"/>
      <source>Insert angle</source>
      <translation type="unfinished">Insert angle</translation>
    </message>
    <message>
      <location filename="../../EditDatumDialog.cpp" line="100"/>
      <source>Angle:</source>
      <translation type="unfinished">Angle:</translation>
    </message>
    <message>
      <location filename="../../EditDatumDialog.cpp" line="105"/>
      <source>Insert radius</source>
      <translation type="unfinished">Insert radius</translation>
    </message>
    <message>
      <location filename="../../EditDatumDialog.cpp" line="107"/>
      <source>Radius:</source>
      <translation type="unfinished">Radius:</translation>
    </message>
    <message>
      <location filename="../../EditDatumDialog.cpp" line="112"/>
      <source>Insert diameter</source>
      <translation type="unfinished">Insert diameter</translation>
    </message>
    <message>
      <location filename="../../EditDatumDialog.cpp" line="114"/>
      <source>Diameter:</source>
      <translation type="unfinished">Diameter:</translation>
    </message>
    <message>
      <location filename="../../EditDatumDialog.cpp" line="119"/>
      <source>Insert weight</source>
      <translation type="unfinished">Insert weight</translation>
    </message>
    <message>
      <location filename="../../EditDatumDialog.cpp" line="120"/>
      <source>Weight:</source>
      <translation type="unfinished">Weight:</translation>
    </message>
    <message>
      <location filename="../../EditDatumDialog.cpp" line="125"/>
      <source>Refractive index ratio</source>
      <comment>Constraint_SnellsLaw</comment>
      <translation type="unfinished">Refractive index ratio</translation>
    </message>
    <message>
      <location filename="../../EditDatumDialog.cpp" line="126"/>
      <source>Ratio n2/n1:</source>
      <comment>Constraint_SnellsLaw</comment>
      <translation type="unfinished">Ratio n2/n1:</translation>
    </message>
    <message>
      <location filename="../../EditDatumDialog.cpp" line="132"/>
      <source>Insert length</source>
      <translation type="unfinished">Insert length</translation>
    </message>
    <message>
      <location filename="../../EditDatumDialog.cpp" line="134"/>
      <source>Length:</source>
      <translation type="unfinished">Length:</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9825"/>
      <source>Refractive index ratio</source>
      <translation type="unfinished">Refractive index ratio</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9826"/>
      <source>Ratio n2/n1:</source>
      <translation type="unfinished">Ratio n2/n1:</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::ElementFilterList</name>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="311"/>
      <source>Normal</source>
      <translation type="unfinished">Normal</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="312"/>
      <source>Construction</source>
      <translation type="unfinished">Construction</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="313"/>
      <source>Internal</source>
      <translation type="unfinished">Internal</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="314"/>
      <source>External</source>
      <translation type="unfinished">External</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="315"/>
      <source>All types</source>
      <translation type="unfinished">All types</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="316"/>
      <source>Point</source>
      <translation type="unfinished">Point</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="317"/>
      <source>Line</source>
      <translation>Linija</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="318"/>
      <source>Circle</source>
      <translation type="unfinished">Circle</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="319"/>
      <source>Ellipse</source>
      <translation type="unfinished">Ellipse</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="320"/>
      <source>Arc of circle</source>
      <translation type="unfinished">Arc of circle</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="321"/>
      <source>Arc of ellipse</source>
      <translation type="unfinished">Arc of ellipse</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="322"/>
      <source>Arc of hyperbola</source>
      <translation type="unfinished">Arc of hyperbola</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="323"/>
      <source>Arc of parabola</source>
      <translation type="unfinished">Arc of parabola</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="324"/>
      <source>B-spline</source>
      <translation type="unfinished">B-spline</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::ElementView</name>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="62"/>
      <source>Point Coincidence</source>
      <translation type="unfinished">Point Coincidence</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="63"/>
      <source>Point on Object</source>
      <translation type="unfinished">Point on Object</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="64"/>
      <source>Vertical Constraint</source>
      <translation type="unfinished">Vertical Constraint</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="65"/>
      <source>Horizontal Constraint</source>
      <translation type="unfinished">Horizontal Constraint</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="66"/>
      <source>Parallel Constraint</source>
      <translation type="unfinished">Parallel Constraint</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="67"/>
      <source>Perpendicular Constraint</source>
      <translation type="unfinished">Perpendicular Constraint</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="68"/>
      <source>Tangent Constraint</source>
      <translation type="unfinished">Tangent Constraint</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="69"/>
      <source>Equal Length</source>
      <translation type="unfinished">Equal Length</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="70"/>
      <source>Symmetric</source>
      <translation type="unfinished">Symmetric</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="71"/>
      <source>Block Constraint</source>
      <translation type="unfinished">Block Constraint</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="72"/>
      <source>Lock Constraint</source>
      <translation type="unfinished">Lock Constraint</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="73"/>
      <source>Horizontal Distance</source>
      <translation type="unfinished">Horizontal Distance</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="74"/>
      <source>Vertical Distance</source>
      <translation type="unfinished">Vertical Distance</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="75"/>
      <source>Length Constraint</source>
      <translation type="unfinished">Length Constraint</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="76"/>
      <source>Radius Constraint</source>
      <translation type="unfinished">Radius Constraint</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="77"/>
      <source>Diameter Constraint</source>
      <translation type="unfinished">Diameter Constraint</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="78"/>
      <source>Radiam Constraint</source>
      <translation type="unfinished">Radiam Constraint</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="79"/>
      <source>Angle Constraint</source>
      <translation type="unfinished">Angle Constraint</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="80"/>
      <source>Toggle construction geometry</source>
      <translation type="unfinished">Toggle construction geometry</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="81"/>
      <source>Select Constraints</source>
      <translation type="unfinished">Select Constraints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="82"/>
      <source>Select Origin</source>
      <translation type="unfinished">Select Origin</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="83"/>
      <source>Select Horizontal Axis</source>
      <translation type="unfinished">Select Horizontal Axis</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="84"/>
      <source>Select Vertical Axis</source>
      <translation type="unfinished">Select Vertical Axis</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="783"/>
      <source>Layer</source>
      <translation type="unfinished">Layer</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="793"/>
      <source>Layer 0</source>
      <translation type="unfinished">Layer 0</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="794"/>
      <source>Layer 1</source>
      <translation type="unfinished">Layer 1</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="795"/>
      <source>Hidden</source>
      <translation type="unfinished">Hidden</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="800"/>
      <source>Delete</source>
      <translation type="unfinished">Delete</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::ExternalSelection</name>
    <message>
      <location filename="../../DrawSketchHandlerExternal.h" line="70"/>
      <source>Linking this will cause circular dependency.</source>
      <translation type="unfinished">Linking this will cause circular dependency.</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerExternal.h" line="73"/>
      <source>This object is in another document.</source>
      <translation type="unfinished">This object is in another document.</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerExternal.h" line="77"/>
      <source>This object belongs to another body, can't link.</source>
      <translation type="unfinished">This object belongs to another body, can't link.</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerExternal.h" line="81"/>
      <source>This object belongs to another part, can't link.</source>
      <translation type="unfinished">This object belongs to another part, can't link.</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::InsertDatum</name>
    <message>
      <location filename="../../InsertDatum.ui" line="23"/>
      <source>Insert datum</source>
      <translation type="unfinished">Insert datum</translation>
    </message>
    <message>
      <location filename="../../InsertDatum.ui" line="31"/>
      <source>datum:</source>
      <translation type="unfinished">datum:</translation>
    </message>
    <message>
      <location filename="../../InsertDatum.ui" line="48"/>
      <source>Name (optional)</source>
      <translation type="unfinished">Name (optional)</translation>
    </message>
    <message>
      <location filename="../../InsertDatum.ui" line="61"/>
      <source>Constraint name (available for expressions)</source>
      <translation type="unfinished">Constraint name (available for expressions)</translation>
    </message>
    <message>
      <location filename="../../InsertDatum.ui" line="76"/>
      <source>Reference (or constraint) dimension</source>
      <translation type="unfinished">Reference (or constraint) dimension</translation>
    </message>
    <message>
      <location filename="../../InsertDatum.ui" line="79"/>
      <source>Reference</source>
      <translation type="unfinished">Reference</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::PropertyConstraintListItem</name>
    <message>
      <location filename="../../PropertyConstraintListItem.cpp" line="131"/>
      <location filename="../../PropertyConstraintListItem.cpp" line="188"/>
      <source>Unnamed</source>
      <translation type="unfinished">Unnamed</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::SketchMirrorDialog</name>
    <message>
      <location filename="../../SketchMirrorDialog.ui" line="14"/>
      <location filename="../../SketchMirrorDialog.ui" line="20"/>
      <source>Select Mirror Axis/Point</source>
      <translation type="unfinished">Select Mirror Axis/Point</translation>
    </message>
    <message>
      <location filename="../../SketchMirrorDialog.ui" line="26"/>
      <source>X-Axis</source>
      <translation type="unfinished">X-Axis</translation>
    </message>
    <message>
      <location filename="../../SketchMirrorDialog.ui" line="36"/>
      <source>Y-Axis</source>
      <translation type="unfinished">Y-Axis</translation>
    </message>
    <message>
      <location filename="../../SketchMirrorDialog.ui" line="43"/>
      <source>Origin</source>
      <translation type="unfinished">Origin</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::SketchOrientationDialog</name>
    <message>
      <location filename="../../SketchOrientationDialog.ui" line="14"/>
      <source>Choose orientation</source>
      <translation type="unfinished">Choose orientation</translation>
    </message>
    <message>
      <location filename="../../SketchOrientationDialog.ui" line="20"/>
      <source>Sketch orientation</source>
      <translation type="unfinished">Sketch orientation</translation>
    </message>
    <message>
      <location filename="../../SketchOrientationDialog.ui" line="26"/>
      <source>XY-Plane</source>
      <translation type="unfinished">XY-Plane</translation>
    </message>
    <message>
      <location filename="../../SketchOrientationDialog.ui" line="36"/>
      <source>XZ-Plane</source>
      <translation type="unfinished">XZ-Plane</translation>
    </message>
    <message>
      <location filename="../../SketchOrientationDialog.ui" line="43"/>
      <source>YZ-Plane</source>
      <translation type="unfinished">YZ-Plane</translation>
    </message>
    <message>
      <location filename="../../SketchOrientationDialog.ui" line="72"/>
      <source>Reverse direction</source>
      <translation type="unfinished">Reverse direction</translation>
    </message>
    <message>
      <location filename="../../SketchOrientationDialog.ui" line="81"/>
      <source>Offset:</source>
      <translation type="unfinished">Offset:</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::SketchRectangularArrayDialog</name>
    <message>
      <location filename="../../SketchRectangularArrayDialog.ui" line="17"/>
      <source>Create array</source>
      <translation type="unfinished">Create array</translation>
    </message>
    <message>
      <location filename="../../SketchRectangularArrayDialog.ui" line="25"/>
      <source>Columns:</source>
      <translation type="unfinished">Columns:</translation>
    </message>
    <message>
      <location filename="../../SketchRectangularArrayDialog.ui" line="32"/>
      <source>Number of columns of the linear array</source>
      <translation type="unfinished">Number of columns of the linear array</translation>
    </message>
    <message>
      <location filename="../../SketchRectangularArrayDialog.ui" line="52"/>
      <source>Rows:</source>
      <translation type="unfinished">Rows:</translation>
    </message>
    <message>
      <location filename="../../SketchRectangularArrayDialog.ui" line="59"/>
      <source>Number of rows of the linear array</source>
      <translation type="unfinished">Number of rows of the linear array</translation>
    </message>
    <message>
      <location filename="../../SketchRectangularArrayDialog.ui" line="77"/>
      <source>Makes the inter-row and inter-col spacing the same if clicked</source>
      <translation type="unfinished">Makes the inter-row and inter-col spacing the same if clicked</translation>
    </message>
    <message>
      <location filename="../../SketchRectangularArrayDialog.ui" line="80"/>
      <source>Equal vertical/horizontal spacing</source>
      <translation type="unfinished">Equal vertical/horizontal spacing</translation>
    </message>
    <message>
      <location filename="../../SketchRectangularArrayDialog.ui" line="93"/>
      <source>If selected, each element in the array is constrained
with respect to the others using construction lines</source>
      <translation type="unfinished">If selected, each element in the array is constrained
with respect to the others using construction lines</translation>
    </message>
    <message>
      <location filename="../../SketchRectangularArrayDialog.ui" line="100"/>
      <source>Constrain inter-element separation</source>
      <translation type="unfinished">Constrain inter-element separation</translation>
    </message>
    <message>
      <location filename="../../SketchRectangularArrayDialog.ui" line="116"/>
      <source>If selected, it substitutes dimensional constraints by geometric constraints
in the copies, so that a change in the original element is directly
reflected on copies</source>
      <translation type="unfinished">If selected, it substitutes dimensional constraints by geometric constraints
in the copies, so that a change in the original element is directly
reflected on copies</translation>
    </message>
    <message>
      <location filename="../../SketchRectangularArrayDialog.ui" line="121"/>
      <source>Clone</source>
      <translation type="unfinished">Clone</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::SketcherRegularPolygonDialog</name>
    <message>
      <location filename="../../SketcherRegularPolygonDialog.ui" line="17"/>
      <source>Create regular polygon</source>
      <translation type="unfinished">Create regular polygon</translation>
    </message>
    <message>
      <location filename="../../SketcherRegularPolygonDialog.ui" line="25"/>
      <source>Number of sides:</source>
      <translation type="unfinished">Number of sides:</translation>
    </message>
    <message>
      <location filename="../../SketcherRegularPolygonDialog.ui" line="32"/>
      <source>Number of columns of the linear array</source>
      <translation type="unfinished">Number of columns of the linear array</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::SketcherSettings</name>
    <message>
      <location filename="../../SketcherSettings.ui" line="14"/>
      <location filename="../../SketcherSettings.ui" line="102"/>
      <source>General</source>
      <translation type="unfinished">General</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="20"/>
      <source>Task panel widgets</source>
      <translation type="unfinished">Task panel widgets</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="26"/>
      <source>Sketcher dialog will have additional section
'Advanced solver control' to adjust solver settings</source>
      <translation type="unfinished">Sketcher dialog will have additional section
'Advanced solver control' to adjust solver settings</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="30"/>
      <source>Show section 'Advanced solver control'</source>
      <translation type="unfinished">Show section 'Advanced solver control'</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="46"/>
      <source>Dragging performance</source>
      <translation type="unfinished">Dragging performance</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="52"/>
      <source>Special solver algorithm will be used while dragging sketch elements.
Requires to re-enter edit mode to take effect.</source>
      <translation type="unfinished">Special solver algorithm will be used while dragging sketch elements.
Requires to re-enter edit mode to take effect.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="56"/>
      <source>Improve solving while dragging</source>
      <translation type="unfinished">Improve solving while dragging</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="108"/>
      <source>New constraints that would be redundant will automatically be removed</source>
      <translation type="unfinished">New constraints that would be redundant will automatically be removed</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="111"/>
      <source>Auto remove redundants</source>
      <translation type="unfinished">Auto remove redundants</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="127"/>
      <source>Allow to leave sketch edit mode when pressing Esc button</source>
      <translation type="unfinished">Allow to leave sketch edit mode when pressing Esc button</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="130"/>
      <source>Esc can leave sketch edit mode</source>
      <translation type="unfinished">Esc can leave sketch edit mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="146"/>
      <source>Disables the shaded view when entering the sketch edit mode.</source>
      <translation type="unfinished">Disables the shaded view when entering the sketch edit mode.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="149"/>
      <source>Disable shading in edit mode</source>
      <translation type="unfinished">Disable shading in edit mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="165"/>
      <source>Notifies about automatic constraint substitutions</source>
      <translation type="unfinished">Notifies about automatic constraint substitutions</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="168"/>
      <source>Notify automatic constraint substitutions</source>
      <translation type="unfinished">Notify automatic constraint substitutions</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="184"/>
      <source>Unify Coincident and PointOnObject in a single tool.</source>
      <translation type="unfinished">Unify Coincident and PointOnObject in a single tool.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="187"/>
      <source>Unify Coincident and PointOnObject</source>
      <translation type="unfinished">Unify Coincident and PointOnObject</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="203"/>
      <source>Use the automatic horizontal/vertical constraint tool. This create a command group in which you have the auto tool, horizontal and vertical.</source>
      <translation type="unfinished">Use the automatic horizontal/vertical constraint tool. This create a command group in which you have the auto tool, horizontal and vertical.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="206"/>
      <source>Auto tool for Horizontal/Vertical</source>
      <translation type="unfinished">Auto tool for Horizontal/Vertical</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="222"/>
      <source>If checked then external geometry is always added as reference, otherwise it's added according to the current construction mode.</source>
      <translation type="unfinished">If checked then external geometry is always added as reference, otherwise it's added according to the current construction mode.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="225"/>
      <source>Always add external geometry as reference</source>
      <translation type="unfinished">Always add external geometry as reference</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="250"/>
      <source>Dimension constraint</source>
      <translation type="unfinished">Dimension constraint</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="263"/>
      <source>Select the type of dimensioning constraints for your toolbar:
'Single tool': A single tool for all dimensioning constraints in the toolbar: Distance, Distance X / Y, Angle, Radius. (Others in dropdown)
'Separated tools': Individual tools for each dimensioning constraint.
'Both': You will have both the 'Dimension' tool and the separated tools.
This setting is only for the toolbar. Whichever you choose, all tools are always available in the menu and through shortcuts.</source>
      <translation type="unfinished">Select the type of dimensioning constraints for your toolbar:
'Single tool': A single tool for all dimensioning constraints in the toolbar: Distance, Distance X / Y, Angle, Radius. (Others in dropdown)
'Separated tools': Individual tools for each dimensioning constraint.
'Both': You will have both the 'Dimension' tool and the separated tools.
This setting is only for the toolbar. Whichever you choose, all tools are always available in the menu and through shortcuts.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="281"/>
      <source>While using the Dimension tool you may choose how to handle circles and arcs:
'Auto': The tool will apply radius to arcs and diameter to circles.
'Diameter': The tool will apply diameter to both arcs and circles.
'Radius': The tool will apply radius to both arcs and circles.</source>
      <translation type="unfinished">While using the Dimension tool you may choose how to handle circles and arcs:
'Auto': The tool will apply radius to arcs and diameter to circles.
'Diameter': The tool will apply diameter to both arcs and circles.
'Radius': The tool will apply radius to both arcs and circles.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="300"/>
      <source>Tool parameters</source>
      <translation type="unfinished">Tool parameters</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="306"/>
      <source>On-View-Parameters:</source>
      <translation type="unfinished">On-View-Parameters:</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="256"/>
      <source>Dimensioning constraints:</source>
      <translation type="unfinished">Dimensioning constraints:</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="274"/>
      <source>Dimension tool diameter/radius mode:</source>
      <translation type="unfinished">Dimension tool diameter/radius mode:</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.ui" line="313"/>
      <source>Choose a visibility mode for the On-View-Parameters:
'Disabled': On-View-Parameters are completely disabled.
'Only dimensional': Only dimensional On-View-Parameters are visible. They are the most useful. For example the radius of a circle.
'All': Both dimensional and positional On-View-Parameters. Positionals are the (x,y) position of the cursor. For example for the center of a circle.</source>
      <translation type="unfinished">Choose a visibility mode for the On-View-Parameters:
'Disabled': On-View-Parameters are completely disabled.
'Only dimensional': Only dimensional On-View-Parameters are visible. They are the most useful. For example the radius of a circle.
'All': Both dimensional and positional On-View-Parameters. Positionals are the (x,y) position of the cursor. For example for the center of a circle.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.cpp" line="194"/>
      <source>Single tool</source>
      <translation type="unfinished">Single tool</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.cpp" line="195"/>
      <source>Separated tools</source>
      <translation type="unfinished">Separated tools</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.cpp" line="196"/>
      <source>Both</source>
      <translation type="unfinished">Both</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.cpp" line="214"/>
      <source>Auto</source>
      <translation type="unfinished">Auto</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.cpp" line="215"/>
      <source>Diameter</source>
      <translation type="unfinished">Diameter</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.cpp" line="216"/>
      <source>Radius</source>
      <translation type="unfinished">Radius</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.cpp" line="226"/>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.cpp" line="227"/>
      <source>Dimensions only</source>
      <translation type="unfinished">Dimensions only</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.cpp" line="228"/>
      <source>Position and dimensions</source>
      <translation type="unfinished">Position and dimensions</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::SketcherSettingsDisplay</name>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="14"/>
      <source>Display</source>
      <translation type="unfinished">Display</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="20"/>
      <source>Sketch editing</source>
      <translation type="unfinished">Sketch editing</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="208"/>
      <source>Font size</source>
      <translation type="unfinished">Font size</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="160"/>
      <source>Font size used for labels and constraints.</source>
      <translation type="unfinished">Font size used for labels and constraints.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="163"/>
      <source>px</source>
      <translation type="unfinished">px</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="32"/>
      <source>View scale ratio</source>
      <translation type="unfinished">View scale ratio</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="42"/>
      <source>The 3D view is scaled based on this factor.</source>
      <translation type="unfinished">The 3D view is scaled based on this factor.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="185"/>
      <source>Base length units will not be displayed in constraints or cursor coordinates.
Supports all unit systems except 'US customary' and 'Building US/Euro'.</source>
      <translation type="unfinished">Base length units will not be displayed in constraints or cursor coordinates.
Supports all unit systems except 'US customary' and 'Building US/Euro'.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="131"/>
      <source>Segments per geometry</source>
      <translation type="unfinished">Segments per geometry</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="73"/>
      <source>The number of polygons used for geometry approximation.</source>
      <translation type="unfinished">The number of polygons used for geometry approximation.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="237"/>
      <source>Cursor position coordinates will be displayed beside cursor while editing sketch.</source>
      <translation type="unfinished">Cursor position coordinates will be displayed beside cursor while editing sketch.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="256"/>
      <source>A dialog will pop up to input a value for new dimensional constraints.</source>
      <translation type="unfinished">A dialog will pop up to input a value for new dimensional constraints.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="259"/>
      <source>Ask for value after creating a dimensional constraint</source>
      <translation type="unfinished">Ask for value after creating a dimensional constraint</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="141"/>
      <source>The current sketcher creation tool will remain active after creation.</source>
      <translation type="unfinished">The current sketcher creation tool will remain active after creation.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="144"/>
      <source>Geometry creation "Continue Mode"</source>
      <translation type="unfinished">Geometry creation "Continue Mode"</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="218"/>
      <source>The current constraint creation tool will remain active after creation.</source>
      <translation type="unfinished">The current constraint creation tool will remain active after creation.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="221"/>
      <source>Constraint creation "Continue Mode"</source>
      <translation type="unfinished">Constraint creation "Continue Mode"</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="189"/>
      <source>Hide base length units for supported unit systems</source>
      <translation type="unfinished">Hide base length units for supported unit systems</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="92"/>
      <source>If checked, displays the name on dimensional constraints (if exists).</source>
      <translation type="unfinished">If checked, displays the name on dimensional constraints (if exists).</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="95"/>
      <source>Show dimensional constraint name with format</source>
      <translation type="unfinished">Show dimensional constraint name with format</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="118"/>
      <source>%N = %V</source>
      <translation type="unfinished">%N = %V</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="108"/>
      <source>The format of the dimensional constraint string presentation.
Defaults to: %N = %V

%N - name parameter
%V - dimension value</source>
      <translation type="unfinished">The format of the dimensional constraint string presentation.
Defaults to: %N = %V

%N - name parameter
%V - dimension value</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="240"/>
      <source>Show coordinates beside cursor while editing</source>
      <translation type="unfinished">Show coordinates beside cursor while editing</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="275"/>
      <source>Cursor coordinates will use the system decimals setting instead of the short form.</source>
      <translation type="unfinished">Cursor coordinates will use the system decimals setting instead of the short form.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="278"/>
      <source>Use system decimals setting for cursor coordinates</source>
      <translation type="unfinished">Use system decimals setting for cursor coordinates</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="321"/>
      <source>Visibility automation</source>
      <translation type="unfinished">Visibility automation</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="327"/>
      <source>When opening a sketch, hide all features that depend on it.</source>
      <translation type="unfinished">When opening a sketch, hide all features that depend on it.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="330"/>
      <source>Hide all objects that depend on the sketch</source>
      <translation type="unfinished">Hide all objects that depend on the sketch</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="346"/>
      <source>When opening a sketch, show sources for external geometry links.</source>
      <translation type="unfinished">When opening a sketch, show sources for external geometry links.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="349"/>
      <source>Show objects used for external geometry</source>
      <translation type="unfinished">Show objects used for external geometry</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="365"/>
      <source>When opening a sketch, show objects the sketch is attached to.</source>
      <translation type="unfinished">When opening a sketch, show objects the sketch is attached to.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="368"/>
      <source>Show objects that the sketch is attached to</source>
      <translation type="unfinished">Show objects that the sketch is attached to</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="384"/>
      <source>When closing a sketch, move camera back to where it was before the sketch was opened.</source>
      <translation type="unfinished">When closing a sketch, move camera back to where it was before the sketch was opened.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="387"/>
      <source>Restore camera position after editing</source>
      <translation type="unfinished">Restore camera position after editing</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="403"/>
      <source>When entering edit mode, force orthographic view of camera.
Works only when "Restore camera position after editing" is enabled.</source>
      <translation type="unfinished">When entering edit mode, force orthographic view of camera.
Works only when "Restore camera position after editing" is enabled.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="407"/>
      <source>Force orthographic camera when entering edit</source>
      <translation type="unfinished">Force orthographic camera when entering edit</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="423"/>
      <source>Open a sketch in Section View mode by default.
Then objects are only visible behind the sketch plane.</source>
      <translation type="unfinished">Open a sketch in Section View mode by default.
Then objects are only visible behind the sketch plane.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="427"/>
      <source>Open sketch in Section View mode</source>
      <translation type="unfinished">Open sketch in Section View mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="449"/>
      <source>Note: these settings are defaults applied to new sketches. The behavior is remembered for each sketch individually as properties on the View tab.</source>
      <translation type="unfinished">Note: these settings are defaults applied to new sketches. The behavior is remembered for each sketch individually as properties on the View tab.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="468"/>
      <source>Applies current visibility automation settings to all sketches in open documents.</source>
      <translation type="unfinished">Applies current visibility automation settings to all sketches in open documents.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsDisplay.ui" line="471"/>
      <source>Apply to existing sketches</source>
      <translation type="unfinished">Apply to existing sketches</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.cpp" line="495"/>
      <source>Unexpected C++ exception</source>
      <translation type="unfinished">Unexpected C++ exception</translation>
    </message>
    <message>
      <location filename="../../SketcherSettings.cpp" line="498"/>
      <source>Sketcher</source>
      <translation type="unfinished">Sketcher</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::SketcherValidation</name>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="178"/>
      <source>No missing coincidences</source>
      <translation type="unfinished">No missing coincidences</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="179"/>
      <source>No missing coincidences found</source>
      <translation type="unfinished">No missing coincidences found</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="187"/>
      <source>Missing coincidences</source>
      <translation type="unfinished">Missing coincidences</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="188"/>
      <source>%1 missing coincidences found</source>
      <translation type="unfinished">%1 missing coincidences found</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="239"/>
      <source>No invalid constraints</source>
      <translation type="unfinished">No invalid constraints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="240"/>
      <source>No invalid constraints found</source>
      <translation type="unfinished">No invalid constraints found</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="246"/>
      <source>Invalid constraints</source>
      <translation type="unfinished">Invalid constraints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="247"/>
      <source>Invalid constraints found</source>
      <translation type="unfinished">Invalid constraints found</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="288"/>
      <location filename="../../TaskSketcherValidation.cpp" line="303"/>
      <location filename="../../TaskSketcherValidation.cpp" line="314"/>
      <location filename="../../TaskSketcherValidation.cpp" line="331"/>
      <source>Reversed external geometry</source>
      <translation type="unfinished">Reversed external geometry</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="289"/>
      <source>%1 reversed external-geometry arcs were found. Their endpoints are encircled in 3D view.

%2 constraints are linking to the endpoints. The constraints have been listed in Report view (menu View -&gt; Panels -&gt; Report view).

Click "Swap endpoints in constraints" button to reassign endpoints. Do this only once to sketches created in FreeCAD older than v0.15</source>
      <translation type="unfinished">%1 reversed external-geometry arcs were found. Their endpoints are encircled in 3D view.

%2 constraints are linking to the endpoints. The constraints have been listed in Report view (menu View -&gt; Panels -&gt; Report view).

Click "Swap endpoints in constraints" button to reassign endpoints. Do this only once to sketches created in FreeCAD older than v0.15</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="304"/>
      <source>%1 reversed external-geometry arcs were found. Their endpoints are encircled in 3D view.

However, no constraints linking to the endpoints were found.</source>
      <translation type="unfinished">%1 reversed external-geometry arcs were found. Their endpoints are encircled in 3D view.

However, no constraints linking to the endpoints were found.</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="315"/>
      <source>No reversed external-geometry arcs were found.</source>
      <translation type="unfinished">No reversed external-geometry arcs were found.</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="332"/>
      <source>%1 changes were made to constraints linking to endpoints of reversed arcs.</source>
      <translation type="unfinished">%1 changes were made to constraints linking to endpoints of reversed arcs.</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="352"/>
      <location filename="../../TaskSketcherValidation.cpp" line="373"/>
      <source>Constraint orientation locking</source>
      <translation type="unfinished">Constraint orientation locking</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="353"/>
      <source>Orientation locking was enabled and recomputed for %1 constraints. The constraints have been listed in Report view (menu View -&gt; Panels -&gt; Report view).</source>
      <translation type="unfinished">Orientation locking was enabled and recomputed for %1 constraints. The constraints have been listed in Report view (menu View -&gt; Panels -&gt; Report view).</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="374"/>
      <source>Orientation locking was disabled for %1 constraints. The constraints have been listed in Report view (menu View -&gt; Panels -&gt; Report view). Note that for all future constraints, the locking still defaults to ON.</source>
      <translation type="unfinished">Orientation locking was disabled for %1 constraints. The constraints have been listed in Report view (menu View -&gt; Panels -&gt; Report view). Note that for all future constraints, the locking still defaults to ON.</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="391"/>
      <location filename="../../TaskSketcherValidation.cpp" line="410"/>
      <source>Delete constraints to external geom.</source>
      <translation type="unfinished">Delete constraints to external geom.</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="392"/>
      <source>You are about to delete ALL constraints that deal with external geometry. This is useful to rescue a sketch with broken/changed links to external geometry. Are you sure you want to delete the constraints?</source>
      <translation type="unfinished">You are about to delete ALL constraints that deal with external geometry. This is useful to rescue a sketch with broken/changed links to external geometry. Are you sure you want to delete the constraints?</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="411"/>
      <source>All constraints that deal with external geometry were deleted.</source>
      <translation type="unfinished">All constraints that deal with external geometry were deleted.</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="480"/>
      <source>No degenerated geometry</source>
      <translation type="unfinished">No degenerated geometry</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="481"/>
      <source>No degenerated geometry found</source>
      <translation type="unfinished">No degenerated geometry found</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="487"/>
      <source>Degenerated geometry</source>
      <translation type="unfinished">Degenerated geometry</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.cpp" line="488"/>
      <source>%1 degenerated geometry found</source>
      <translation type="unfinished">%1 degenerated geometry found</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::TaskSketcherConstraints</name>
    <message>
      <location filename="../../TaskSketcherConstraints.ui" line="40"/>
      <source>Check to toggle filters</source>
      <translation type="unfinished">Check to toggle filters</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.ui" line="59"/>
      <source>Click to show filters</source>
      <translation type="unfinished">Click to show filters</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.ui" line="65"/>
      <source>Filters</source>
      <translation type="unfinished">Filters</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.ui" line="87"/>
      <source>Show/hide all listed constraints from 3D view. (same as ticking/unticking all listed constraints in list below)</source>
      <translation type="unfinished">Show/hide all listed constraints from 3D view. (same as ticking/unticking all listed constraints in list below)</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.ui" line="107"/>
      <source>Settings</source>
      <translation type="unfinished">Settings</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="817"/>
      <source>Constraints</source>
      <translation type="unfinished">Constraints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="843"/>
      <source>Auto constraints</source>
      <translation type="unfinished">Auto constraints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="844"/>
      <source>Auto remove redundants</source>
      <translation type="unfinished">Auto remove redundants</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="845"/>
      <source>Show only filtered Constraints</source>
      <translation type="unfinished">Show only filtered Constraints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="846"/>
      <source>Extended information (in widget)</source>
      <translation type="unfinished">Extended information (in widget)</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="847"/>
      <source>Hide internal alignment (in widget)</source>
      <translation type="unfinished">Hide internal alignment (in widget)</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="1150"/>
      <location filename="../../TaskSketcherConstraints.cpp" line="1543"/>
      <source>Error</source>
      <translation type="unfinished">Error</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="1150"/>
      <source>Impossible to update visibility tracking</source>
      <translation type="unfinished">Impossible to update visibility tracking</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="1543"/>
      <source>Impossible to update visibility tracking:</source>
      <translation type="unfinished">Impossible to update visibility tracking:</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::TaskSketcherElements</name>
    <message>
      <location filename="../../TaskSketcherElements.ui" line="40"/>
      <source>Check to toggle filters</source>
      <translation type="unfinished">Check to toggle filters</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.ui" line="59"/>
      <source>Click to show filters</source>
      <translation type="unfinished">Click to show filters</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.ui" line="65"/>
      <source>Filters</source>
      <translation type="unfinished">Filters</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.ui" line="81"/>
      <source>Settings</source>
      <translation type="unfinished">Settings</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="1829"/>
      <location filename="../../TaskSketcherElements.cpp" line="1836"/>
      <location filename="../../TaskSketcherElements.cpp" line="1843"/>
      <location filename="../../TaskSketcherElements.cpp" line="1850"/>
      <location filename="../../TaskSketcherElements.cpp" line="1857"/>
      <location filename="../../TaskSketcherElements.cpp" line="1864"/>
      <location filename="../../TaskSketcherElements.cpp" line="1871"/>
      <location filename="../../TaskSketcherElements.cpp" line="1878"/>
      <location filename="../../TaskSketcherElements.cpp" line="1885"/>
      <location filename="../../TaskSketcherElements.cpp" line="1891"/>
      <source>Construction</source>
      <translation type="unfinished">Construction</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="1185"/>
      <source>Elements</source>
      <translation type="unfinished">Elements</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="1827"/>
      <location filename="../../TaskSketcherElements.cpp" line="1832"/>
      <location filename="../../TaskSketcherElements.cpp" line="1968"/>
      <location filename="../../TaskSketcherElements.cpp" line="1969"/>
      <source>Point</source>
      <translation type="unfinished">Point</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="1830"/>
      <location filename="../../TaskSketcherElements.cpp" line="1837"/>
      <location filename="../../TaskSketcherElements.cpp" line="1844"/>
      <location filename="../../TaskSketcherElements.cpp" line="1851"/>
      <location filename="../../TaskSketcherElements.cpp" line="1858"/>
      <location filename="../../TaskSketcherElements.cpp" line="1865"/>
      <location filename="../../TaskSketcherElements.cpp" line="1872"/>
      <location filename="../../TaskSketcherElements.cpp" line="1879"/>
      <location filename="../../TaskSketcherElements.cpp" line="1886"/>
      <location filename="../../TaskSketcherElements.cpp" line="1892"/>
      <source>Internal</source>
      <translation type="unfinished">Internal</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="1834"/>
      <location filename="../../TaskSketcherElements.cpp" line="1839"/>
      <location filename="../../TaskSketcherElements.cpp" line="1971"/>
      <location filename="../../TaskSketcherElements.cpp" line="1972"/>
      <source>Line</source>
      <translation>Linija</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="1841"/>
      <location filename="../../TaskSketcherElements.cpp" line="1846"/>
      <location filename="../../TaskSketcherElements.cpp" line="1974"/>
      <location filename="../../TaskSketcherElements.cpp" line="1975"/>
      <source>Arc</source>
      <translation>Luk</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="1848"/>
      <location filename="../../TaskSketcherElements.cpp" line="1853"/>
      <location filename="../../TaskSketcherElements.cpp" line="1977"/>
      <location filename="../../TaskSketcherElements.cpp" line="1978"/>
      <source>Circle</source>
      <translation type="unfinished">Circle</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="1855"/>
      <location filename="../../TaskSketcherElements.cpp" line="1860"/>
      <location filename="../../TaskSketcherElements.cpp" line="1980"/>
      <location filename="../../TaskSketcherElements.cpp" line="1981"/>
      <source>Ellipse</source>
      <translation type="unfinished">Ellipse</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="1862"/>
      <location filename="../../TaskSketcherElements.cpp" line="1867"/>
      <location filename="../../TaskSketcherElements.cpp" line="1984"/>
      <location filename="../../TaskSketcherElements.cpp" line="1985"/>
      <source>Elliptical Arc</source>
      <translation type="unfinished">Elliptical Arc</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="1869"/>
      <location filename="../../TaskSketcherElements.cpp" line="1874"/>
      <location filename="../../TaskSketcherElements.cpp" line="1988"/>
      <location filename="../../TaskSketcherElements.cpp" line="1989"/>
      <source>Hyperbolic Arc</source>
      <translation type="unfinished">Hyperbolic Arc</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="1876"/>
      <location filename="../../TaskSketcherElements.cpp" line="1881"/>
      <location filename="../../TaskSketcherElements.cpp" line="1992"/>
      <location filename="../../TaskSketcherElements.cpp" line="1993"/>
      <source>Parabolic Arc</source>
      <translation type="unfinished">Parabolic Arc</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="1883"/>
      <location filename="../../TaskSketcherElements.cpp" line="1888"/>
      <location filename="../../TaskSketcherElements.cpp" line="1995"/>
      <location filename="../../TaskSketcherElements.cpp" line="1996"/>
      <source>B-spline</source>
      <translation type="unfinished">B-spline</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="1889"/>
      <location filename="../../TaskSketcherElements.cpp" line="1894"/>
      <location filename="../../TaskSketcherElements.cpp" line="1997"/>
      <location filename="../../TaskSketcherElements.cpp" line="1998"/>
      <source>Other</source>
      <translation type="unfinished">Other</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherElements.cpp" line="2038"/>
      <source>Extended information</source>
      <translation type="unfinished">Extended information</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::TaskSketcherMessages</name>
    <message>
      <location filename="../../TaskSketcherMessages.cpp" line="44"/>
      <source>Solver messages</source>
      <translation type="unfinished">Solver messages</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherMessages.cpp" line="99"/>
      <source>Auto update</source>
      <translation type="unfinished">Auto update</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherMessages.cpp" line="100"/>
      <source>Executes a recomputation of active document after every sketch action</source>
      <translation type="unfinished">Executes a recomputation of active document after every sketch action</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherMessages.cpp" line="142"/>
      <source>Click to select these conflicting constraints.</source>
      <translation type="unfinished">Click to select these conflicting constraints.</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherMessages.cpp" line="144"/>
      <source>Click to select these redundant constraints.</source>
      <translation type="unfinished">Click to select these redundant constraints.</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherMessages.cpp" line="147"/>
      <source>The sketch has unconstrained elements giving rise to those Degrees Of Freedom. Click to select these unconstrained elements.</source>
      <translation type="unfinished">The sketch has unconstrained elements giving rise to those Degrees Of Freedom. Click to select these unconstrained elements.</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherMessages.cpp" line="150"/>
      <source>Click to select these malformed constraints.</source>
      <translation type="unfinished">Click to select these malformed constraints.</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherMessages.cpp" line="153"/>
      <source>Some constraints in combination are partially redundant. Click to select these partially redundant constraints.</source>
      <translation type="unfinished">Some constraints in combination are partially redundant. Click to select these partially redundant constraints.</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::TaskSketcherSolverAdvanced</name>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.cpp" line="58"/>
      <source>Advanced solver control</source>
      <translation type="unfinished">Advanced solver control</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::TaskSketcherValidation</name>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="14"/>
      <source>Sketcher validation</source>
      <translation type="unfinished">Sketcher validation</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="20"/>
      <source>Open and non-manifold vertexes</source>
      <translation type="unfinished">Open and non-manifold vertexes</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="38"/>
      <source>Highlights open and non-manifold vertexes that could lead to error if sketch is used to generate solids
This is purely based on topological shape of the sketch and not on its geometry/constrain set.</source>
      <translation type="unfinished">Highlights open and non-manifold vertexes that could lead to error if sketch is used to generate solids
This is purely based on topological shape of the sketch and not on its geometry/constrain set.</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="42"/>
      <source>Highlight troublesome vertexes</source>
      <translation type="unfinished">Highlight troublesome vertexes</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="52"/>
      <source>Fixes found missing coincidences by adding extra coincident constrains</source>
      <translation type="unfinished">Fixes found missing coincidences by adding extra coincident constrains</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="55"/>
      <source>Missing coincidences</source>
      <translation type="unfinished">Missing coincidences</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="61"/>
      <source>Tolerance:</source>
      <translation type="unfinished">Tolerance:</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="68"/>
      <source>Defines the X/Y tolerance inside which missing coincidences are searched.</source>
      <translation type="unfinished">Defines the X/Y tolerance inside which missing coincidences are searched.</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="75"/>
      <source>If checked, construction geometries are ignored in the search</source>
      <translation type="unfinished">If checked, construction geometries are ignored in the search</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="78"/>
      <source>Ignore construction geometry</source>
      <translation type="unfinished">Ignore construction geometry</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="88"/>
      <source>Finds and displays missing coincidences in the sketch.
This is done by analyzing the sketch geometries and constraints.</source>
      <translation type="unfinished">Finds and displays missing coincidences in the sketch.
This is done by analyzing the sketch geometries and constraints.</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="92"/>
      <location filename="../../TaskSketcherValidation.ui" line="118"/>
      <location filename="../../TaskSketcherValidation.ui" line="157"/>
      <location filename="../../TaskSketcherValidation.ui" line="186"/>
      <source>Find</source>
      <translation type="unfinished">Find</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="99"/>
      <location filename="../../TaskSketcherValidation.ui" line="128"/>
      <location filename="../../TaskSketcherValidation.ui" line="167"/>
      <source>Fix</source>
      <translation type="unfinished">Fix</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="109"/>
      <source>Invalid constraints</source>
      <translation type="unfinished">Invalid constraints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="115"/>
      <source>Finds invalid/malformed constrains in the sketch</source>
      <translation type="unfinished">Finds invalid/malformed constrains in the sketch</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="125"/>
      <source>Tries to fix found invalid constraints</source>
      <translation type="unfinished">Tries to fix found invalid constraints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="135"/>
      <source>Deletes constraints referring to external geometry</source>
      <translation type="unfinished">Deletes constraints referring to external geometry</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="138"/>
      <source>Delete constraints to external geom.</source>
      <translation type="unfinished">Delete constraints to external geom.</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="148"/>
      <source>Degenerated geometry</source>
      <translation type="unfinished">Degenerated geometry</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="154"/>
      <source>Finds degenerated geometries in the sketch</source>
      <translation type="unfinished">Finds degenerated geometries in the sketch</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="164"/>
      <source>Tries to fix found degenerated geometries</source>
      <translation type="unfinished">Tries to fix found degenerated geometries</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="177"/>
      <source>Reversed external geometry</source>
      <translation type="unfinished">Reversed external geometry</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="183"/>
      <source>Finds reversed external geometries</source>
      <translation type="unfinished">Finds reversed external geometries</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="193"/>
      <source>Fixes found reversed external geometries by swapping their endpoints</source>
      <translation type="unfinished">Fixes found reversed external geometries by swapping their endpoints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="196"/>
      <source>Swap endpoints in constraints</source>
      <translation type="unfinished">Swap endpoints in constraints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="206"/>
      <source>Constraint orientation locking</source>
      <translation type="unfinished">Constraint orientation locking</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="212"/>
      <source>Enables/updates constraint orientation locking</source>
      <translation type="unfinished">Enables/updates constraint orientation locking</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="215"/>
      <source>Enable/Update</source>
      <translation type="unfinished">Enable/Update</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="222"/>
      <source>Disables constraint orientation locking</source>
      <translation type="unfinished">Disables constraint orientation locking</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherValidation.ui" line="225"/>
      <source>Disable</source>
      <translation type="unfinished">Disable</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::ViewProviderSketch</name>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="2968"/>
      <source>Edit sketch</source>
      <translation type="unfinished">Edit sketch</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="2985"/>
      <source>A dialog is already open in the task panel</source>
      <translation type="unfinished">A dialog is already open in the task panel</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="2986"/>
      <source>Do you want to close this dialog?</source>
      <translation type="unfinished">Do you want to close this dialog?</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3005"/>
      <source>Invalid sketch</source>
      <translation type="unfinished">Invalid sketch</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3006"/>
      <source>Do you want to open the sketch validation tool?</source>
      <translation type="unfinished">Do you want to open the sketch validation tool?</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3007"/>
      <source>The sketch is invalid and cannot be edited.</source>
      <translation type="unfinished">The sketch is invalid and cannot be edited.</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3151"/>
      <source>Please remove the following constraint:</source>
      <translation type="unfinished">Please remove the following constraint:</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3152"/>
      <source>Please remove at least one of the following constraints:</source>
      <translation type="unfinished">Please remove at least one of the following constraints:</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3158"/>
      <source>Please remove the following redundant constraint:</source>
      <translation type="unfinished">Please remove the following redundant constraint:</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3159"/>
      <source>Please remove the following redundant constraints:</source>
      <translation type="unfinished">Please remove the following redundant constraints:</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3165"/>
      <source>The following constraint is partially redundant:</source>
      <translation type="unfinished">The following constraint is partially redundant:</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3166"/>
      <source>The following constraints are partially redundant:</source>
      <translation type="unfinished">The following constraints are partially redundant:</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3172"/>
      <source>Please remove the following malformed constraint:</source>
      <translation type="unfinished">Please remove the following malformed constraint:</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3173"/>
      <source>Please remove the following malformed constraints:</source>
      <translation type="unfinished">Please remove the following malformed constraints:</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3231"/>
      <source>Empty sketch</source>
      <translation type="unfinished">Empty sketch</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3236"/>
      <source>Over-constrained:</source>
      <translation type="unfinished">Over-constrained:</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3242"/>
      <source>Malformed constraints:</source>
      <translation type="unfinished">Malformed constraints:</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3250"/>
      <source>Redundant constraints:</source>
      <translation type="unfinished">Redundant constraints:</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3256"/>
      <source>Partially redundant:</source>
      <translation type="unfinished">Partially redundant:</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3263"/>
      <source>Solver failed to converge</source>
      <translation type="unfinished">Solver failed to converge</translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3269"/>
      <source>Under-constrained:</source>
      <translation type="unfinished">Under-constrained:</translation>
    </message>
    <message numerus="yes">
      <location filename="../../ViewProviderSketch.cpp" line="3271"/>
      <source>%n DoF(s)</source>
      <translation type="unfinished">
        <numerusform>%n DoF(s)</numerusform>
        <numerusform>%n DoF(s)</numerusform>
        <numerusform>%n DoF(s)</numerusform>
      </translation>
    </message>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3275"/>
      <source>Fully constrained</source>
      <translation type="unfinished">Fully constrained</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_BSplineComb</name>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="320"/>
      <location filename="../../CommandSketcherOverlay.cpp" line="323"/>
      <source>Switches between showing and hiding the curvature comb for all B-splines</source>
      <translation type="unfinished">Switches between showing and hiding the curvature comb for all B-splines</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_BSplineDecreaseKnotMultiplicity</name>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="714"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="717"/>
      <source>Decreases the multiplicity of the selected knot of a B-spline</source>
      <translation type="unfinished">Decreases the multiplicity of the selected knot of a B-spline</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_BSplineDegree</name>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="302"/>
      <location filename="../../CommandSketcherOverlay.cpp" line="305"/>
      <source>Switches between showing and hiding the degree for all B-splines</source>
      <translation type="unfinished">Switches between showing and hiding the degree for all B-splines</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_BSplineIncreaseKnotMultiplicity</name>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="705"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="708"/>
      <source>Increases the multiplicity of the selected knot of a B-spline</source>
      <translation type="unfinished">Increases the multiplicity of the selected knot of a B-spline</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_BSplineKnotMultiplicity</name>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="329"/>
      <location filename="../../CommandSketcherOverlay.cpp" line="332"/>
      <source>Switches between showing and hiding the knot multiplicity for all B-splines</source>
      <translation type="unfinished">Switches between showing and hiding the knot multiplicity for all B-splines</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_BSplinePoleWeight</name>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="339"/>
      <location filename="../../CommandSketcherOverlay.cpp" line="342"/>
      <source>Switches between showing and hiding the control point weight for all B-splines</source>
      <translation type="unfinished">Switches between showing and hiding the control point weight for all B-splines</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_BSplinePolygon</name>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="311"/>
      <location filename="../../CommandSketcherOverlay.cpp" line="314"/>
      <source>Switches between showing and hiding the control polygons for all B-splines</source>
      <translation type="unfinished">Switches between showing and hiding the control polygons for all B-splines</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_Clone</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1678"/>
      <location filename="../../CommandSketcherTools.cpp" line="1681"/>
      <source>Creates a clone of the geometry taking as reference the last selected point</source>
      <translation type="unfinished">Creates a clone of the geometry taking as reference the last selected point</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CompCopy</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1677"/>
      <source>Clone</source>
      <translation type="unfinished">Clone</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1685"/>
      <source>Copy</source>
      <translation type="unfinished">Copy</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1693"/>
      <source>Move</source>
      <translation>Pomjeriti</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_ConstrainDiameter</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="8620"/>
      <location filename="../../CommandConstraints.cpp" line="8622"/>
      <source>Fix the diameter of a circle or an arc</source>
      <translation type="unfinished">Fix the diameter of a circle or an arc</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_Copy</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1686"/>
      <location filename="../../CommandSketcherTools.cpp" line="1689"/>
      <source>Creates a simple copy of the geometry taking as reference the last selected point</source>
      <translation type="unfinished">Creates a simple copy of the geometry taking as reference the last selected point</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreateBSpline</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1116"/>
      <source>B-spline by control points</source>
      <translation type="unfinished">B-spline by control points</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1118"/>
      <location filename="../../CommandCreateGeo.cpp" line="1120"/>
      <source>Create a B-spline by control points</source>
      <translation type="unfinished">Create a B-spline by control points</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerBSpline.h" line="849"/>
      <source>By control points</source>
      <translation type="unfinished">By control points</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerBSpline.h" line="850"/>
      <source>By knots</source>
      <translation type="unfinished">By knots</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreateCircle</name>
    <message>
      <location filename="../../DrawSketchHandlerCircle.h" line="352"/>
      <source>Center</source>
      <translation type="unfinished">Center</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerCircle.h" line="353"/>
      <source>3 rim points</source>
      <translation type="unfinished">3 rim points</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreateHeptagon</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="2096"/>
      <location filename="../../CommandCreateGeo.cpp" line="2099"/>
      <source>Create a heptagon by its center and by one corner</source>
      <translation type="unfinished">Create a heptagon by its center and by one corner</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreateHexagon</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="2088"/>
      <location filename="../../CommandCreateGeo.cpp" line="2091"/>
      <source>Create a hexagon by its center and by one corner</source>
      <translation type="unfinished">Create a hexagon by its center and by one corner</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreateOblong</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="445"/>
      <source>Create a rounded rectangle</source>
      <translation type="unfinished">Create a rounded rectangle</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreateOctagon</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="2104"/>
      <location filename="../../CommandCreateGeo.cpp" line="2107"/>
      <source>Create an octagon by its center and by one corner</source>
      <translation type="unfinished">Create an octagon by its center and by one corner</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="2113"/>
      <location filename="../../CommandCreateGeo.cpp" line="2116"/>
      <source>Create a regular polygon by its center and by one corner</source>
      <translation type="unfinished">Create a regular polygon by its center and by one corner</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreatePentagon</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="2080"/>
      <location filename="../../CommandCreateGeo.cpp" line="2083"/>
      <source>Create a pentagon by its center and by one corner</source>
      <translation type="unfinished">Create a pentagon by its center and by one corner</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreateRectangle</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="433"/>
      <source>Create a rectangle</source>
      <translation type="unfinished">Create a rectangle</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreateRectangle_Center</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="439"/>
      <source>Create a centered rectangle</source>
      <translation type="unfinished">Create a centered rectangle</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreateSquare</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="2072"/>
      <location filename="../../CommandCreateGeo.cpp" line="2075"/>
      <source>Create a square by its center and by one corner</source>
      <translation type="unfinished">Create a square by its center and by one corner</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreateTriangle</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="2065"/>
      <location filename="../../CommandCreateGeo.cpp" line="2068"/>
      <source>Create an equilateral triangle by its center and by one corner</source>
      <translation type="unfinished">Create an equilateral triangle by its center and by one corner</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_Create_Periodic_BSpline</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1122"/>
      <source>Periodic B-spline by control points</source>
      <translation type="unfinished">Periodic B-spline by control points</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1125"/>
      <location filename="../../CommandCreateGeo.cpp" line="1128"/>
      <source>Create a periodic B-spline by control points</source>
      <translation type="unfinished">Create a periodic B-spline by control points</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_MapSketch</name>
    <message>
      <location filename="../../Command.cpp" line="601"/>
      <source>No sketch found</source>
      <translation type="unfinished">No sketch found</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="603"/>
      <source>Cannot attach sketch to itself!</source>
      <translation type="unfinished">Cannot attach sketch to itself!</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="604"/>
      <source>The document doesn't have a sketch</source>
      <translation type="unfinished">The document doesn't have a sketch</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="620"/>
      <source>Select sketch</source>
      <translation type="unfinished">Select sketch</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="622"/>
      <source>Select a sketch (some sketches not shown to prevent a circular dependency)</source>
      <translation type="unfinished">Select a sketch (some sketches not shown to prevent a circular dependency)</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="624"/>
      <source>Select a sketch from the list</source>
      <translation type="unfinished">Select a sketch from the list</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="689"/>
      <source> (incompatible with selection)</source>
      <translation type="unfinished"> (incompatible with selection)</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="690"/>
      <source> (current)</source>
      <translation type="unfinished"> (current)</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="698"/>
      <source> (suggested)</source>
      <translation type="unfinished"> (suggested)</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="705"/>
      <source>Sketch attachment</source>
      <translation type="unfinished">Sketch attachment</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="707"/>
      <source>Current attachment mode is incompatible with the new selection.
Select the method to attach this sketch to selected objects.</source>
      <translation type="unfinished">Current attachment mode is incompatible with the new selection.
Select the method to attach this sketch to selected objects.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="711"/>
      <source>Select the method to attach this sketch to selected objects.</source>
      <translation type="unfinished">Select the method to attach this sketch to selected objects.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="755"/>
      <source>Map sketch</source>
      <translation type="unfinished">Map sketch</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="756"/>
      <source>Can't map a sketch to support:
%1</source>
      <translation type="unfinished">Can't map a sketch to support:
%1</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_Move</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="1694"/>
      <location filename="../../CommandSketcherTools.cpp" line="1696"/>
      <source>Moves the geometry taking as reference the last selected point</source>
      <translation type="unfinished">Moves the geometry taking as reference the last selected point</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_NewSketch</name>
    <message>
      <location filename="../../Command.cpp" line="197"/>
      <source>Sketch attachment</source>
      <translation type="unfinished">Sketch attachment</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="198"/>
      <source>Select the method to attach this sketch to selected object</source>
      <translation type="unfinished">Select the method to attach this sketch to selected object</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_ReorientSketch</name>
    <message>
      <location filename="../../Command.cpp" line="431"/>
      <source>Sketch has support</source>
      <translation type="unfinished">Sketch has support</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="432"/>
      <source>Sketch with a support face cannot be reoriented.
Do you want to detach it from the support?</source>
      <translation type="unfinished">Sketch with a support face cannot be reoriented.
Do you want to detach it from the support?</translation>
    </message>
  </context>
  <context>
    <name>TaskSketcherMessages</name>
    <message>
      <location filename="../../TaskSketcherMessages.ui" line="20"/>
      <source>DOF</source>
      <translation type="unfinished">DOF</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherMessages.ui" line="27"/>
      <source>Link</source>
      <translation type="unfinished">Link</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherMessages.ui" line="40"/>
      <source>Forces recomputation of active document</source>
      <translation type="unfinished">Forces recomputation of active document</translation>
    </message>
  </context>
  <context>
    <name>TaskSketcherSolverAdvanced</name>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="22"/>
      <source>Default algorithm used for Sketch solving</source>
      <translation type="unfinished">Default algorithm used for Sketch solving</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="25"/>
      <source>Default solver:</source>
      <translation type="unfinished">Default solver:</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="32"/>
      <source>Solver is used for solving the geometry.
LevenbergMarquardt and DogLeg are trust region optimization algorithms.
BFGS solver uses the Broyden–Fletcher–Goldfarb–Shanno algorithm.</source>
      <translation type="unfinished">Solver is used for solving the geometry.
LevenbergMarquardt and DogLeg are trust region optimization algorithms.
BFGS solver uses the Broyden–Fletcher–Goldfarb–Shanno algorithm.</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="47"/>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="393"/>
      <source>BFGS</source>
      <translation type="unfinished">BFGS</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="52"/>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="398"/>
      <source>LevenbergMarquardt</source>
      <translation type="unfinished">LevenbergMarquardt</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="57"/>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="403"/>
      <source>DogLeg</source>
      <translation type="unfinished">DogLeg</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="69"/>
      <source>Type of function to apply in DogLeg for the Gauss step</source>
      <translation type="unfinished">Type of function to apply in DogLeg for the Gauss step</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="72"/>
      <source>DogLeg Gauss step:</source>
      <translation type="unfinished">DogLeg Gauss step:</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="79"/>
      <source>Step type used in the DogLeg algorithm</source>
      <translation type="unfinished">Step type used in the DogLeg algorithm</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="92"/>
      <source>FullPivLU</source>
      <translation type="unfinished">FullPivLU</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="97"/>
      <source>LeastNorm-FullPivLU</source>
      <translation type="unfinished">LeastNorm-FullPivLU</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="102"/>
      <source>LeastNorm-LDLT</source>
      <translation type="unfinished">LeastNorm-LDLT</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="114"/>
      <source>Maximum number of iterations of the default algorithm</source>
      <translation type="unfinished">Maximum number of iterations of the default algorithm</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="117"/>
      <source>Maximum iterations:</source>
      <translation type="unfinished">Maximum iterations:</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="124"/>
      <source>Maximum iterations to find convergence before solver is stopped</source>
      <translation type="unfinished">Maximum iterations to find convergence before solver is stopped</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="150"/>
      <source>If selected, the Maximum iterations value is multiplied by the sketch size</source>
      <translation type="unfinished">If selected, the Maximum iterations value is multiplied by the sketch size</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="153"/>
      <source>Sketch size multiplier:</source>
      <translation type="unfinished">Sketch size multiplier:</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="166"/>
      <source>Maximum iterations will be multiplied by number of parameters</source>
      <translation type="unfinished">Maximum iterations will be multiplied by number of parameters</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="189"/>
      <source>Error threshold under which convergence is reached</source>
      <translation type="unfinished">Error threshold under which convergence is reached</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="192"/>
      <source>Convergence:</source>
      <translation type="unfinished">Convergence:</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="199"/>
      <source>Threshold for squared error that is used
to determine whether a solution converges or not</source>
      <translation type="unfinished">Threshold for squared error that is used
to determine whether a solution converges or not</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="298"/>
      <source>Algorithm used for the rank revealing QR decomposition</source>
      <translation type="unfinished">Algorithm used for the rank revealing QR decomposition</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="301"/>
      <source>QR algorithm:</source>
      <translation type="unfinished">QR algorithm:</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="308"/>
      <source>During diagnosing the QR rank of matrix is calculated.
Eigen Dense QR is a dense matrix QR with full pivoting; usually slower
Eigen Sparse QR algorithm is optimized for sparse matrices; usually faster</source>
      <translation type="unfinished">During diagnosing the QR rank of matrix is calculated.
Eigen Dense QR is a dense matrix QR with full pivoting; usually slower
Eigen Sparse QR algorithm is optimized for sparse matrices; usually faster</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="323"/>
      <source>Eigen Dense QR</source>
      <translation type="unfinished">Eigen Dense QR</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="328"/>
      <source>Eigen Sparse QR</source>
      <translation type="unfinished">Eigen Sparse QR</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="340"/>
      <source>Pivot threshold</source>
      <translation type="unfinished">Pivot threshold</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="347"/>
      <source>During a QR, values under the pivot threshold are treated as zero</source>
      <translation type="unfinished">During a QR, values under the pivot threshold are treated as zero</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="350"/>
      <source>1E-13</source>
      <translation type="unfinished">1E-13</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="370"/>
      <source>Solving algorithm used for determination of Redundant constraints</source>
      <translation type="unfinished">Solving algorithm used for determination of Redundant constraints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="373"/>
      <source>Redundant solver:</source>
      <translation type="unfinished">Redundant solver:</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="380"/>
      <source>Solver used to determine whether a group is redundant or conflicting</source>
      <translation type="unfinished">Solver used to determine whether a group is redundant or conflicting</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="415"/>
      <source>Maximum number of iterations of the solver used for determination of Redundant constraints</source>
      <translation type="unfinished">Maximum number of iterations of the solver used for determination of Redundant constraints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="418"/>
      <source>Redundant max. iterations:</source>
      <translation type="unfinished">Redundant max. iterations:</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="425"/>
      <source>Same as 'Maximum iterations', but for redundant solving</source>
      <translation type="unfinished">Same as 'Maximum iterations', but for redundant solving</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="451"/>
      <source>If selected, the Maximum iterations value for the redundant algorithm is multiplied by the sketch size</source>
      <translation type="unfinished">If selected, the Maximum iterations value for the redundant algorithm is multiplied by the sketch size</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="454"/>
      <source>Redundant sketch size multiplier:</source>
      <translation type="unfinished">Redundant sketch size multiplier:</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="461"/>
      <source>Same as 'Sketch size multiplier', but for redundant solving</source>
      <translation type="unfinished">Same as 'Sketch size multiplier', but for redundant solving</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="484"/>
      <source>Error threshold under which convergence is reached for the solving of redundant constraints</source>
      <translation type="unfinished">Error threshold under which convergence is reached for the solving of redundant constraints</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="487"/>
      <source>Redundant convergence</source>
      <translation type="unfinished">Redundant convergence</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="494"/>
      <source>Same as 'Convergence', but for redundant solving</source>
      <translation type="unfinished">Same as 'Convergence', but for redundant solving</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="497"/>
      <source>1E-10</source>
      <translation type="unfinished">1E-10</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="589"/>
      <source>Degree of verbosity of the debug output to the console</source>
      <translation type="unfinished">Degree of verbosity of the debug output to the console</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="592"/>
      <source>Console debug mode:</source>
      <translation type="unfinished">Console debug mode:</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="599"/>
      <source>Verbosity of console output</source>
      <translation type="unfinished">Verbosity of console output</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="612"/>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="617"/>
      <source>Minimum</source>
      <translation type="unfinished">Minimum</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="622"/>
      <source>Iteration Level</source>
      <translation type="unfinished">Iteration Level</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="634"/>
      <source>Solve</source>
      <translation type="unfinished">Solve</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="641"/>
      <source>Resets all solver values to their default values</source>
      <translation type="unfinished">Resets all solver values to their default values</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherSolverAdvanced.ui" line="644"/>
      <source>Restore Defaults</source>
      <translation type="unfinished">Restore Defaults</translation>
    </message>
  </context>
  <context>
    <name>ViewProviderSketch</name>
    <message>
      <location filename="../../ViewProviderSketch.cpp" line="3215"/>
      <source>and %1 more</source>
      <translation type="unfinished">and %1 more</translation>
    </message>
  </context>
  <context>
    <name>Workbench</name>
    <message>
      <location filename="../../Workbench.cpp" line="37"/>
      <source>P&amp;rofiles</source>
      <translation type="unfinished">P&amp;rofiles</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="38"/>
      <source>S&amp;ketch</source>
      <translation type="unfinished">S&amp;ketch</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="39"/>
      <source>Sketcher</source>
      <translation type="unfinished">Sketcher</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="40"/>
      <source>Sketcher edit mode</source>
      <translation type="unfinished">Sketcher edit mode</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="41"/>
      <source>Sketcher geometries</source>
      <translation type="unfinished">Sketcher geometries</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="42"/>
      <source>Sketcher constraints</source>
      <translation type="unfinished">Sketcher constraints</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="43"/>
      <source>Sketcher tools</source>
      <translation type="unfinished">Sketcher tools</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="44"/>
      <source>Sketcher B-spline tools</source>
      <translation type="unfinished">Sketcher B-spline tools</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="45"/>
      <source>Sketcher visual</source>
      <translation type="unfinished">Sketcher visual</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="46"/>
      <source>Sketcher virtual space</source>
      <translation type="unfinished">Sketcher virtual space</translation>
    </message>
    <message>
      <location filename="../../Workbench.cpp" line="47"/>
      <source>Sketcher edit tools</source>
      <translation type="unfinished">Sketcher edit tools</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_ProfilesHexagon1</name>
    <message>
      <location filename="../../../Profiles.py" line="59"/>
      <source>Creates a hexagonal profile</source>
      <translation type="unfinished">Creates a hexagonal profile</translation>
    </message>
    <message>
      <location filename="../../../Profiles.py" line="64"/>
      <source>Creates a hexagonal profile in the sketch</source>
      <translation type="unfinished">Creates a hexagonal profile in the sketch</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::SketcherSettingsGrid</name>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="14"/>
      <location filename="../../SketcherSettingsGrid.ui" line="38"/>
      <source>Grid</source>
      <translation type="unfinished">Grid</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="20"/>
      <source>Grid settings</source>
      <translation type="unfinished">Grid settings</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="35"/>
      <source>A grid will be shown</source>
      <translation type="unfinished">A grid will be shown</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="57"/>
      <source>Automatically adapt grid spacing based on the viewer dimensions.</source>
      <translation type="unfinished">Automatically adapt grid spacing based on the viewer dimensions.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="60"/>
      <source>Grid Auto Spacing</source>
      <translation type="unfinished">Grid Auto Spacing</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="73"/>
      <source>Grid spacing</source>
      <translation type="unfinished">Grid spacing</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="83"/>
      <source>Distance between two subsequent grid lines.
If 'Grid Auto Spacing' is enabled, will be used as base value.</source>
      <translation type="unfinished">Distance between two subsequent grid lines.
If 'Grid Auto Spacing' is enabled, will be used as base value.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="115"/>
      <source>Pixel size threshold</source>
      <translation type="unfinished">Pixel size threshold</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="125"/>
      <source>While using 'Grid Auto Spacing' this sets a threshold in pixel to the grid spacing.
The grid spacing change if it becomes smaller than this number of pixel.</source>
      <translation type="unfinished">While using 'Grid Auto Spacing' this sets a threshold in pixel to the grid spacing.
The grid spacing change if it becomes smaller than this number of pixel.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="151"/>
      <source>Grid display</source>
      <translation type="unfinished">Grid display</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="163"/>
      <source>Minor grid lines</source>
      <translation type="unfinished">Minor grid lines</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="269"/>
      <source>Major grid lines</source>
      <translation type="unfinished">Major grid lines</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="281"/>
      <source>Major grid line every:</source>
      <translation type="unfinished">Major grid line every:</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="291"/>
      <source>Every N lines there will be a major line. Set to 1 to disable major lines.</source>
      <translation type="unfinished">Every N lines there will be a major line. Set to 1 to disable major lines.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="175"/>
      <location filename="../../SketcherSettingsGrid.ui" line="313"/>
      <source>Line pattern</source>
      <translation type="unfinished">Line pattern</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="185"/>
      <source>Line pattern used for grid lines.</source>
      <translation type="unfinished">Line pattern used for grid lines.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="195"/>
      <location filename="../../SketcherSettingsGrid.ui" line="333"/>
      <source>Line width</source>
      <translation type="unfinished">Line width</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="205"/>
      <source>Distance between two subsequent grid lines</source>
      <translation type="unfinished">Distance between two subsequent grid lines</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="230"/>
      <location filename="../../SketcherSettingsGrid.ui" line="365"/>
      <source>Line color</source>
      <translation>Boja crte</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="323"/>
      <source>Line pattern used for grid division.</source>
      <translation type="unfinished">Line pattern used for grid division.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsGrid.ui" line="343"/>
      <source>Distance between two subsequent division lines</source>
      <translation type="unfinished">Distance between two subsequent division lines</translation>
    </message>
  </context>
  <context>
    <name>GridSpaceAction</name>
    <message>
      <location filename="../../Command.cpp" line="1150"/>
      <source>Grid auto spacing</source>
      <translation type="unfinished">Grid auto spacing</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1151"/>
      <source>Resize grid automatically depending on zoom.</source>
      <translation type="unfinished">Resize grid automatically depending on zoom.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1154"/>
      <source>Spacing</source>
      <translation type="unfinished">Spacing</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1155"/>
      <source>Distance between two subsequent grid lines.</source>
      <translation type="unfinished">Distance between two subsequent grid lines.</translation>
    </message>
  </context>
  <context>
    <name>Notifications</name>
    <message>
      <location filename="../../../App/SketchObject.cpp" line="566"/>
      <source>The Sketch has malformed constraints!</source>
      <translation type="unfinished">The Sketch has malformed constraints!</translation>
    </message>
    <message>
      <location filename="../../../App/SketchObject.cpp" line="572"/>
      <source>The Sketch has partially redundant constraints!</source>
      <translation type="unfinished">The Sketch has partially redundant constraints!</translation>
    </message>
    <message>
      <location filename="../../../App/SketchObject.cpp" line="10233"/>
      <source>Unmanaged change of Geometry Property results in invalid constraint indices</source>
      <translation type="unfinished">Unmanaged change of Geometry Property results in invalid constraint indices</translation>
    </message>
    <message>
      <location filename="../../../App/SketchObject.cpp" line="10264"/>
      <source>Unmanaged change of Constraint Property results in invalid constraint indices</source>
      <translation type="unfinished">Unmanaged change of Constraint Property results in invalid constraint indices</translation>
    </message>
    <message>
      <location filename="../../../App/SketchObject.cpp" line="10893"/>
      <source>Parabolas were migrated. Migrated files won't open in previous versions of FreeCAD!!
</source>
      <translation type="unfinished">Parabolas were migrated. Migrated files won't open in previous versions of FreeCAD!!
</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerSymmetry.h" line="150"/>
      <location filename="../../DrawSketchHandlerLine.h" line="134"/>
      <location filename="../../DrawSketchHandlerRectangle.h" line="350"/>
      <location filename="../../DrawSketchHandlerTrimming.h" line="182"/>
      <location filename="../../DrawSketchHandlerArcOfEllipse.h" line="317"/>
      <location filename="../../DrawSketchHandlerExtend.h" line="334"/>
      <location filename="../../DrawSketchHandlerSlot.h" line="160"/>
      <location filename="../../DrawSketchHandlerCarbonCopy.h" line="187"/>
      <location filename="../../DrawSketchHandlerTranslate.h" line="129"/>
      <location filename="../../DrawSketchHandlerArcOfParabola.h" line="253"/>
      <location filename="../../DrawSketchHandlerCircle.h" line="166"/>
      <location filename="../../DrawSketchHandlerRotate.h" line="134"/>
      <location filename="../../DrawSketchHandlerArcOfHyperbola.h" line="251"/>
      <location filename="../../DrawSketchHandlerArcOfHyperbola.h" line="330"/>
      <location filename="../../DrawSketchHandlerSplitting.h" line="158"/>
      <location filename="../../DrawSketchHandlerExternal.h" line="194"/>
      <location filename="../../DrawSketchHandlerPolygon.h" line="131"/>
      <location filename="../../DrawSketchHandlerLineSet.h" line="462"/>
      <location filename="../../DrawSketchHandlerLineSet.h" line="492"/>
      <location filename="../../DrawSketchHandlerBSpline.h" line="378"/>
      <location filename="../../DrawSketchHandlerBSpline.h" line="609"/>
      <location filename="../../DrawSketchHandlerBSpline.h" line="679"/>
      <location filename="../../DrawSketchHandlerScale.h" line="130"/>
      <location filename="../../DrawSketchHandlerEllipse.h" line="175"/>
      <location filename="../../CommandSketcherTools.cpp" line="1278"/>
      <location filename="../../CommandSketcherTools.cpp" line="1855"/>
      <location filename="../../CommandSketcherTools.cpp" line="2292"/>
      <location filename="../../DrawSketchHandlerArcSlot.h" line="180"/>
      <location filename="../../DrawSketchHandlerPoint.h" line="93"/>
      <source>Error</source>
      <translation type="unfinished">Error</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2093"/>
      <source>Failed to delete all geometry</source>
      <translation type="unfinished">Failed to delete all geometry</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2158"/>
      <source>Failed to delete all constraints</source>
      <translation type="unfinished">Failed to delete all constraints</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2378"/>
      <source>Selection has no valid geometries. B-splines and points are not supported yet.</source>
      <translation type="unfinished">Selection has no valid geometries. B-splines and points are not supported yet.</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="134"/>
      <location filename="../../CommandSketcherTools.cpp" line="2377"/>
      <source>Invalid selection</source>
      <translation type="unfinished">Invalid selection</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="135"/>
      <source>Selection has no valid geometries.</source>
      <translation type="unfinished">Selection has no valid geometries.</translation>
    </message>
    <message>
      <location filename="../../../App/SketchObjectPyImp.cpp" line="414"/>
      <source>The constraint has invalid index information and is malformed.</source>
      <translation type="unfinished">The constraint has invalid index information and is malformed.</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherBSpline.cpp" line="468"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="604"/>
      <location filename="../../CommandSketcherBSpline.cpp" line="832"/>
      <location filename="../../CommandConstraints.cpp" line="434"/>
      <location filename="../../CommandConstraints.cpp" line="514"/>
      <location filename="../../CommandConstraints.cpp" line="611"/>
      <location filename="../../CommandConstraints.cpp" line="701"/>
      <location filename="../../CommandConstraints.cpp" line="775"/>
      <location filename="../../CommandConstraints.cpp" line="6215"/>
      <location filename="../../CommandConstraints.cpp" line="6419"/>
      <location filename="../../CommandSketcherTools.cpp" line="1068"/>
      <source>Invalid Constraint</source>
      <translation type="unfinished">Invalid Constraint</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerLineSet.h" line="493"/>
      <source>Failed to add arc</source>
      <translation type="unfinished">Failed to add arc</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerArcOfEllipse.h" line="318"/>
      <source>Failed to add arc of ellipse</source>
      <translation type="unfinished">Failed to add arc of ellipse</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerArcOfHyperbola.h" line="252"/>
      <source>Cannot create arc of hyperbola from invalid angles, try again!</source>
      <translation type="unfinished">Cannot create arc of hyperbola from invalid angles, try again!</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerArcOfHyperbola.h" line="331"/>
      <source>Cannot create arc of hyperbola</source>
      <translation type="unfinished">Cannot create arc of hyperbola</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerArcOfParabola.h" line="254"/>
      <source>Cannot create arc of parabola</source>
      <translation type="unfinished">Cannot create arc of parabola</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerBSpline.h" line="379"/>
      <source>Error creating B-spline</source>
      <translation type="unfinished">Error creating B-spline</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerBSpline.h" line="610"/>
      <source>Error deleting last pole/knot</source>
      <translation type="unfinished">Error deleting last pole/knot</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerBSpline.h" line="680"/>
      <source>Error adding B-spline pole/knot</source>
      <translation type="unfinished">Error adding B-spline pole/knot</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerCarbonCopy.h" line="188"/>
      <source>Failed to add carbon copy</source>
      <translation type="unfinished">Failed to add carbon copy</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerCircle.h" line="167"/>
      <source>Failed to add circle</source>
      <translation type="unfinished">Failed to add circle</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerExtend.h" line="335"/>
      <source>Failed to extend edge</source>
      <translation type="unfinished">Failed to extend edge</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerExternal.h" line="195"/>
      <source>Failed to add external geometry</source>
      <translation type="unfinished">Failed to add external geometry</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerFillet.h" line="225"/>
      <source>Failed to create fillet</source>
      <translation type="unfinished">Failed to create fillet</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerLine.h" line="135"/>
      <location filename="../../DrawSketchHandlerLineSet.h" line="463"/>
      <source>Failed to add line</source>
      <translation type="unfinished">Failed to add line</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerSymmetry.h" line="155"/>
      <location filename="../../DrawSketchHandlerLine.h" line="139"/>
      <location filename="../../DrawSketchHandlerRectangle.h" line="355"/>
      <location filename="../../DrawSketchHandlerSlot.h" line="165"/>
      <location filename="../../DrawSketchHandlerTranslate.h" line="134"/>
      <location filename="../../DrawSketchHandlerArc.h" line="245"/>
      <location filename="../../DrawSketchHandlerCircle.h" line="171"/>
      <location filename="../../DrawSketchHandlerRotate.h" line="139"/>
      <location filename="../../DrawSketchHandlerPolygon.h" line="136"/>
      <location filename="../../DrawSketchHandlerScale.h" line="135"/>
      <location filename="../../DrawSketchHandlerEllipse.h" line="180"/>
      <location filename="../../DrawSketchHandlerArcSlot.h" line="185"/>
      <source>Tool execution aborted</source>
      <translation type="unfinished">Tool execution aborted</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerPoint.h" line="94"/>
      <source>Failed to add point</source>
      <translation type="unfinished">Failed to add point</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerPolygon.h" line="132"/>
      <source>Failed to add polygon</source>
      <translation type="unfinished">Failed to add polygon</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerRectangle.h" line="351"/>
      <source>Failed to add box</source>
      <translation type="unfinished">Failed to add box</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerSlot.h" line="161"/>
      <source>Failed to add slot</source>
      <translation type="unfinished">Failed to add slot</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerSplitting.h" line="159"/>
      <source>Failed to add edge</source>
      <translation type="unfinished">Failed to add edge</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerTrimming.h" line="183"/>
      <source>Failed to trim edge</source>
      <translation type="unfinished">Failed to trim edge</translation>
    </message>
    <message>
      <location filename="../../TaskSketcherConstraints.cpp" line="1237"/>
      <location filename="../../TaskSketcherConstraints.cpp" line="1255"/>
      <location filename="../../EditDatumDialog.cpp" line="251"/>
      <source>Value Error</source>
      <translation type="unfinished">Value Error</translation>
    </message>
    <message>
      <location filename="../../DrawSketchDefaultHandler.h" line="961"/>
      <source>Autoconstraints cause redundancy. Removing them</source>
      <translation type="unfinished">Autoconstraints cause redundancy. Removing them</translation>
    </message>
    <message>
      <location filename="../../DrawSketchDefaultHandler.h" line="980"/>
      <source>Redundant constraint is not an autoconstraint. No autoconstraints or additional constraints were added. Please report!</source>
      <translation type="unfinished">Redundant constraint is not an autoconstraint. No autoconstraints or additional constraints were added. Please report!</translation>
    </message>
    <message>
      <location filename="../../DrawSketchDefaultHandler.h" line="995"/>
      <source>Autoconstraints cause conflicting constraints - Please report!</source>
      <translation type="unfinished">Autoconstraints cause conflicting constraints - Please report!</translation>
    </message>
    <message>
      <location filename="../../DrawSketchDefaultHandler.h" line="1021"/>
      <source>Unexpected Redundancy/Conflicting constraint. Check the constraints and autoconstraints of this operation.</source>
      <translation type="unfinished">Unexpected Redundancy/Conflicting constraint. Check the constraints and autoconstraints of this operation.</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerOffset.h" line="1133"/>
      <source>Invalid Value</source>
      <translation type="unfinished">Invalid Value</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerOffset.h" line="1134"/>
      <source>Offset value can't be 0.</source>
      <translation type="unfinished">Offset value can't be 0.</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerArcSlot.h" line="181"/>
      <source>Failed to add arc slot</source>
      <translation type="unfinished">Failed to add arc slot</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerEllipse.h" line="176"/>
      <source>Failed to add ellipse</source>
      <translation type="unfinished">Failed to add ellipse</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerRotate.h" line="135"/>
      <source>Failed to rotate</source>
      <translation type="unfinished">Failed to rotate</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerScale.h" line="131"/>
      <source>Failed to scale</source>
      <translation type="unfinished">Failed to scale</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerTranslate.h" line="130"/>
      <source>Failed to translate</source>
      <translation type="unfinished">Failed to translate</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerSymmetry.h" line="151"/>
      <source>Failed to create symmetry</source>
      <translation type="unfinished">Failed to create symmetry</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreateBSplineByInterpolation</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1132"/>
      <source>B-spline by knots</source>
      <translation type="unfinished">B-spline by knots</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1133"/>
      <location filename="../../CommandCreateGeo.cpp" line="1135"/>
      <source>Create a B-spline by knots</source>
      <translation type="unfinished">Create a B-spline by knots</translation>
    </message>
  </context>
  <context>
    <name>SnapSpaceAction</name>
    <message>
      <location filename="../../Command.cpp" line="1394"/>
      <source>Snap to objects</source>
      <translation type="unfinished">Snap to objects</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1395"/>
      <source>New points will snap to the currently preselected object. It will also snap to the middle of lines and arcs.</source>
      <translation type="unfinished">New points will snap to the currently preselected object. It will also snap to the middle of lines and arcs.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1399"/>
      <source>Snap to grid</source>
      <translation type="unfinished">Snap to grid</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1401"/>
      <source>New points will snap to the nearest grid line.
Points must be set closer than a fifth of the grid spacing to a grid line to snap.</source>
      <translation type="unfinished">New points will snap to the nearest grid line.
Points must be set closer than a fifth of the grid spacing to a grid line to snap.</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1405"/>
      <source>Snap angle</source>
      <translation type="unfinished">Snap angle</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1407"/>
      <source>Angular step for tools that use 'Snap at Angle' (line for instance). Hold CTRL to enable 'Snap at Angle'. The angle starts from the positive X axis of the sketch.</source>
      <translation type="unfinished">Angular step for tools that use 'Snap at Angle' (line for instance). Hold CTRL to enable 'Snap at Angle'. The angle starts from the positive X axis of the sketch.</translation>
    </message>
  </context>
  <context>
    <name>RenderingOrderAction</name>
    <message>
      <location filename="../../Command.cpp" line="1642"/>
      <location filename="../../Command.cpp" line="1649"/>
      <location filename="../../Command.cpp" line="1656"/>
      <source>Normal Geometry</source>
      <translation type="unfinished">Normal Geometry</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1643"/>
      <location filename="../../Command.cpp" line="1650"/>
      <location filename="../../Command.cpp" line="1657"/>
      <source>Construction Geometry</source>
      <translation type="unfinished">Construction Geometry</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1644"/>
      <location filename="../../Command.cpp" line="1651"/>
      <location filename="../../Command.cpp" line="1658"/>
      <source>External Geometry</source>
      <translation type="unfinished">External Geometry</translation>
    </message>
  </context>
  <context>
    <name>CmdRenderingOrder</name>
    <message>
      <location filename="../../Command.cpp" line="1767"/>
      <source>Configure rendering order</source>
      <translation type="unfinished">Configure rendering order</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1768"/>
      <source>Reorder the items in the list to configure rendering order.</source>
      <translation type="unfinished">Reorder the items in the list to configure rendering order.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherGrid</name>
    <message>
      <location filename="../../Command.cpp" line="1251"/>
      <source>Toggle grid</source>
      <translation type="unfinished">Toggle grid</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1253"/>
      <source>Toggle the grid in the sketch. In the menu you can change grid settings.</source>
      <translation type="unfinished">Toggle the grid in the sketch. In the menu you can change grid settings.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherSnap</name>
    <message>
      <location filename="../../Command.cpp" line="1507"/>
      <source>Toggle snap</source>
      <translation type="unfinished">Toggle snap</translation>
    </message>
    <message>
      <location filename="../../Command.cpp" line="1509"/>
      <source>Toggle all snap functionality. In the menu you can toggle 'Snap to grid' and 'Snap to objects' individually, and change further snap settings.</source>
      <translation type="unfinished">Toggle all snap functionality. In the menu you can toggle 'Snap to grid' and 'Snap to objects' individually, and change further snap settings.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateBSplineByInterpolation</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="918"/>
      <source>Create B-spline by knots</source>
      <translation type="unfinished">Create B-spline by knots</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="919"/>
      <source>Create a B-spline by knots, i.e. by interpolation, in the sketch.</source>
      <translation type="unfinished">Create a B-spline by knots, i.e. by interpolation, in the sketch.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreatePeriodicBSplineByInterpolation</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="952"/>
      <source>Create periodic B-spline by knots</source>
      <translation type="unfinished">Create periodic B-spline by knots</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="954"/>
      <source>Create a periodic B-spline by knots, i.e. by interpolation, in the sketch.</source>
      <translation type="unfinished">Create a periodic B-spline by knots, i.e. by interpolation, in the sketch.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherDimension</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2776"/>
      <source>Dimension</source>
      <translation type="unfinished">Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2777"/>
      <source>Constrain contextually based on your selection.
Depending on your selection you might have several constraints available. You can cycle through them using M key.
Left clicking on empty space will validate the current constraint. Right clicking or pressing Esc will cancel.</source>
      <translation type="unfinished">Constrain contextually based on your selection.
Depending on your selection you might have several constraints available. You can cycle through them using M key.
Left clicking on empty space will validate the current constraint. Right clicking or pressing Esc will cancel.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherArcOverlay</name>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="363"/>
      <source>Show/hide circular helper for arcs</source>
      <translation type="unfinished">Show/hide circular helper for arcs</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherOverlay.cpp" line="365"/>
      <source>Switches between showing and hiding the circular helper for all arcs</source>
      <translation type="unfinished">Switches between showing and hiding the circular helper for all arcs</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompDimensionTools</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1206"/>
      <source>Dimension</source>
      <translation type="unfinished">Dimension</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1207"/>
      <source>Dimension tools.</source>
      <translation type="unfinished">Dimension tools.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainRadius</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="7452"/>
      <source>Constrain radius</source>
      <translation type="unfinished">Constrain radius</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="7453"/>
      <source>Fix the radius of a circle or an arc</source>
      <translation type="unfinished">Fix the radius of a circle or an arc</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::SketcherToolDefaultWidget</name>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="14"/>
      <source>Form</source>
      <translation type="unfinished">Form</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="22"/>
      <source>Mode (M)</source>
      <translation type="unfinished">Mode (M)</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="46"/>
      <location filename="../../SketcherToolDefaultWidget.ui" line="70"/>
      <source>Mode</source>
      <translation type="unfinished">Mode</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="94"/>
      <source>Parameter 1</source>
      <translation type="unfinished">Parameter 1</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="115"/>
      <source>Parameter 2</source>
      <translation type="unfinished">Parameter 2</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="136"/>
      <source>Parameter 3</source>
      <translation type="unfinished">Parameter 3</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="157"/>
      <source>Parameter 4</source>
      <translation type="unfinished">Parameter 4</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="178"/>
      <source>Parameter 5</source>
      <translation type="unfinished">Parameter 5</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="199"/>
      <source>Parameter 6</source>
      <translation type="unfinished">Parameter 6</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="220"/>
      <source>Parameter 7</source>
      <translation type="unfinished">Parameter 7</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="241"/>
      <source>Parameter 8</source>
      <translation type="unfinished">Parameter 8</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="262"/>
      <source>Parameter 9</source>
      <translation type="unfinished">Parameter 9</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="283"/>
      <source>Parameter 10</source>
      <translation type="unfinished">Parameter 10</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="305"/>
      <source>Checkbox 1 toolTip</source>
      <translation type="unfinished">Checkbox 1 toolTip</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="308"/>
      <source>Checkbox 1</source>
      <translation type="unfinished">Checkbox 1</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="327"/>
      <source>Checkbox 2 toolTip</source>
      <translation type="unfinished">Checkbox 2 toolTip</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="330"/>
      <source>Checkbox 2</source>
      <translation type="unfinished">Checkbox 2</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="349"/>
      <source>Checkbox 3 toolTip</source>
      <translation type="unfinished">Checkbox 3 toolTip</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="352"/>
      <source>Checkbox 3</source>
      <translation type="unfinished">Checkbox 3</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="371"/>
      <source>Checkbox 4 toolTip</source>
      <translation type="unfinished">Checkbox 4 toolTip</translation>
    </message>
    <message>
      <location filename="../../SketcherToolDefaultWidget.ui" line="374"/>
      <source>Checkbox 4</source>
      <translation type="unfinished">Checkbox 4</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherOffset</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2313"/>
      <source>Offset geometry</source>
      <translation type="unfinished">Offset geometry</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2314"/>
      <source>Offset selected geometries. A positive offset length makes the offset go outward, a negative length inward.</source>
      <translation type="unfinished">Offset selected geometries. A positive offset length makes the offset go outward, a negative length inward.</translation>
    </message>
  </context>
  <context>
    <name>TaskSketcherTool_c1_offset</name>
    <message>
      <location filename="../../DrawSketchHandlerOffset.h" line="1110"/>
      <source>Delete original geometries (U)</source>
      <translation type="unfinished">Delete original geometries (U)</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerRotate.h" line="500"/>
      <source>Apply equal constraints</source>
      <translation type="unfinished">Apply equal constraints</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerRotate.h" line="504"/>
      <source>If this option is selected dimensional constraints are excluded from the operation.
Instead equal constraints are applied between the original objects and their copies.</source>
      <translation type="unfinished">If this option is selected dimensional constraints are excluded from the operation.
Instead equal constraints are applied between the original objects and their copies.</translation>
    </message>
  </context>
  <context>
    <name>TaskSketcherTool_c2_offset</name>
    <message>
      <location filename="../../DrawSketchHandlerOffset.h" line="1114"/>
      <source>Add offset constraint (J)</source>
      <translation type="unfinished">Add offset constraint (J)</translation>
    </message>
  </context>
  <context>
    <name>TaskSketcherTool_c1_rectangle</name>
    <message>
      <location filename="../../DrawSketchHandlerRectangle.h" line="1657"/>
      <source>Corner, width, height</source>
      <translation type="unfinished">Corner, width, height</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerRectangle.h" line="1658"/>
      <source>Center, width, height</source>
      <translation type="unfinished">Center, width, height</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerRectangle.h" line="1659"/>
      <source>3 corners</source>
      <translation type="unfinished">3 corners</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerRectangle.h" line="1660"/>
      <source>Center, 2 corners</source>
      <translation type="unfinished">Center, 2 corners</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerRectangle.h" line="1665"/>
      <source>Rounded corners (U)</source>
      <translation type="unfinished">Rounded corners (U)</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerRectangle.h" line="1668"/>
      <source>Create a rectangle with rounded corners.</source>
      <translation type="unfinished">Create a rectangle with rounded corners.</translation>
    </message>
  </context>
  <context>
    <name>TaskSketcherTool_c2_rectangle</name>
    <message>
      <location filename="../../DrawSketchHandlerRectangle.h" line="1674"/>
      <source>Frame (J)</source>
      <translation type="unfinished">Frame (J)</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerRectangle.h" line="1677"/>
      <source>Create two rectangles with a constant offset.</source>
      <translation type="unfinished">Create two rectangles with a constant offset.</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::TaskSketcherTool</name>
    <message>
      <location filename="../../TaskSketcherTool.cpp" line="48"/>
      <source>Tool parameters</source>
      <translation type="unfinished">Tool parameters</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompHorizontalVertical</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2833"/>
      <source>Constrain horizontal/vertical</source>
      <translation type="unfinished">Constrain horizontal/vertical</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="2834"/>
      <source>Constrains a single line to either horizontal or vertical.</source>
      <translation type="unfinished">Constrains a single line to either horizontal or vertical.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainHorVer</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3151"/>
      <source>Constrain horizontal/vertical</source>
      <translation type="unfinished">Constrain horizontal/vertical</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3152"/>
      <source>Constrains a single line to either horizontal or vertical, whichever is closer to current alignment.</source>
      <translation type="unfinished">Constrains a single line to either horizontal or vertical, whichever is closer to current alignment.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompCurveEdition</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1414"/>
      <source>Curve Edition</source>
      <translation type="unfinished">Curve Edition</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1415"/>
      <source>Curve Edition tools.</source>
      <translation type="unfinished">Curve Edition tools.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompSlot</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1610"/>
      <source>Slots</source>
      <translation type="unfinished">Slots</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1611"/>
      <source>Slot tools.</source>
      <translation type="unfinished">Slot tools.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateArcSlot</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1696"/>
      <source>Create arc slot</source>
      <translation type="unfinished">Create arc slot</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1697"/>
      <source>Create an arc slot in the sketch</source>
      <translation type="unfinished">Create an arc slot in the sketch</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainCoincidentUnified</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3775"/>
      <source>Constrain coincident</source>
      <translation type="unfinished">Constrain coincident</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="3776"/>
      <source>Create a coincident constraint between points, or fix a point on an edge, or a concentric constraint between circles, arcs, and ellipses</source>
      <translation type="unfinished">Create a coincident constraint between points, or fix a point on an edge, or a concentric constraint between circles, arcs, and ellipses</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherRotate</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2396"/>
      <source>Rotate / Polar transform</source>
      <translation type="unfinished">Rotate / Polar transform</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2397"/>
      <source>Rotate selected geometries, making n copies, enable creation of circular patterns.</source>
      <translation type="unfinished">Rotate selected geometries, making n copies, enable creation of circular patterns.</translation>
    </message>
  </context>
  <context>
    <name>SketcherGui::SketcherSettingsAppearance</name>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="14"/>
      <source>Appearance</source>
      <translation type="unfinished">Appearance</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="20"/>
      <source>Working colors</source>
      <translation type="unfinished">Working colors</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="34"/>
      <source>Creating line</source>
      <translation type="unfinished">Creating line</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="41"/>
      <source>Color used while new sketch elements are created</source>
      <translation type="unfinished">Color used while new sketch elements are created</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="80"/>
      <source>Coordinate text</source>
      <translation type="unfinished">Coordinate text</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="87"/>
      <source>Text color of the coordinates</source>
      <translation type="unfinished">Text color of the coordinates</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="107"/>
      <source>Cursor crosshair</source>
      <translation type="unfinished">Cursor crosshair</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="114"/>
      <source>Color of crosshair cursor.
(The one you get when creating a new sketch element.)</source>
      <translation type="unfinished">Color of crosshair cursor.
(The one you get when creating a new sketch element.)</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="140"/>
      <source>Geometric element colors</source>
      <translation type="unfinished">Geometric element colors</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="152"/>
      <source>Constrained</source>
      <translation type="unfinished">Constrained</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="165"/>
      <source>Unconstrained</source>
      <translation type="unfinished">Unconstrained</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="172"/>
      <source>Pattern</source>
      <translation type="unfinished">Pattern</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="179"/>
      <source>Width</source>
      <translation type="unfinished">Width</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="212"/>
      <source>Color of fully constrained normal geometry in edit mode</source>
      <translation type="unfinished">Color of fully constrained normal geometry in edit mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="238"/>
      <source>Color of normal geometry in edit mode</source>
      <translation type="unfinished">Color of normal geometry in edit mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="306"/>
      <source>Color of fully constrained construction geometry in edit mode</source>
      <translation type="unfinished">Color of fully constrained construction geometry in edit mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="387"/>
      <source>Internal alignment geometry</source>
      <translation type="unfinished">Internal alignment geometry</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="400"/>
      <source>Color of fully constrained internal alignment geometry in edit mode</source>
      <translation type="unfinished">Color of fully constrained internal alignment geometry in edit mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="426"/>
      <source>Color of internal alignment geometry in edit mode</source>
      <translation type="unfinished">Color of internal alignment geometry in edit mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="555"/>
      <source>Fully constrained sketch</source>
      <translation type="unfinished">Fully constrained sketch</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="568"/>
      <source>Color of geometry indicating a fully constrained sketch</source>
      <translation type="unfinished">Color of geometry indicating a fully constrained sketch</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="588"/>
      <source>Invalid sketch</source>
      <translation type="unfinished">Invalid sketch</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="672"/>
      <source>Color of dimensional driving constraints in edit mode</source>
      <translation type="unfinished">Color of dimensional driving constraints in edit mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="799"/>
      <source>Vertex</source>
      <translation type="unfinished">Vertex</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="806"/>
      <source>Color of vertices outside edit mode</source>
      <translation type="unfinished">Color of vertices outside edit mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="845"/>
      <source>Edge</source>
      <translation type="unfinished">Edge</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="852"/>
      <source>Color of edges outside edit mode</source>
      <translation type="unfinished">Color of edges outside edit mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="199"/>
      <source>Geometry</source>
      <translation type="unfinished">Geometry</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="258"/>
      <source>Line pattern of normal edges.</source>
      <translation type="unfinished">Line pattern of normal edges.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="268"/>
      <source>Width of normal edges.</source>
      <translation type="unfinished">Width of normal edges.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="293"/>
      <source>Construction geometry</source>
      <translation type="unfinished">Construction geometry</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="332"/>
      <source>Color of construction geometry in edit mode</source>
      <translation type="unfinished">Color of construction geometry in edit mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="352"/>
      <source>Line pattern of construction edges.</source>
      <translation type="unfinished">Line pattern of construction edges.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="362"/>
      <source>Width of construction edges.</source>
      <translation type="unfinished">Width of construction edges.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="446"/>
      <source>Line pattern of internal aligned edges.</source>
      <translation type="unfinished">Line pattern of internal aligned edges.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="456"/>
      <source>Width of internal aligned edges.</source>
      <translation type="unfinished">Width of internal aligned edges.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="481"/>
      <source>External geometry</source>
      <translation type="unfinished">External geometry</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="494"/>
      <source>Color of external geometry in edit mode</source>
      <translation type="unfinished">Color of external geometry in edit mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="514"/>
      <source>Line pattern of external edges.</source>
      <translation type="unfinished">Line pattern of external edges.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="524"/>
      <source>Width of external edges.</source>
      <translation type="unfinished">Width of external edges.</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="601"/>
      <source>Color of geometry indicating an invalid sketch</source>
      <translation type="unfinished">Color of geometry indicating an invalid sketch</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="624"/>
      <source>Constraint colors</source>
      <translation type="unfinished">Constraint colors</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="638"/>
      <source>Constraint symbols</source>
      <translation type="unfinished">Constraint symbols</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="645"/>
      <source>Color of driving constraints in edit mode</source>
      <translation type="unfinished">Color of driving constraints in edit mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="665"/>
      <source>Dimensional constraint</source>
      <translation type="unfinished">Dimensional constraint</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="692"/>
      <source>Reference constraint</source>
      <translation type="unfinished">Reference constraint</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="699"/>
      <source>Color of reference constraints in edit mode</source>
      <translation type="unfinished">Color of reference constraints in edit mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="719"/>
      <source>Expression dependent constraint</source>
      <translation type="unfinished">Expression dependent constraint</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="726"/>
      <source>Color of expression dependent constraints in edit mode</source>
      <translation type="unfinished">Color of expression dependent constraints in edit mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="746"/>
      <source>Deactivated constraint</source>
      <translation type="unfinished">Deactivated constraint</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="753"/>
      <source>Color of deactivated constraints in edit mode</source>
      <translation type="unfinished">Color of deactivated constraints in edit mode</translation>
    </message>
    <message>
      <location filename="../../SketcherSettingsAppearance.ui" line="791"/>
      <source>Colors outside Sketcher</source>
      <translation type="unfinished">Colors outside Sketcher</translation>
    </message>
  </context>
  <context>
    <name>TaskSketcherTool_p4_rotate</name>
    <message>
      <location filename="../../DrawSketchHandlerRotate.h" line="523"/>
      <source>Copies (+'U'/ -'J')</source>
      <translation type="unfinished">Copies (+'U'/ -'J')</translation>
    </message>
  </context>
  <context>
    <name>ToolWidgetManager_p4</name>
    <message>
      <location filename="../../DrawSketchHandlerPolygon.h" line="304"/>
      <source>Sides (+'U'/ -'J')</source>
      <translation type="unfinished">Sides (+'U'/ -'J')</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerBSpline.h" line="890"/>
      <source>Degree (+'U'/ -'J')</source>
      <translation type="unfinished">Degree (+'U'/ -'J')</translation>
    </message>
  </context>
  <context>
    <name>TaskSketcherTool_c1_scale</name>
    <message>
      <location filename="../../DrawSketchHandlerScale.h" line="405"/>
      <source>Keep original geometries (U)</source>
      <translation type="unfinished">Keep original geometries (U)</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompConstrainTools</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1279"/>
      <source>Constrain</source>
      <translation type="unfinished">Constrain</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1280"/>
      <source>Constrain tools.</source>
      <translation type="unfinished">Constrain tools.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCopyClipboard</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="219"/>
      <source>C&amp;opy in sketcher</source>
      <translation type="unfinished">C&amp;opy in sketcher</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="220"/>
      <source>Copy selected geometries and constraints to the clipboard</source>
      <translation type="unfinished">Copy selected geometries and constraints to the clipboard</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCut</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="250"/>
      <source>C&amp;ut in sketcher</source>
      <translation type="unfinished">C&amp;ut in sketcher</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="251"/>
      <source>Cut selected geometries and constraints to the clipboard</source>
      <translation type="unfinished">Cut selected geometries and constraints to the clipboard</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherPaste</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="290"/>
      <source>P&amp;aste in sketcher</source>
      <translation type="unfinished">P&amp;aste in sketcher</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="291"/>
      <source>Paste selected geometries and constraints from the clipboard</source>
      <translation type="unfinished">Paste selected geometries and constraints from the clipboard</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherScale</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2430"/>
      <source>Scale transform</source>
      <translation type="unfinished">Scale transform</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2431"/>
      <source>Scale selected geometries. After selecting the center point you can either enter the scale factor, or select two reference points then scale factor = length(p2-center) / length(p1-center).</source>
      <translation type="unfinished">Scale selected geometries. After selecting the center point you can either enter the scale factor, or select two reference points then scale factor = length(p2-center) / length(p1-center).</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherTranslate</name>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2464"/>
      <source>Move / Array transform</source>
      <translation type="unfinished">Move / Array transform</translation>
    </message>
    <message>
      <location filename="../../CommandSketcherTools.cpp" line="2465"/>
      <source>Translate selected geometries. Enable creation of i * j copies.</source>
      <translation type="unfinished">Translate selected geometries. Enable creation of i * j copies.</translation>
    </message>
  </context>
  <context>
    <name>TaskSketcherTool_p3_translate</name>
    <message>
      <location filename="../../DrawSketchHandlerTranslate.h" line="516"/>
      <source>Copies (+'U'/-'J')</source>
      <translation type="unfinished">Copies (+'U'/-'J')</translation>
    </message>
  </context>
  <context>
    <name>TaskSketcherTool_p5_translate</name>
    <message>
      <location filename="../../DrawSketchHandlerTranslate.h" line="519"/>
      <source>Rows (+'R'/-'F')</source>
      <translation type="unfinished">Rows (+'R'/-'F')</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreateArc</name>
    <message>
      <location filename="../../DrawSketchHandlerArc.h" line="460"/>
      <source>Center</source>
      <translation type="unfinished">Center</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerArc.h" line="461"/>
      <source>3 rim points</source>
      <translation type="unfinished">3 rim points</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCreateChamfer</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1258"/>
      <source>Create chamfer</source>
      <translation type="unfinished">Create chamfer</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1259"/>
      <source>Create a chamfer between two lines or at a coincident point</source>
      <translation type="unfinished">Create a chamfer between two lines or at a coincident point</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompCreateFillets</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1289"/>
      <source>Create fillet or chamfer</source>
      <translation type="unfinished">Create fillet or chamfer</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1290"/>
      <source>Create a fillet or chamfer between two lines</source>
      <translation type="unfinished">Create a fillet or chamfer between two lines</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreateArcSlot</name>
    <message>
      <location filename="../../DrawSketchHandlerArcSlot.h" line="546"/>
      <source>Arc ends</source>
      <translation type="unfinished">Arc ends</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerArcSlot.h" line="547"/>
      <source>Flat ends</source>
      <translation type="unfinished">Flat ends</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreateEllipse</name>
    <message>
      <location filename="../../DrawSketchHandlerEllipse.h" line="420"/>
      <source>Center</source>
      <translation type="unfinished">Center</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerEllipse.h" line="421"/>
      <source>Axis endpoints</source>
      <translation type="unfinished">Axis endpoints</translation>
    </message>
  </context>
  <context>
    <name>TaskSketcherTool_c1_fillet</name>
    <message>
      <location filename="../../DrawSketchHandlerFillet.h" line="432"/>
      <source>Preserve corner (U)</source>
      <translation type="unfinished">Preserve corner (U)</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerFillet.h" line="435"/>
      <source>Preserves intersection point and most constraints</source>
      <translation type="unfinished">Preserves intersection point and most constraints</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreateLine</name>
    <message>
      <location filename="../../DrawSketchHandlerLine.h" line="277"/>
      <source>Point, length, angle</source>
      <translation type="unfinished">Point, length, angle</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerLine.h" line="278"/>
      <source>Point, width, height</source>
      <translation type="unfinished">Point, width, height</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerLine.h" line="279"/>
      <source>2 points</source>
      <translation type="unfinished">2 points</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreateOffset</name>
    <message>
      <location filename="../../DrawSketchHandlerOffset.h" line="1097"/>
      <source>Arc</source>
      <translation>Luk</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerOffset.h" line="1098"/>
      <source>Intersection</source>
      <translation type="unfinished">Intersection</translation>
    </message>
  </context>
  <context>
    <name>TaskSketcherTool_c1_symmetry</name>
    <message>
      <location filename="../../DrawSketchHandlerSymmetry.h" line="263"/>
      <source>Delete original geometries (U)</source>
      <translation type="unfinished">Delete original geometries (U)</translation>
    </message>
  </context>
  <context>
    <name>TaskSketcherTool_c2_symmetry</name>
    <message>
      <location filename="../../DrawSketchHandlerSymmetry.h" line="266"/>
      <source>Create Symmetry Constraints (J)</source>
      <translation type="unfinished">Create Symmetry Constraints (J)</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherConstrainTangent</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="6577"/>
      <source>Constrain tangent or collinear</source>
      <translation type="unfinished">Constrain tangent or collinear</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="6578"/>
      <source>Create a tangent or collinear constraint between two entities</source>
      <translation type="unfinished">Create a tangent or collinear constraint between two entities</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherChangeDimensionConstraint</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9913"/>
      <source>Change value</source>
      <translation type="unfinished">Change value</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="9914"/>
      <source>Change the value of a dimensional constraint</source>
      <translation type="unfinished">Change the value of a dimensional constraint</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_CreatePeriodicBSplineByInterpolation</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1139"/>
      <source>Periodic B-spline by knots</source>
      <translation type="unfinished">Periodic B-spline by knots</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1142"/>
      <location filename="../../CommandCreateGeo.cpp" line="1145"/>
      <source>Create a periodic B-spline by knots</source>
      <translation type="unfinished">Create a periodic B-spline by knots</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompLine</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="115"/>
      <source>Create polyline</source>
      <translation type="unfinished">Create polyline</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="116"/>
      <source>Create a polyline in the sketch. 'M' Key cycles behaviour</source>
      <translation type="unfinished">Create a polyline in the sketch. 'M' Key cycles behaviour</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompToggleConstraints</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1310"/>
      <source>Toggle constraints</source>
      <translation type="unfinished">Toggle constraints</translation>
    </message>
    <message>
      <location filename="../../CommandConstraints.cpp" line="1311"/>
      <source>Toggle constrain tools.</source>
      <translation type="unfinished">Toggle constrain tools.</translation>
    </message>
  </context>
  <context>
    <name>TaskSketcherTool_c1_bspline</name>
    <message>
      <location filename="../../DrawSketchHandlerBSpline.h" line="847"/>
      <source>Press F to undo last point.</source>
      <translation type="unfinished">Press F to undo last point.</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerBSpline.h" line="855"/>
      <source>Periodic (R)</source>
      <translation type="unfinished">Periodic (R)</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerBSpline.h" line="858"/>
      <source>Create a periodic B-spline.</source>
      <translation type="unfinished">Create a periodic B-spline.</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_ConstrainRadius</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="8614"/>
      <location filename="../../CommandConstraints.cpp" line="8616"/>
      <source>Fix the radius of an arc or a circle</source>
      <translation type="unfinished">Fix the radius of an arc or a circle</translation>
    </message>
  </context>
  <context>
    <name>Sketcher_ConstrainRadiam</name>
    <message>
      <location filename="../../CommandConstraints.cpp" line="8627"/>
      <location filename="../../CommandConstraints.cpp" line="8629"/>
      <source>Fix the radius/diameter of an arc or a circle</source>
      <translation type="unfinished">Fix the radius/diameter of an arc or a circle</translation>
    </message>
  </context>
  <context>
    <name>TaskSketcherTool_c1_translate</name>
    <message>
      <location filename="../../DrawSketchHandlerTranslate.h" line="488"/>
      <source>Apply equal constraints</source>
      <translation type="unfinished">Apply equal constraints</translation>
    </message>
    <message>
      <location filename="../../DrawSketchHandlerTranslate.h" line="491"/>
      <source>If this option is selected dimensional constraints are excluded from the operation.
Instead equal constraints are applied between the original objects and their copies.</source>
      <translation type="unfinished">If this option is selected dimensional constraints are excluded from the operation.
Instead equal constraints are applied between the original objects and their copies.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherCompExternal</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1448"/>
      <source>Create external</source>
      <translation type="unfinished">Create external</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1449"/>
      <source>Create external edges linked to external geometries.</source>
      <translation type="unfinished">Create external edges linked to external geometries.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherProjection</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1503"/>
      <source>Create external projection geometry</source>
      <translation type="unfinished">Create external projection geometry</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1504"/>
      <source>Create the projection edges of an external geometry.
External edges can be either defining or construction geometries.
You can use the toggle construction tool.</source>
      <translation type="unfinished">Create the projection edges of an external geometry.
External edges can be either defining or construction geometries.
You can use the toggle construction tool.</translation>
    </message>
  </context>
  <context>
    <name>CmdSketcherIntersection</name>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1540"/>
      <source>Create external intersection geometry</source>
      <translation type="unfinished">Create external intersection geometry</translation>
    </message>
    <message>
      <location filename="../../CommandCreateGeo.cpp" line="1542"/>
      <source>Create the intersection edges of an external geometry with the sketch plane.
External edges can be either defining or construction geometries.
You can use the toggle construction tool.</source>
      <translation type="unfinished">Create the intersection edges of an external geometry with the sketch plane.
External edges can be either defining or construction geometries.
You can use the toggle construction tool.</translation>
    </message>
  </context>
</TS>
